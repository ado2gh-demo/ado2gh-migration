# 🚀 Azure DevOps to GitHub Repository Migration Pipeline

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Pipeline](https://img.shields.io/badge/Pipeline-Azure%20DevOps-0078D7.svg)](https://azure.microsoft.com/en-us/services/devops/)
[![Migration Tool](https://img.shields.io/badge/Tool-gh--ado2gh-181717.svg)](https://github.com/github/gh-ado2gh)

> A stage-based Azure DevOps pipeline for migrating repositories from Azure DevOps to GitHub Enterprise at scale. Supports batch migrations, automated validation, pipeline rewiring, and opt-in ADO repo disabling.

---

## 🎯 Migration Challenges at Enterprise Scale

Enterprise-scale repository migration from Azure DevOps to GitHub Enterprise is a multi-stage process that includes readiness validation, repository migration, post-migration verification, and pipeline rewiring. When applied to thousands of repositories, this process becomes difficult to coordinate, error-prone, and hard to scale using ad-hoc scripts or centralized execution models.

This pipeline addresses those challenges through a staged, self-service migration model. Instead of relying on a single central team, individual product teams can migrate their own repositories using a standardized Azure DevOps YAML pipeline that orchestrates the entire lifecycle. This approach reduces operational bottlenecks, limits blast radius, and enforces consistency across all migrations.

At enterprise scale, this pipeline overcomes the following challenges:

- ⏱️ Serial execution does not scale for thousands of repositories
- 🚦 Centralized migration teams become bottlenecks
- ⚠️ All-at-once migrations increase risk and blast radius
- 🔍 Manual validation leads to errors and inconsistencies
- 📊 Tracking partial success and failures is operationally complex


## 📋 Table of Contents

- [Pipeline Execution Model](#-pipeline-execution-model)
- [Limitations](#️-limitations)
- [Prerequisites](#️-prerequisites)
- [Quick Start](#-quick-start-your-first-migration)
- [FAQ](#-frequently-asked-questions)
- [Contributing](#-contributing)
- [License](#-license)

---

## 📋 Pipeline Execution Model

> ℹ️ **Informational Only**  
> This section is provided for **conceptual understanding** of the pipeline flow.
> Actual execution behavior is governed by the YAML implementation.

This pipeline orchestrates a **six-stage migration process** from Azure DevOps to GitHub Enterprise. Every stage runs on a **Microsoft-hosted Ubuntu agent** (`ubuntu-latest`) by default and has no job timeout, so long-running migrations aren't cut off. To point the pipeline at a self-hosted pool instead, edit the single `pool:` block at the top of the YAML — the install scripts auto-detect and adapt to whichever agent actually runs them, so no separate toggle parameter is needed.

### Key Features

- **Partial Success:**  **Stage 3 (Repository Migration)** publishes a `repos-migration-status.csv` artifact that tracks which repositories migrated successfully and which failed. Stages 4-6 consume this artifact and execute **only against successfully migrated repositories**. **Stage 5 (Pipeline Rewiring)** has additional logic: it reads pipeline definitions from `pipelines.csv`, then cross-references with `repos-migration-status.csv` to ensure rewiring only occurs for repositories that migrated successfully.

- **Manual Approval Gate:**  After **Stage 2 (Pre-migration Check)**, The pipeline pauses at a manual approval gate to allow review of active pull requests and running pipelines before migration. The approval expires after 1 day and is automatically rejected if not approved.

- **Stage 4 and Stage 5 run in parallel:**  Both depend only on Stage 3 succeeding, not on each other — Migration Validation reads GitHub/ADO directly, Pipeline Rewiring reads the CSVs, so there's no reason to serialize them.

- **Stage Dependencies:**  Stages 1-3 require strict success. Stages 4-6 tolerate partial failures and will execute even if the previous stage completes with issues.

> **Note:** Since Ubuntu runners do not persist state between stages, the pipeline uses artifacts for cross-stage continuity.

```mermaid
---
config:
  theme: neo
  layout: dagre
  look: handDrawn
---
flowchart TB
    Start["<b>Start YAML Pipeline</b>"] --> Stage1["<b>Stage 1: Prereq validation</b><br>Verify repos.csv & pipeline.csv"]
    Stage1 --> Stage2["<b>Stage 2: Pre-migration check</b><br>Check for active PR and pipelines"]
    Stage2 --> Gate1["<b>User approval</b><br>Approval to trigger the next stage"]
    Gate1 -- Approved --> Stage3["<b>Stage 3: Repository Migration</b><br>Migrate repositories with commit history and branches"]
    Gate1 -- Rejected --> End1["<b>Pipeline Cancelled</b>"]
    Stage3 --> Stage4["<b>Stage 4: Migration Validation</b><br>Compare every branch and tag between ADO and GHE by name and commit SHA to confirm commit history integrity"]
    Stage3 --> Stage5["<b>Stage 5: Pipeline Rewiring</b><br>Rewire Azure DevOps YAML pipelines to GitHub repositories using a service connection<br>(runs in parallel with Stage 4, skipped in Repo Migration-Only mode)"]
    Stage4 --> Stage6["<b>Stage 6: Disable ADO Repositories</b><br>Opt-in: disable successfully migrated ADO repos via the ADO REST API, after validation<br>(skipped unless explicitly enabled)"]
    Stage5 --> Stage6
    Stage6 --> Success(["<b>Migration Complete ✓</b>"])
    
    Start@{ shape: tag-proc}
    Stage1@{ shape: procs}
    Stage2@{ shape: procs}
    Gate1@{ shape: doc}
    Stage3@{ shape: procs}
    End1@{ shape: terminal}
    Stage4@{ shape: procs}
    Stage5@{ shape: procs}
    Stage6@{ shape: procs}
    style Stage1 fill:#e1f5ff,stroke-width:1px,stroke-dasharray: 0
    style Stage2 fill:#e1f5ff
    style Gate1 fill:#FFF9C4
    style Stage3 fill:#e1f5ff
    style End1 fill:#ffcccc
    style Stage4 fill:#e1f5ff
    style Stage5 fill:#e1f5ff
    style Stage6 fill:#e1f5ff
    style Success fill:#e1ffe1
```

### Stage Execution Details

Each stage executes a specific script and generates detailed logs. Stages 4-6 automatically process only repositories that migrated successfully in Stage 3. Stages 4 and 5 run in parallel (both depend only on Stage 3); Stage 6 waits for both.

### Stage 1️⃣: Prerequisite Validation
Performs validation checks to:

- Verify `bash/repos.csv` and `bash/pipelines.csv` exist.

### Stage 2️⃣: Pre-Migration Check
Executes `1_pr_pipeline_check.sh` to:

- Detects active builds, release pipelines, and pull requests

> **⚠️ IMPORTANT**: The pipeline pauses here for manual approval. Review the readiness report to ensure no active PRs or running pipelines exist before proceeding to Stage 3. Timeout: 1 day (auto-rejects if not approved).

### Stage 3️⃣: Repository Migration
Executes `2_migration.sh` to:

- Migrate repository content, branches, and commit history (15 repositories at a time)
- Create `repos-migration-status.csv` tracking `success/failure` for each repository — rewritten after every finished repository (unfinished ones count as `Failed`), so even a cancelled run still publishes a usable file
- Publish artifact for downstream stages

**Stuck repositories (per-repo timeout):** a migration that runs on GitHub longer than `migrationTimeoutMinutes` (default 120) is aborted on GitHub, marked `Failed`, and the stage moves on to the remaining repositories. The clock starts when GitHub reports the migration `IN_PROGRESS`, so time spent waiting in GitHub's queue doesn't count; the queue wait is bounded separately by `migrationQueueTimeoutMinutes` (default 120). Timed-out repositories are not retried.

- **Circuit breaker:** after `migrationCircuitBreakerThreshold` timeouts in one run (default 3, `0` = off), no new repositories are started — repeated timeouts usually mean GitHub itself is having trouble. Repositories still waiting are marked `Failed` and can go in a later wave.
- **`migration-timeouts.csv`** (published as the `migration-timeouts` artifact) lists every timed-out or not-started repository with its migration ID, GitHub's final state, and whether a partial repository was left on GitHub.
- **⚠️ Before re-running a timed-out repository**, delete the partial repository GitHub leaves behind after an abort (`github_repo_exists=yes` in `migration-timeouts.csv`) — otherwise the re-run stops with "No operation will be performed". If the abort could not be confirmed (`TIMEOUT_ABORT_UNCONFIRMED`), check the migration's state on GitHub first.
- **Stage result:** red only if no repository migrated at all; otherwise **Succeeded with issues**, and the later stages run normally for the repositories that migrated.

**If `gh ado2gh` exits early:** when the migration tool exits without a final result (crash, out of memory, network error), the migration may still be running on GitHub. The script checks GitHub before deciding:
- GitHub says **SUCCEEDED** → the repository is marked `Success` (row `CLIENT_EXITED_SUCCEEDED` in `migration-timeouts.csv`)
- GitHub says **FAILED** → `Failed`, as before
- **Still queued or running** → the script keeps watching it through GitHub's API, with the same time limits, and aborts it at the deadline like any other timeout
- GitHub's state **can't be read** (5 tries, about 5 minutes) → `Failed`, with an ACTION REQUIRED warning and a `CLIENT_EXITED_UNVERIFIED` row: check that migration on GitHub, it may still be running

**If the stage is cancelled:** every migration still running is aborted on GitHub, so nothing keeps migrating after a cancel. Repositories that already finished keep their result; the cancelled ones are `Failed` and listed as `CANCELLED_ABORT_REQUESTED` in `migration-timeouts.csv`. The abort is requested but can't be verified in the few seconds Azure DevOps allows before stopping the job: check those migrations on GitHub and delete any partial repository before re-running. A migration that was finishing at that exact moment can still end `SUCCEEDED` on GitHub (seen once in testing), so a cancelled repository may in fact be fully migrated.

### Stage 4️⃣: Repository Migration Validation
Executes `3_post_migration_validation.sh` (operates on successfully migrated repos only) to:

- Compare **every** branch and tag between ADO and GitHub by name and by the commit SHA it points to (identical head SHAs imply identical commit history, so commits are not counted)
- Classify each repository as `VALID`, `INVALID` (a ref missing on either side, GitHub's default branch missing ADO commits, or the GitHub repo does not exist) or `UNVERIFIED` (the comparison could not be completed, e.g. API errors that persisted through retries, or an ADO repo that is already disabled) — API errors are never reported as data differences
- Report as a **warning**, not a failure: a default branch where GitHub has every ADO commit plus newer ones (e.g. commits pushed to the migrated repo after the migration, possibly while validation is still running), and any non-default branch or tag pointing to a different SHA — each with an explanation (e.g. "GitHub is 3 commit(s) behind ADO", or unrelated history)
- Use GitHub GraphQL (about 1 point per 100 refs), wait out rate limits until their reset instead of failing, and resolve GitHub's renaming of characters it doesn't allow in repo names (e.g. `(` → `-`)
- Must run **before** the ADO repositories are disabled: ADO returns 404 for a disabled repo, so its refs can no longer be compared

### Stage 5️⃣: Pipeline Rewiring
Executes `4_rewire_pipeline.sh` (operates on successfully migrated repos only; skipped in Repo Migration-Only mode) to:

- Rewire Azure DevOps pipelines to point to GitHub repositories via service connection
- Verify each claimed success directly against ADO's build-definitions API before trusting it
- Publish `pipeline-rewiring-status.csv` (one row per pipeline: Success/AlreadyOnGitHub/Failed/Skipped)

### Stage 6️⃣: Disable ADO Repositories (opt-in)
Executes `bash/6_disable_repo.sh` (operates on successfully migrated repos only) to:

- Disable each successfully migrated ADO repository through the ADO REST API directly (look the repo up by name, then set `isDisabled: true`), preventing accidental commits to the old location. It no longer uses `gh ado2gh disable-ado-repo`, which downloads the project's full repository list (~26 MB) on every call
- Pause and retry when ADO throttles requests, the same way Pipeline Rewiring does
- Append a `disabled` (0/1) column to `repos-migration-status.csv`
- Publish per-repo logs as the `disable-repo-logs` artifact

Skipped by default — enable the `Disable ADO repos after rewiring` parameter to run it. Waits for both Pipeline Rewiring and Migration Validation (ADO returns 404 for a disabled repo, so validation must read the repos first), and only runs if validation succeeded. Runs even if Pipeline Rewiring was skipped (e.g. in Repo Migration-Only mode), since disabling ADO repos doesn't depend on pipelines being rewired.

**Checking a wave before migration day (`--dry-run`):** the same script can check a wave's repositories against the real ADO org without changing anything. It only makes read requests, never modifies the input CSV, and accepts a plain `repos.csv`:

```bash
ADO_PAT="..." ./bash/6_disable_repo.sh --csv bash/repos.csv --dry-run
```

It writes `disable-dry-run-report.csv` with one result per repository (`WOULD_DISABLE`, `ALREADY_DISABLED`, `NOT_FOUND`, `ERROR`, `SKIPPED`) and exits with an error if any repository is `NOT_FOUND` or `ERROR`.

---

## ⚠️ Limitations

#### 1️⃣ What Gets Migrated 
- Git repository content (all files)
- Complete commit history
- All branches and tags
- Commit metadata (authors, dates, messages, SHAs)

**Recommendation:** Complete or abandon all active pull requests before migrating.

#### 2️⃣ Azure DevOps agent Timeout
- Every job in this pipeline sets `timeoutInMinutes: 0` (unlimited), so the default 60-minute Azure DevOps hosted-agent cap doesn't apply here — you don't need a self-hosted agent just to avoid it. If you do point the pipeline at a self-hosted pool (edit the `pool:` block in the YAML), the install steps auto-detect that environment and adapt without any extra configuration.
- The actual repository migration is executed on GitHub's backend services, not on the Azure DevOps agent itself. The agent only runs lightweight scripts that poll the migration status at regular intervals (every 30–60 seconds).
- `gh ado2gh migrate-repo` has no timeout of its own, so a migration stuck on GitHub's side would wait forever. Stage 3 bounds this per repository (see Stage 3: Repository Migration): a stuck repository is aborted and marked `Failed` instead of blocking the whole run.

- **Track Long-Running Migrations:**
If your pipeline times out, monitor migration progress using the GitHub CLI:

```bash
gh extension install mona-actions/gh-migration-monitor
gh migration monitor
```

[GitHub Migration Monitor](https://github.com/mona-actions/gh-migration-monitor)

#### 3️⃣ Pipeline Rewiring
- Only YAML-based pipelines are supported
- Classic pipelines (UI-defined) are NOT supported must be rewired manually. 

#### 4️⃣ Repository Migration Size Limits
The [GitHub Enterprise Importer](https://github.com/github/gh-ado2gh) has the following size limits:

| Item | Maximum Size |
|------|--------------|
| Repository archive | ~40 GiB |
| Single file (during migration) | 400 MiB |
| Single file (after migration) | 100 MiB (larger files must use Git LFS) |
| Single commit | 2 GiB |





---

## ⚙️ Prerequisites



> **Watch these video guides** before starting your first migration:

#### Part 1: Prerequisites Overview

https://github.com/user-attachments/assets/cdf6cc4e-ae3b-44ce-a1e6-937b1eeb4ca3

_Covers: CSV configuration, PAT tokens, service connections, and variable groups_

#### Part 2: Pipeline info

https://github.com/user-attachments/assets/ff93c5de-ba12-45e4-834d-31d3c7d8ef5b

_Covers: the pipeline design and how it works_

---

### Initial Setup

Complete these steps before your first migration pipeline run:

#### 1️⃣ 🧩 GitHub Service Connection

Ensure a GitHub service connection exists in Azure DevOps; create one if required:

1. Navigate to **Project Settings** → **Service connections**
2. Create new **GitHub** connection (choose "GitHub App" for best security)
3. Grant **Contributor** permissions on target GitHub org/repos
4. Copy the service connection ID (GUID)
5. Add ID to `serviceConnection` column in `bash/pipelines.csv`

**Example:**
```csv
serviceConnection: 3dfa8dac-601c-4b68-a4eb-29737c5ebf04
```

[Learn more about service connections](https://learn.microsoft.com/en-us/azure/devops/pipelines/library/service-endpoints)

---

#### 2️⃣ 🗂️ CSV Configuration Files

Edit two CSV template files in the `bash/` directory to define your migration scope:

**`bash/repos.csv`** - Repositories to migrate

| Column | Description |
|--------|-------------|
| `org` | Azure DevOps organization name |
| `teamproject` | Azure DevOps project name |
| `repo` | Azure DevOps repository name |
| `github_org` | Target GitHub organization |
| `github_repo` | Target GitHub repository name |
| `gh_repo_visibility` | `private`, `public`, or `internal` |

**`bash/pipelines.csv`** - Pipelines to rewire (Stage 5)

| Column | Description |
|--------|-------------|
| `org` | Azure DevOps organization name |
| `teamproject` | Azure DevOps project name |
| `repo` | Azure DevOps repository name (cross-references with repos.csv) |
| `pipeline_id` | Azure DevOps pipeline (build definition) ID — required, used to target the exact pipeline |
| `pipeline` | Pipeline name/path (e.g., `\my-pipeline-ci`) — for reference |
| `url` | Pipeline URL (for reference) |
| `serviceConnection` | GitHub service connection ID (see Prerequisite #1) |
| `github_org` | Target GitHub organization |
| `github_repo` | Target GitHub repository name |


---

#### 3️⃣ 🔐 Authentication Tokens

Create **2 PAT tokens** with the following scopes:

**GitHub PAT (all stages, including the opt-in Disable ADO Repositories stage):**
- ✅ `repo` (Full control of private repositories)
- ✅ `workflow` (Update GitHub Action workflows)
- ✅ `admin:org` (Full control of orgs and teams)
- ✅ `read:user` (Read user profile data)

**Azure DevOps PAT:**
- **Recommended**: `Full access` / Admin scope (simplest option)
- **Alternative**: Use minimum required scopes (see below)

<details>
<summary>📋 Minimum Required ADO PAT Scopes (click to expand)</summary>

- ✅ `Analytics` (Read)
- ✅ `Build` (Read)
- ✅ `Code` (Read, Full, Status)
- ✅ `GitHub Connections` (Read & manage)
- ✅ `Graph` (Read)
- ✅ `Identity` (Read)
- ✅ `Pipeline Resources` (Use)
- ✅ `User Profile` (Read)
- ✅ `Project and Team` (Read)
- ✅ `Release` (Read)
- ✅ `Security` (Manage)
- ✅ `Service Connections` (Read & query)
- ✅ `Work Items` (Read)

</details>

---

#### 4️⃣ 🔐 Variable Group

Store your PAT tokens (from Prerequisite #3) in a single Azure DevOps Variable Group named `ado2gh-self-pipeline`:

| Variable | Value | Used In |
|----------|-------|---------|
| `GH_PAT` | GitHub PAT (see Prerequisite #3) | All stages |
| `ADO_PAT` | Azure DevOps PAT | All stages |

> **Note:** Verify the variable group is created and granted pipeline permissions. Modify the YAML file's `variables:` block if you use a different group name.

---

#### 5️⃣ ⚙️ Pipeline Run Parameters

Set these in the "Run pipeline" dialog each time you queue a run:

| Parameter | Default | Effect |
|-----------|---------|--------|
| `Repo migration & validation only` (`runDemoRepoMigration`) | Off | Skips Stage 5 (Pipeline Rewiring) — see below |
| `Repo migration: timeout in minutes (counted from GitHub IN_PROGRESS)` (`migrationTimeoutMinutes`) | `120` | Aborts a repository migration that runs on GitHub longer than this, marks it `Failed`, and continues with the rest. See Stage 3: Repository Migration above |
| `Repo migration: max minutes waiting in GitHub's queue (after submission, max 15 at a time)` (`migrationQueueTimeoutMinutes`) | `120` | Same, for a repository that never leaves GitHub's queue. Only repositories already submitted count (15 at a time), so large batches don't hit it just by waiting their turn |
| `Repo migration: stop starting new repos after N timeouts (0 = disabled)` (`migrationCircuitBreakerThreshold`) | `3` | Circuit breaker: after N timeouts in one run, repositories not yet started are marked `Failed` instead of being started |
| `Pipeline rewiring: concurrent jobs` (`rewireMaxConcurrent`) | `2` | How many pipelines Stage 5 rewires at once. Raise this for a larger `pipelines.csv` batch; each concurrent job writes its own ~150MB verbose log, so don't raise it past what your agent's disk can hold |
| `Disable ADO repos after rewiring (Success repos only)` (`runRepoDisable`) | Off | Opt-in: runs Stage 6 (Disable ADO Repositories) after rewiring (or its skip) and migration validation complete |

##### Repo Migration-Only mode

Enable `Repo migration & validation only` if you want to skip pipeline rewiring — e.g. a repo-only migration with no ADO pipelines to move.

**Behavior:**
- ✅ Runs Stages 1-4 (Prerequisites, Pre-migration Check, Repo Migration, Migration Validation)
- ❌ Skips Stage 5 (Pipeline Rewiring)
- ✅ Stage 6 (Disable ADO Repositories) still runs if `runRepoDisable` is also enabled — disabling ADO repos doesn't depend on pipelines being rewired

**Rollback (if needed):**
```bash
# Navigate to GitHub repository settings
# https://github.com/<org>/<repo>/settings
# Scroll to "Danger Zone" → "Delete this repository"
```

---

## 🚀 Quick Start: Your First Migration

**Before you begin**, ensure you've completed the [Prerequisites](#️-prerequisites):
- ✅ Created 2 PAT tokens (1 ADO, 1 GitHub)
- ✅ Configured 1 Variable Group in Azure DevOps
- ✅ Set up GitHub service connection
- ✅ Prepared CSV files in `bash/` directory

---

### Step-by-Step Instructions

#### 1️⃣ **Clone this pipeline repository**
   ```bash
   # Clone the ado2gh-ado-pipelines repository
   git clone <your-repo-url>
   cd ado2gh-ado-pipelines
   ```

#### 2️⃣ **Prepare CSV configuration files**
   ```bash
   # Edit repos.csv - Add repositories for your first run
   code bash/repos.csv
   
   # Edit pipelines.csv - Optional for Demo Mode, required for production
   code bash/pipelines.csv
   ```

   **Example repos.csv:**
   ```csv
   org,teamproject,repo,github_org,github_repo,gh_repo_visibility
   mycompany,Platform,api-service,mycompany-gh,platform-api,private
   mycompany,Platform,web-frontend,mycompany-gh,platform-web,private
   ```
   **Example pipelines.csv:**
   ```csv
   org,teamproject,repo,pipeline_id,pipeline,url,serviceConnection,github_org,github_repo
   mycompany,Platform,api-service,123,\api-service-ci,https://dev.azure.com/mycompany/Platform/_build?definitionId=123,abc123-def4-56gh-78ij-90klmn1234op,mycompany-gh,platform-api
   mycompany,Platform,web-frontend,456,\web-frontend-ci,https://dev.azure.com/mycompany/Platform/_build?definitionId=456,abc123-def4-56gh-78ij-90klmn1234op,mycompany-gh,platform-web
   ```

#### 3️⃣ **Commit and push changes**
   ```bash
   git add bash/repos.csv bash/pipelines.csv
   git commit -m "Configure migration batch: test repositories"
   git push
   ```

#### 4️⃣ **Set up the pipeline in Azure DevOps** (first-time only)
   
   **If pipeline doesn't exist:**
   - Navigate to `https://dev.azure.com/<org>/<project>` → **Pipelines** → **New Pipeline**
   - Select your repository source (Azure Repos/GitHub)
   - Choose **Existing Azure Pipelines YAML file** → Select `ado2gh-migration.yml`
   - Click **Save** or **Run**
   
   **If pipeline already exists:**
   - Go to **Pipelines** → Select the migration pipeline → Click **Run pipeline**

#### 5️⃣ **Configure pipeline parameters**
   
   In the "Run pipeline" dialog, configure (see Prerequisite #5, "Pipeline Run Parameters", above, for the full list):
   
   **For Repo Migration-Only mode:**
   - Check the box: "Repo migration & validation only"

   **To disable ADO repos automatically after migration:**
   - Check the box: "Disable ADO repos after rewiring (Success repos only)"
   
   Click **Run** to start the pipeline.

#### 6️⃣ **Monitor pipeline execution**
   
   | Stage | Key Actions | Expected Outcome |
   |-------|-------------|------------------|
   | **Stage 1: Prerequisite Validation** | View logs to verify CSV validation | ✅ "X repositories found" message |
   | **Stage 2: Pre-migration Check** | View the "Execute Migration Readiness Check" task log | ✅ No active PRs or running pipelines |
   | **🔒 Manual Approval Gate** | Review readiness report, then **APPROVE** or **REJECT** | ✅ Approval granted (timeout: 1 day) |
   | **Stage 3: Repository Migration** | Monitor logs, check the `migration-results` artifact (`repos-migration-status.csv`, and `migration-timeouts` if any repo timed out) | ✅ Migration completes (success/partial) |
   | **Stage 4: Migration Validation** | Download `validation-logs`, check ✅/❌/⚠️ indicators | ✅ All branches and tags match by name and SHA (❌ = real difference, ⚠️ = could not be verified, re-run) |
   | **Stage 5: Pipeline Rewiring** | Download `rewiring-logs`, check `pipeline-rewiring-status.csv` in `migration-results` | ✅ Pipelines point to GitHub repos |
   | **Stage 6: Disable ADO Repositories** (opt-in) | Download `disable-repo-logs` if any repo failed to disable | ✅ `repos-migration-status.csv`'s `disabled` column is `1` for each repo |

#### 7️⃣ **Verify migration success**
   
   **Automated validation (Stage 4):**
   - Every branch and tag exists in both ADO and GitHub and points to the same commit SHA (same SHA = same commit history)
   - Each repository ends `VALID`, `INVALID` (a real difference) or `UNVERIFIED` (could not be checked, e.g. persistent API errors — re-run it)
   - A non-default branch or tag with a different SHA, or a default branch where GitHub only has newer commits on top of ADO's, is a warning, not a failure
   
   **Manual verification:**
   ```bash
   # Clone the migrated repository
   git clone https://github.com/<github_org>/<github_repo>.git
   cd <github_repo>
   
   # Verify branches exist
   git branch -a
   
   # Check commit history
   git log --oneline
   
   ```
   
  **Post-migration cleanup:**
   
   After successful migration, disable ADO repositories to prevent accidental commits. Two ways to do this:

   - **Automatically, as part of the pipeline:** enable the `Disable ADO repos after rewiring (Success repos only)` parameter on your run (see Prerequisite #5). Runs Stage 6 against every repo `repos-migration-status.csv` marks `Success`.
   - **Manually, for a small batch outside a pipeline run:**
     1. Edit `misc/disable_repo.csv` with the repos to disable (org,teamproject,repo)
     2. Run the disable script:
        ```bash
        cd misc
        export ADO_PAT="your-ado-pat-token"
        ./6_disable_repo.sh
        ```
     > **Note:** The script automatically looks for `disable_repo.csv` in its own folder. Use `--csv <path>` to specify a different file.

---

#### 8️⃣ Manual remediation: rewiring a handful of pipelines locally

If Stage 5 comes back with a handful of pipelines `Skipped`/`Failed` and you don't want to re-queue the whole pipeline just to retry them, `misc/4_rewire_pipeline_local.sh` runs the same rewiring logic locally against a trimmed batch:

1. From a completed run's `migration-results` artifact, grab `repos-migration-status.csv` and `pipeline-rewiring-status.csv`.
2. Copy `repos-migration-status.csv` into your current working directory (not `misc/`).
3. Copy `misc/pipelines.csv`'s header plus only the rows for the `pipeline_id`s you need to retry into a working copy of `misc/pipelines.csv` (don't edit the tracked placeholder in place).
4. Run it:
   ```bash
   cd misc
   export ADO_PAT="your-ado-pat-token" GH_PAT="your-gh-pat-token"
   ./4_rewire_pipeline_local.sh
   ```
5. It writes `pipeline-rewiring-status.csv` and a detailed `.log` file to the current directory — nothing is uploaded anywhere, this is local-only.

See the script's own header comment for full prerequisites (including `curl`/`jq`) and its drift warning against `bash/4_rewire_pipeline.sh` — it's a manually-synced copy, not a symlink, so diff the two before trusting it for a real remediation if they might have diverged.

---

### 🎉 Migration Complete!

**Next Steps:**
- **More migrations?** Update `bash/repos.csv` and rerun the pipeline
- **Troubleshooting?** See [FAQ](#-frequently-asked-questions)
- **Advanced configuration?** Review [Prerequisites](#️-prerequisites)

  
---

## ❓ Frequently Asked Questions

### Q1: Can multiple teams run this pipeline simultaneously?

**A:** Yes, **if migrating different repositories**.

**Best Practices:**
- Coordinate migration schedules across teams
- Use separate CSV files per team with **zero repository overlap**
- Ensure each repository appears in only one team's CSV file
- If uncertain, run migrations sequentially to avoid conflicts


### Q2: What happens to the ADO repository after migration?

**A:** The ADO repository remains **intact and unchanged**. Migration is a **copy operation**, not a move.
> **💡 Tip**: After confirming migration success, manually disable the ADO repository to prevent accidental commits.


### Q3: Can I migrate repositories from multiple ADO organizations?

**A:** Yes, but you need **separate ADO PAT tokens** for each organization.

**Requirements:**
- ✅ Create a **separate ADO PAT token for each organization**
- ✅ The pipeline currently supports **one ADO organization per run**
- ✅ To migrate from multiple orgs, run the pipeline **separately for each organization**


### Q4: How long does a typical migration take?

**A:** Highly variable based on repository size and batch size.

### Q5: Can I skip Stage 5 (Pipeline Rewiring) if I don't have pipelines?

**A:** Yes, two ways:
- Enable the `Repo migration & validation only` parameter for that run (see Prerequisite #5) — this skips Stage 5 entirely.
- Or leave the parameter off and provide an **empty `pipelines.csv`** file with just the header row; Stage 5 still runs but has nothing to rewire.

**Empty pipelines.csv:**

```csv
org,teamproject,repo,pipeline_id,pipeline,url,serviceConnection,github_org,github_repo
```

### Q6: Does this pipeline migrate pull requests?

**A:** No, **pull requests are NOT migrated**.

### Q7: Can I migrate private ADO repos to public GitHub repos?

**A:** Yes, use `gh_repo_visibility: public` in repos.csv.


### Q8: What happens if migration fails halfway through?

**A:** The pipeline **continues processing successfully migrated repositories**. Stages 4-6 run only for repos that migrated successfully.

**How Partial Failures Work:**
- ✅ Stage 3 completes with **"Succeeded with issues"** status
- ✅ `repos-migration-status.csv` tracks which repos succeeded/failed
- ✅ A repo stuck on GitHub's side is aborted after `migrationTimeoutMinutes` and marked failed (see Stage 3: Repository Migration); delete the partial repo GitHub leaves behind before re-running it
- ✅ Stages 4-6 automatically skip failed repos and process only successful ones
- ✅ Pipeline completes all stages for successful repositories

### Q9: How do I validate that migration was successful?

**A:** Use the automated validation in **Stage 4**, plus manual verification

---

## 🤝 Contributing

Contributions are welcome! If you'd like to improve this pipeline or documentation:

1. **Fork the repository**
2. **Create a feature branch**: `git checkout -b feature/your-improvement`
3. **Make your changes** and commit: `git commit -m "Add: your improvement description"`
4. **Push to your fork**: `git push origin feature/your-improvement`
5. **Open a Pull Request** with a clear description of your changes

### Reporting Issues

If you encounter bugs or have feature requests:
- Check [existing issues](../../issues) first
- Create a new issue with:
  - Clear description of the problem/request
  - Steps to reproduce (for bugs)
  - Expected vs actual behavior
  - Pipeline logs (if applicable)

Please submit a PR or open an issue.

---

## 📄 License

MIT License

Copyright (c) 2025 Vamsi Cherukuri (<vamsicherukuri@hotmail.com>)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

**Made with ❤️ for the DevOps community**
