# Manual Use Scripts

Scripts here are **NOT** part of the automated pipeline (`ado2gh-migration.yml`) — they're for manual/local use. This doc file lives in `bash/`, but the actual scripts it describes live in `misc/`.

Note there's a separate, similarly-numbered `bash/6_disable_repo.sh` — that one *is* pipeline-integrated (the `RepoDisable` stage's script, reads `repos-migration-status.csv` directly). Don't confuse it with `misc/6_disable_repo.sh` below; they're deliberately different scripts with different CSV contracts.

## misc/6_disable_repo.sh

**Purpose**: Disables Azure DevOps repositories after migration to GitHub, via `gh ado2gh disable-ado-repo`.

**Why manual, not in a pipeline stage?**
This is the standalone/manual path for disabling repos outside of a full pipeline run — e.g. after confirming migration is 100% stable and no reruns are needed, or for a small batch you don't want to wait for a pipeline run to process. For disabling repos automatically as part of the main migration, use the `runRepoDisable` pipeline parameter instead (see the main `README.md`'s "Pipeline Run Parameters" section) — that runs `bash/6_disable_repo.sh` against `repos-migration-status.csv`, not this script.

**Usage:**
```bash
cd misc

# Edit disable_repo.csv with the repos to disable (columns: org,teamproject,repo)

# Set required environment variable (GH_PAT is not needed - this script only calls ADO)
export ADO_PAT="your-ado-pat-token"

# Run the script (reads ./disable_repo.csv by default)
./6_disable_repo.sh

# Or point at a different CSV:
./6_disable_repo.sh --csv /path/to/your.csv
```

**Prerequisites:**
- `disable_repo.csv` with exactly 3 columns: `org,teamproject,repo` (no header extras)
- `ADO_PAT` environment variable
- `gh` CLI with the `gh-ado2gh` extension installed

**Output:** console summary only (`Total | Disabled | Failed` counts) — no log file is written; exits `1` if any repo failed to disable.

## misc/4_rewire_pipeline_local.sh

**Purpose**: Rewires a targeted batch of ADO YAML pipelines to their migrated GitHub repos, without running the full `ado2gh-migration.yml` pipeline. A manually-synced copy of `bash/4_rewire_pipeline.sh` (same rewiring logic, including the ADO-verified success check) — see its own header comment for the full usage/prerequisites and the drift warning, or the main `README.md`'s "Manual remediation: rewiring a handful of pipelines locally" section for a step-by-step walkthrough.

**Why manual, not in a pipeline stage?**
For a quick, targeted fix to a handful of pipelines that came back `Skipped`/`Failed` from a real Stage 5 run, without re-queuing the whole pipeline.

**Output:** `pipeline-rewiring-status.csv` plus a detailed `.log` file, written to the current directory.
