#!/usr/bin/env bash
# ADO -> GitHub parallel migration runner (GitHub Actions optimized)
# - Configurable via CLI parameters
# - Keeps status bar and CSV writes
# - Background jobs write only to log files; parent prints log stream deltas
# - Robust completion parsing so "failed" increments correctly
# - Per-repo timeout: a repo that stays IN_PROGRESS on GitHub longer than
#   --timeout-minutes (or never starts within --queue-timeout-minutes) is
#   aborted on GitHub, marked Failed, and the run moves on. No retries.
# - Circuit breaker: after --circuit-breaker-threshold timeouts, no new
#   migrations are started (GitHub is likely degraded); queued repos are
#   marked Failed (not started). In-flight migrations finish normally.
# - repos-migration-status.csv is rewritten after every completed repo, so a
#   cancelled run still leaves a usable file (unfinished repos = Failed).
# - If gh-ado2gh exits without a final result (crash, OOM, network error), the
#   migration may still be running on GitHub: its state is checked there, and
#   a still-running one is watched via the API under the same deadlines.
# - Stage cancelled: every in-flight migration is aborted on GitHub.

set -o pipefail

############################################
# CLI args
############################################
MAX_CONCURRENT=15  # Hardcoded to maximum safe concurrency
CSV_PATH="repos.csv"
OUTPUT_PATH=""     # empty -> timestamped file
MIGRATION_TIMEOUT_MINUTES=120      # max minutes a repo may stay IN_PROGRESS on GitHub
QUEUE_TIMEOUT_MINUTES=120          # max minutes until GitHub starts it (PENDING_VALIDATION/QUEUED)
CIRCUIT_BREAKER_THRESHOLD=3        # timeouts before no new migrations start (0 = disabled)

# Timeout-path tuning (env-overridable, mainly for testing)
WATCHDOG_INTERVAL_SECONDS="${MIGRATION_WATCHDOG_INTERVAL_SECONDS:-5}"
ABORT_MAX_ATTEMPTS="${MIGRATION_ABORT_MAX_ATTEMPTS:-3}"
ABORT_VERIFY_POLLS="${MIGRATION_ABORT_VERIFY_POLLS:-6}"
ABORT_VERIFY_INTERVAL_SECONDS="${MIGRATION_ABORT_VERIFY_INTERVAL_SECONDS:-20}"
RECONCILE_POLL_SECONDS="${MIGRATION_RECONCILE_POLL_SECONDS:-60}"            # GitHub state polling after gh-ado2gh exited early
RECONCILE_MAX_UNKNOWN="${MIGRATION_RECONCILE_MAX_UNKNOWN_POLLS:-5}"       # consecutive unreadable states before giving up
CANCEL_WAIT_SECONDS="${MIGRATION_CANCEL_WAIT_SECONDS:-6}"                 # on cancel, max seconds after the signal to wait for aborts (ADO kills at 10 s)
GH_CALL_TIMEOUT_SECONDS=120        # cap for each abort / state-query call

while [[ $# -gt 0 ]]; do
  case "$1" in
    --csv)
      CSV_PATH="$2"; shift 2;;
    --output)
      OUTPUT_PATH="$2"; shift 2;;
    --timeout-minutes)
      MIGRATION_TIMEOUT_MINUTES="$2"; shift 2;;
    --queue-timeout-minutes)
      QUEUE_TIMEOUT_MINUTES="$2"; shift 2;;
    --circuit-breaker-threshold)
      CIRCUIT_BREAKER_THRESHOLD="$2"; shift 2;;
    -*|--*)
      echo -e "\033[31m[ERROR] Unknown option: $1\033[0m"; exit 1;;
    *)
      echo -e "\033[31m[ERROR] Unexpected positional arg: $1\033[0m"; exit 1;;
  esac
done

############################################
# Validate settings
############################################
for _opt in MIGRATION_TIMEOUT_MINUTES QUEUE_TIMEOUT_MINUTES CIRCUIT_BREAKER_THRESHOLD \
            WATCHDOG_INTERVAL_SECONDS ABORT_MAX_ATTEMPTS ABORT_VERIFY_POLLS ABORT_VERIFY_INTERVAL_SECONDS \
            RECONCILE_POLL_SECONDS RECONCILE_MAX_UNKNOWN CANCEL_WAIT_SECONDS; do
  if [[ ! "${!_opt}" =~ ^[0-9]+$ ]]; then
    echo -e "\033[31m[ERROR] ${_opt} must be a non-negative integer (got '${!_opt}')\033[0m"; exit 1
  fi
done
if (( MIGRATION_TIMEOUT_MINUTES < 1 || QUEUE_TIMEOUT_MINUTES < 1 || WATCHDOG_INTERVAL_SECONDS < 1 || ABORT_MAX_ATTEMPTS < 1 \
      || RECONCILE_POLL_SECONDS < 1 || RECONCILE_MAX_UNKNOWN < 1 )); then
  echo -e "\033[31m[ERROR] Timeouts, intervals and attempt counts must be >= 1\033[0m"; exit 1
fi
if ! command -v timeout >/dev/null 2>&1; then
  echo -e "\033[31m[ERROR] 'timeout' (GNU coreutils) is required\033[0m"; exit 1
fi
# Last-resort cap on the gh process itself, in case the watchdog below never fires
HARD_CAP_SECONDS=$(( (QUEUE_TIMEOUT_MINUTES + MIGRATION_TIMEOUT_MINUTES + 15) * 60 ))
# Normalize CRLF if present (Windows-generated CSV)
sed -i 's/\r$//' "${CSV_PATH}" 2>/dev/null || true

if [[ ! -f "${CSV_PATH}" ]]; then
  echo -e "\033[31m[ERROR] CSV file not found: ${CSV_PATH}\033[0m"; exit 1
fi

if [[ -z "${OUTPUT_PATH}" ]]; then
  timestamp="$(date +%Y%m%d-%H%M%S)"
  OUTPUT_CSV_PATH="repo_migration_output-${timestamp}.csv"
else
  OUTPUT_CSV_PATH="${OUTPUT_PATH}"
fi

############################################
# CSV helpers
############################################

# Robust CSV line parser (quoted fields, escaped quotes)
parse_csv_line() {
  local line="$1"
  local -a fields=()
  local field="" in_quotes=false i char next
  for ((i=0; i<${#line}; i++)); do
    char="${line:$i:1}"
    next="${line:$((i+1)):1}"
    if [[ "${char}" == '"' ]]; then
      if [[ "${in_quotes}" == true ]]; then
        if [[ "${next}" == '"' ]]; then
          field+='"'; ((i++))
        else
          in_quotes=false
        fi
      else
        in_quotes=true
      fi
    elif [[ "${char}" == ',' && "${in_quotes}" == false ]]; then
      fields+=("${field}")
      field=""
    else
      field+="${char}"
    fi
  done
  fields+=("${field}")
  printf '%s\n' "${fields[@]}"
}

# Strip a single leading and trailing double-quote if present (no eval)
strip_quotes() {
  local s="$1"
  [[ ${s} == \"* ]] && s="${s#\"}"
  [[ ${s} == *\" ]] && s="${s%\"}"
  printf '%s' "$s"
}

# Header check: require these columns anywhere in header order
# CSV now has 6 columns: org,teamproject,repo,github_org,github_repo,gh_repo_visibility
REQUIRED_COLUMNS=(org teamproject repo github_org github_repo gh_repo_visibility)

read -r HEADER_LINE < "${CSV_PATH}"
mapfile -t HEADER_FIELDS < <(parse_csv_line "${HEADER_LINE}")

# Build an index map: name -> position
declare -A COLIDX=()
for idx in "${!HEADER_FIELDS[@]}"; do
  name="${HEADER_FIELDS[$idx]}"
  name="${name%\"}"; name="${name#\"}"
  # An empty key is a bash error that silently ends this loop, leaving
  # every later column unmapped. Skip it and keep mapping.
  if [[ -z "${name}" ]]; then
    echo "##vso[task.logissue type=warning]${CSV_PATH}: header column $((idx + 1)) has no name (stray comma or blank column?); ignored"
    continue
  fi
  COLIDX["$name"]="$idx"
done

# Validate required columns exist
missing=()
for col in "${REQUIRED_COLUMNS[@]}"; do
  [[ -n "${COLIDX[$col]:-}" ]] || missing+=("$col")
done
if [[ ${#missing[@]} -gt 0 ]]; then
  echo -e "\033[31m[ERROR] CSV missing required columns: ${missing[*]}\033[0m"
  echo -e "\033[31m[ERROR] Required: ${REQUIRED_COLUMNS[*]}\033[0m"
  exit 1
fi

############################################
# Status CSV writers
############################################
# The per-run CSV lives in memory, in input order, and is rewritten in full
# on every change. Re-parsing the file char by char instead cost ~25 s per
# update at 1,600 rows, twice per repo, blocking the main loop.
RUN_ROW_PREFIX=()  # '"org","teamproject","repo","github_org","github_repo","visibility"'
RUN_ROW_GH_REPO=()
RUN_ROW_STATUS=()
RUN_ROW_LOG=()

add_status_row() {
  # args: org teamproject repo github_org github_repo gh_repo_visibility status log_file
  RUN_ROW_PREFIX+=("$(printf '"%s","%s","%s","%s","%s","%s"' "$1" "$2" "$3" "$4" "$5" "$6")")
  RUN_ROW_GH_REPO+=("$5")
  RUN_ROW_STATUS+=("$7")
  RUN_ROW_LOG+=("$8")
}

write_migration_status_csv() {
  local tmp="${OUTPUT_CSV_PATH}.tmp" i
  {
    echo "org,teamproject,repo,github_org,github_repo,gh_repo_visibility,Migration_Status,Log_File"
    for i in "${!RUN_ROW_PREFIX[@]}"; do
      printf '%s,"%s","%s"\n' "${RUN_ROW_PREFIX[$i]}" "${RUN_ROW_STATUS[$i]}" "${RUN_ROW_LOG[$i]}"
    done
  } > "${tmp}"
  mv "${tmp}" "${OUTPUT_CSV_PATH}"
}

update_repo_status_in_csv() {
  local target_repo="$1" new_status="$2" log_file="$3" i
  for i in "${!RUN_ROW_GH_REPO[@]}"; do
    if [[ "${RUN_ROW_GH_REPO[$i]}" == "${target_repo}" ]]; then
      RUN_ROW_STATUS[$i]="${new_status}"
      RUN_ROW_LOG[$i]="${log_file}"
    fi
  done
  write_migration_status_csv
}

# Circuit breaker: every still-"Pending" row becomes "Not Started", in one pass.
mark_pending_rows_not_started() {
  local i
  for i in "${!RUN_ROW_STATUS[@]}"; do
    [[ "${RUN_ROW_STATUS[$i]}" == "Pending" ]] && RUN_ROW_STATUS[$i]="Not Started"
  done
  write_migration_status_csv
}

# Quote one CSV field (double any embedded quotes)
csv_quote() {
  local s="${1//\"/\"\"}"
  printf '"%s"' "${s}"
}

TIMEOUTS_CSV="migration-timeouts.csv"
write_timeouts_csv_header() {
  echo "org,teamproject,repo,github_org,github_repo,outcome,migration_id,phase,minutes_in_phase,github_state,github_repo_exists,details" > "${TIMEOUTS_CSV}"
}

# Writes "${log_file}.timeout": the outcome..details part of a
# migration-timeouts.csv row (the parent prepends the repo columns).
# Args: log_file outcome migration_id phase minutes github_state repo_exists details
write_issue_fragment() {
  {
    csv_quote "$2"; printf ','; csv_quote "$3"; printf ','
    csv_quote "$4"; printf ','; csv_quote "$5"; printf ','
    csv_quote "$6"; printf ','; csv_quote "$7"; printf ','
    csv_quote "$8"; printf '\n'
  } > "$1.timeout"
}

# Appends " ... delete it before re-running" advice for github_org/github_repo
# to details. Prints "<repo_exists><TAB><details>". Args: github_org github_repo details
add_repo_left_behind_advice() {
  local exists details="$3"
  exists="$(github_repo_exists "$1" "$2")"
  case "${exists}" in
    yes)     details+=". GitHub repo $1/$2 was left behind (partial): delete it before re-running";;
    unknown) details+=". Could not check whether $1/$2 exists: if it does, delete it before re-running";;
  esac
  printf '%s\t%s' "${exists}" "${details}"
}

############################################
# Timeout handling (runs only when a repo hits its deadline)
############################################

# Prints "STATE<TAB>failureReason" for a migration ID, or nothing if GitHub
# could not be queried. On GraphQL errors gh prints the error JSON to stdout,
# so only a line that starts with a state word is accepted.
get_migration_state() {
  local out
  out="$(timeout --kill-after=10 "${GH_CALL_TIMEOUT_SECONDS}" gh api graphql \
    -f id="$1" \
    -f query='query($id:ID!){node(id:$id){... on RepositoryMigration{state failureReason}}}' \
    --jq '.data.node | select(. != null) | [.state, (.failureReason // "")] | @tsv' 2>/dev/null)"
  [[ "${out}" =~ ^[A-Z_]+($'\t'|$) ]] && printf '%s' "${out}"
}

# Prints the ID of the newest migration of github_org/github_repo created at or
# after $3 (ISO-8601 UTC), or nothing. Verified 2026-10-01: GitHub applies
# first:N before orderBy, so first:1 + DESC can return an older migration;
# fetch them all and pick the newest here.
find_migration_id() {
  local found id created
  found="$(timeout --kill-after=10 "${GH_CALL_TIMEOUT_SECONDS}" gh api graphql \
    -f org="$1" -f repo="$2" \
    -f query='query($org:String!,$repo:String!){organization(login:$org){repositoryMigrations(first:100,repositoryName:$repo){nodes{id createdAt}}}}' \
    --jq '.data.organization.repositoryMigrations.nodes | max_by(.createdAt) // empty | [.id, .createdAt] | @tsv' 2>/dev/null)"
  [[ "${found}" =~ ^RM_[A-Za-z0-9_-]+$'\t' ]] || return 0
  IFS=$'\t' read -r id created <<< "${found}"
  [[ -n "${id}" && ! "${created}" < "$3" ]] && printf '%s' "${id}"
}

# Prints "yes" / "no" / "unknown": does github_org/github_repo exist? Read-only.
# Verified 2026-10-01: GitHub keeps the partially migrated repo after an abort,
# and a re-run then fails with "No operation will be performed".
github_repo_exists() {
  local out
  out="$(timeout --kill-after=10 "${GH_CALL_TIMEOUT_SECONDS}" gh api "repos/$1/$2" --jq '.full_name' 2>&1)"
  if [[ "${out,,}" == "${1,,}/${2,,}" ]]; then
    echo "yes"
  elif [[ "${out}" == *"HTTP 404"* ]]; then
    echo "no"
  else
    echo "unknown"
  fi
}

# Prints this job's migration ID: from the log, else looked up on GitHub by
# repository name (migrations created after the job started), else nothing.
# Args: github_org github_repo log_file job_start_epoch
resolve_migration_id() {
  local id
  id="$(grep -oE '\(ID: RM_[A-Za-z0-9_-]+\)' "$3" | tail -n 1 | sed -E 's/^\(ID: //; s/\)$//')"
  if [[ -z "${id}" ]]; then
    id="$(find_migration_id "$1" "$2" "$(date -u -d "@$(( $4 - 120 ))" +%Y-%m-%dT%H:%M:%SZ)")"
  fi
  printf '%s' "${id}"
}

# True while PID $1 is still our `timeout` process. Only used right before
# sending a signal (guards against PID reuse); not as the watchdog loop
# condition, since right after `&` the child may not have exec'd timeout yet.
is_our_timeout_process() {
  [[ "$(ps -o comm= -p "$1" 2>/dev/null)" == "timeout" ]]
}

# Called after the watchdog stopped migrate-repo. Finds the migration on
# GitHub, aborts it if it is still running and verifies the abort.
# Writes "${log_file}.timeout" (CSV fragment for migration-timeouts.csv).
# Args: github_org github_repo log_file phase minutes_in_phase job_start_epoch
# Return: 0 = migration actually SUCCEEDED (finished at the deadline)
#         2 = timed out, migration confirmed stopped on GitHub
#         3 = timed out, abort NOT confirmed (may still be running on GitHub)
handle_migration_timeout() {
  local github_org="$1" github_repo="$2" log_file="$3" phase="$4" minutes="$5" job_start="$6"
  local migration_id="" state="" reason="" details="" outcome="" rc=3 attempt poll

  migration_id="$(resolve_migration_id "${github_org}" "${github_repo}" "${log_file}" "${job_start}")"

  if [[ -z "${migration_id}" ]]; then
    outcome="TIMEOUT_ABORT_UNCONFIRMED"
    details="No migration ID found in the log or on GitHub; cannot confirm nothing is running"
  else
    IFS=$'\t' read -r state reason <<< "$(get_migration_state "${migration_id}")"
    printf '[%s] [INFO] Migration %s state on GitHub: %s\n' "$(date)" "${migration_id}" "${state:-UNKNOWN (query failed)}"

    for (( attempt = 1; attempt <= ABORT_MAX_ATTEMPTS; attempt++ )); do
      case "${state}" in
        SUCCEEDED|FAILED|FAILED_VALIDATION) break;;
      esac
      printf '[%s] [INFO] Aborting migration %s (attempt %s/%s)\n' "$(date)" "${migration_id}" "${attempt}" "${ABORT_MAX_ATTEMPTS}"
      timeout --kill-after=10 "${GH_CALL_TIMEOUT_SECONDS}" gh ado2gh abort-migration --migration-id "${migration_id}"
      printf '[%s] [INFO] abort-migration exit code: %s\n' "$(date)" "$?"
      for (( poll = 1; poll <= ABORT_VERIFY_POLLS; poll++ )); do
        sleep "${ABORT_VERIFY_INTERVAL_SECONDS}"
        IFS=$'\t' read -r state reason <<< "$(get_migration_state "${migration_id}")"
        printf '[%s] [INFO] Verify abort: state=%s\n' "$(date)" "${state:-UNKNOWN (query failed)}"
        case "${state}" in
          SUCCEEDED|FAILED|FAILED_VALIDATION) break;;
        esac
      done
    done

    case "${state}" in
      SUCCEEDED)
        outcome="SUCCEEDED_AFTER_TIMEOUT"; rc=0
        details="GitHub reports the migration SUCCEEDED at the deadline; counted as Success";;
      FAILED|FAILED_VALIDATION)
        outcome="TIMEOUT_ABORTED"; rc=2
        details="Migration stopped on GitHub (${state}${reason:+: ${reason}})";;
      *)
        outcome="TIMEOUT_ABORT_UNCONFIRMED"
        details="Abort not confirmed after ${ABORT_MAX_ATTEMPTS} attempts; last state ${state:-UNKNOWN}. Escalate migration ID to GitHub";;
    esac
  fi

  local repo_exists=""
  if (( rc != 0 )); then
    IFS=$'\t' read -r repo_exists details <<< "$(add_repo_left_behind_advice "${github_org}" "${github_repo}" "${details}")"
  fi

  printf '[%s] [%s] %s\n' "$(date)" "${outcome}" "${details}"
  write_issue_fragment "${log_file}" "${outcome}" "${migration_id}" "${phase}" "${minutes}" "${state}" "${repo_exists}" "${details}"
  return "${rc}"
}

# gh-ado2gh exited without a final verdict in its log (no "State: SUCCEEDED",
# no "No operation will be performed"): it crashed, was OOM-killed, hit a
# network error, or its wording changed. The migration may still be running
# on GitHub, so ask GitHub before calling it a failure. A still-running
# migration is watched via the API under the same deadlines as the watchdog
# (counted from the original start), and aborted at the deadline.
# Args: github_org github_repo log_file job_start_epoch in_progress_since gh_rc
# Return: 0 = SUCCEEDED on GitHub, 1 = failed (or never started on GitHub),
#         2/3 = deadline reached (see handle_migration_timeout),
#         4 = GitHub state unreadable; may still be running
reconcile_after_client_exit() {
  local github_org="$1" github_repo="$2" log_file="$3" job_start="$4" in_progress_since="$5" gh_rc="$6"
  local migration_id state="" reason="" unknown=0 now announced=false repo_exists details

  migration_id="$(resolve_migration_id "${github_org}" "${github_repo}" "${log_file}" "${job_start}")"
  if [[ -z "${migration_id}" ]]; then
    printf '[%s] [INFO] migrate-repo exited (code %s); no migration was started on GitHub\n' "$(date)" "${gh_rc}"
    return 1
  fi
  printf '[%s] [WARNING] migrate-repo exited (code %s) without a final result; checking migration %s on GitHub\n' \
    "$(date)" "${gh_rc}" "${migration_id}"

  while true; do
    IFS=$'\t' read -r state reason <<< "$(get_migration_state "${migration_id}")"
    now=$(date +%s)
    case "${state}" in
      SUCCEEDED)
        details="migrate-repo exited with code ${gh_rc} but GitHub reports the migration SUCCEEDED; counted as Success"
        printf '[%s] [CLIENT_EXITED_SUCCEEDED] %s\n' "$(date)" "${details}"
        write_issue_fragment "${log_file}" "CLIENT_EXITED_SUCCEEDED" "${migration_id}" "CLIENT_EXITED" \
          "$(( (now - job_start) / 60 ))" "${state}" "" "${details}"
        return 0;;
      FAILED|FAILED_VALIDATION)
        printf '[%s] [INFO] GitHub reports migration %s %s%s\n' "$(date)" "${migration_id}" "${state}" "${reason:+: ${reason}}"
        return 1;;
      "")
        (( ++unknown ))
        printf '[%s] [WARNING] Could not read the state of migration %s from GitHub (%s/%s)\n' \
          "$(date)" "${migration_id}" "${unknown}" "${RECONCILE_MAX_UNKNOWN}"
        if (( unknown >= RECONCILE_MAX_UNKNOWN )); then
          details="migrate-repo exited with code ${gh_rc} and GitHub's migration state could not be read; it may still be running. Check the migration ID on GitHub and abort it if it is"
          IFS=$'\t' read -r repo_exists details <<< "$(add_repo_left_behind_advice "${github_org}" "${github_repo}" "${details}")"
          printf '[%s] [CLIENT_EXITED_UNVERIFIED] %s\n' "$(date)" "${details}"
          write_issue_fragment "${log_file}" "CLIENT_EXITED_UNVERIFIED" "${migration_id}" "CLIENT_EXITED" \
            "$(( (now - job_start) / 60 ))" "" "${repo_exists}" "${details}"
          return 4
        fi;;
      *)
        unknown=0
        if [[ "${state}" == "IN_PROGRESS" && -z "${in_progress_since}" ]]; then
          in_progress_since=${now}
          printf '[%s] [INFO] GitHub reports IN_PROGRESS; %s-minute timeout starts now\n' "$(date)" "${MIGRATION_TIMEOUT_MINUTES}"
        fi
        if [[ "${announced}" == false ]]; then
          announced=true
          printf '[%s] [INFO] Migration %s is still %s on GitHub; watching it via the API every %s s\n' \
            "$(date)" "${migration_id}" "${state}" "${RECONCILE_POLL_SECONDS}"
        fi;;
    esac

    # Same deadlines as the watchdog in migrate_repository
    if [[ -n "${in_progress_since}" ]] && (( now - in_progress_since >= MIGRATION_TIMEOUT_MINUTES * 60 )); then
      printf '[%s] [WARNING] TIMEOUT: %s minutes in phase IN_PROGRESS (watched via the API)\n' "$(date)" "$(( (now - in_progress_since) / 60 ))"
      handle_migration_timeout "${github_org}" "${github_repo}" "${log_file}" "IN_PROGRESS" "$(( (now - in_progress_since) / 60 ))" "${job_start}"
      return $?
    elif [[ -z "${in_progress_since}" ]] && (( now - job_start >= QUEUE_TIMEOUT_MINUTES * 60 )); then
      printf '[%s] [WARNING] TIMEOUT: %s minutes in phase NOT_STARTED (watched via the API)\n' "$(date)" "$(( (now - job_start) / 60 ))"
      handle_migration_timeout "${github_org}" "${github_repo}" "${log_file}" "NOT_STARTED" "$(( (now - job_start) / 60 ))" "${job_start}"
      return $?
    fi
    sleep "${RECONCILE_POLL_SECONDS}"
  done
}

############################################
# Migration function (no console noise)
############################################
# Return: 0 success, 1 failed, 2 timed out + aborted, 3 timed out + abort unconfirmed,
#         4 gh-ado2gh exited early and GitHub's state could not be read
migrate_repository() {
  local ado_org="$1" ado_team_project="$2" ado_repo="$3"
  local github_org="$4" github_repo="$5" gh_repo_visibility="$6"
  local log_file="$7"
  local job_start now gh_pid gh_rc in_progress_since="" timed_out=false phase="" minutes=0
  local queue_deadline_checked=false q_id q_state

  {
    printf '[%s] [START] Migration: %s/%s -> %s/%s (gh_repo_visibility: %s)\n' \
      "$(date)" "${ado_team_project}" "${ado_repo}" "${github_org}" "${github_repo}" "${gh_repo_visibility}"

    printf '[%s] [DEBUG] Running: gh ado2gh migrate-repo --ado-org %s --ado-team-project %s --ado-repo %s --github-org %s --github-repo %s --target-repo-visibility %s\n' \
      "$(date)" "${ado_org}" "${ado_team_project}" "${ado_repo}" "${github_org}" "${github_repo}" "${gh_repo_visibility}"

    # Run migration: append output ONLY to log file (no tee to stdout).
    # Not --foreground: timeout must own a process group so stopping it also
    # kills the gh-ado2gh child process, not just gh.
    job_start=$(date +%s)
    timeout --kill-after=60 "${HARD_CAP_SECONDS}" gh ado2gh migrate-repo \
      --ado-org "${ado_org}" \
      --ado-team-project "${ado_team_project}" \
      --ado-repo "${ado_repo}" \
      --github-org "${github_org}" \
      --github-repo "${github_repo}" \
      --target-repo-visibility "${gh_repo_visibility}" >>"${log_file}" 2>&1 &
    gh_pid=$!
    # For the parent's cancel handler: timeout's pid = its process group
    printf '%s\n' "${gh_pid}" > "${log_file}.pid"

    # Watchdog: the timeout clock starts when GitHub reports IN_PROGRESS;
    # before that, the queue timeout applies (counted from job start).
    while kill -0 "${gh_pid}" 2>/dev/null; do
      now=$(date +%s)
      if [[ -z "${in_progress_since}" ]] && grep -q "State: IN_PROGRESS" "${log_file}"; then
        in_progress_since=${now}
        printf '[%s] [INFO] GitHub started the migration (IN_PROGRESS); %s-minute timeout starts now\n' \
          "$(date)" "${MIGRATION_TIMEOUT_MINUTES}"
      fi
      if [[ -n "${in_progress_since}" ]]; then
        if (( now - in_progress_since >= MIGRATION_TIMEOUT_MINUTES * 60 )); then
          timed_out=true; phase="IN_PROGRESS"; minutes=$(( (now - in_progress_since) / 60 ))
        fi
      elif (( now - job_start >= QUEUE_TIMEOUT_MINUTES * 60 )); then
        # The IN_PROGRESS clock depends on gh-ado2gh's log text. Before
        # treating this as "never started", ask GitHub: if it is IN_PROGRESS
        # (e.g. the log wording changed), start the timeout now instead.
        if [[ "${queue_deadline_checked}" == false ]]; then
          queue_deadline_checked=true
          q_id="$(resolve_migration_id "${github_org}" "${github_repo}" "${log_file}" "${job_start}")"
          q_state=""
          [[ -n "${q_id}" ]] && q_state="$(get_migration_state "${q_id}" | cut -f1)"
          printf '[%s] [INFO] Queue timeout reached; GitHub state of %s: %s\n' \
            "$(date)" "${q_id:-<no migration ID>}" "${q_state:-UNKNOWN}"
          if [[ "${q_state}" == "IN_PROGRESS" ]]; then
            in_progress_since=$(date +%s)
            printf '[%s] [WARNING] Log never showed IN_PROGRESS but GitHub does; %s-minute timeout starts now\n' \
              "$(date)" "${MIGRATION_TIMEOUT_MINUTES}"
            continue
          fi
        fi
        timed_out=true; phase="NOT_STARTED"; minutes=$(( (now - job_start) / 60 ))
      fi
      if [[ "${timed_out}" == true ]]; then
        printf '[%s] [WARNING] TIMEOUT: %s minutes in phase %s; stopping migrate-repo\n' "$(date)" "${minutes}" "${phase}"
        is_our_timeout_process "${gh_pid}" && kill -TERM "${gh_pid}" 2>/dev/null
        break
      fi
      sleep "${WATCHDOG_INTERVAL_SECONDS}"
    done
    wait "${gh_pid}"
    gh_rc=$?
    rm -f "${log_file}.pid"

    # Hard cap hit (watchdog did not fire): treat as a timeout as well. The
    # elapsed check keeps an unrelated KILL (e.g. OOM, also 137) a plain failure.
    if [[ "${timed_out}" == false ]] && (( gh_rc == 124 || gh_rc == 137 )) \
       && (( $(date +%s) - job_start >= HARD_CAP_SECONDS )); then
      timed_out=true; phase="HARD_CAP"; minutes=$(( ($(date +%s) - job_start) / 60 ))
      printf '[%s] [WARNING] TIMEOUT: migrate-repo hit the %s-second hard cap\n' "$(date)" "${HARD_CAP_SECONDS}"
    fi

    # timeout returns as soon as gh dies; a gh-ado2gh child that ignored TERM
    # would survive. timeout led its own process group (pgid = its pid), so
    # KILL whatever is left of that group.
    if [[ "${timed_out}" == true ]]; then
      kill -KILL -- "-${gh_pid}" 2>/dev/null && \
        printf '[%s] [WARNING] Killed leftover migrate-repo processes\n' "$(date)"
    fi

    if [[ "${timed_out}" == true ]] && ! grep -q "State: SUCCEEDED" "${log_file}"; then
      handle_migration_timeout "${github_org}" "${github_repo}" "${log_file}" "${phase}" "${minutes}" "${job_start}"
      local t_rc=$?
      if (( t_rc == 0 )); then
        printf '[%s] [SUCCESS] Migration: %s/%s -> %s/%s\n' \
          "$(date)" "${ado_team_project}" "${ado_repo}" "${github_org}" "${github_repo}"
      fi
      return "${t_rc}"
    fi

    # Assess log content
    if grep -q "No operation will be performed" "${log_file}"; then
      printf '[%s] [FAILED] No operation performed - repository may already exist or migration was skipped\n' "$(date)" >> "${log_file}"
      return 1
    fi
    if ! grep -q "State: SUCCEEDED" "${log_file}"; then
      # No verdict in the log: GitHub decides (the migration may still be running)
      reconcile_after_client_exit "${github_org}" "${github_repo}" "${log_file}" "${job_start}" "${in_progress_since}" "${gh_rc}"
      local r_rc=$?
      case "${r_rc}" in
        0) ;;  # SUCCEEDED on GitHub: fall through to the success line
        1) printf '[%s] [FAILED] Migration did not reach SUCCEEDED state\n' "$(date)"
           return 1;;
        *) return "${r_rc}";;
      esac
    fi

    printf '[%s] [SUCCESS] Migration: %s/%s -> %s/%s\n' \
      "$(date)" "${ado_team_project}" "${ado_repo}" "${github_org}" "${github_repo}" >> "${log_file}"
    return 0
  } >> "${log_file}" 2>&1
}

############################################
# Queues and tracking
############################################
declare -A JOB_PIDS=()      # pid -> "org,teamproject,repo,github_org,github_repo,gh_repo_visibility"
declare -A JOB_LOGS=()      # pid -> log file
declare -A JOB_REPOS=()     # pid -> github_repo
declare -A JOB_LASTLEN=()   # pid -> last printed length
declare -A JOB_STARTS=()    # pid -> start epoch (for the cancel handler's ID lookup)

QUEUE=()
MIGRATED=()
FAILED=()
TIMED_OUT_COUNT=0
CIRCUIT_BREAKER_TRIPPED=false

############################################
# repos-migration-status.csv (downstream contract)
############################################
STATUS_CSV="repos-migration-status.csv"

# Writes every repo: Success for the migrated ones, Failed for the rest
# (failed, in flight or not started). Called after every completed repo so a
# cancelled run still publishes a correct file; at the end of a normal run the
# output matches the previous end-of-run format.
# Each item is already "org,teamproject,repo,github_org,github_repo,visibility",
# so a row is just "<item>,<status>".
write_repos_migration_status_csv() {
  local tmp="${STATUS_CSV}.tmp" item
  local -A succeeded=()
  {
    echo "org,teamproject,repo,github_org,github_repo,gh_repo_visibility,migration_status"
    for item in "${MIGRATED[@]}"; do
      succeeded["${item}"]=1
      printf '%s,Success\n' "${item}"
    done
    for item in "${ALL_ITEMS[@]}"; do
      [[ -n "${succeeded[${item}]:-}" ]] && continue
      printf '%s,Failed\n' "${item}"
    done
  } > "${tmp}"
  mv "${tmp}" "${STATUS_CSV}"
}

############################################
# Load queue from CSV rows (skip header)
############################################
LINE_NUM=0
while IFS= read -r line; do
  ((LINE_NUM++))
  [[ ${LINE_NUM} -eq 1 ]] && continue

  mapfile -t F < <(parse_csv_line "${line}")
  # Pull required columns by header indices (robust to column order)
  org="${F[${COLIDX[org]}]}"
  teamproject="${F[${COLIDX[teamproject]}]}"
  repo="${F[${COLIDX[repo]}]}"
  github_org="${F[${COLIDX[github_org]}]}"
  github_repo="${F[${COLIDX[github_repo]}]}"
  gh_repo_visibility="${F[${COLIDX[gh_repo_visibility]}]}"

  # Trim quotes (single pair)
  org="$(strip_quotes "$org")"
  teamproject="$(strip_quotes "$teamproject")"
  repo="$(strip_quotes "$repo")"
  github_org="$(strip_quotes "$github_org")"
  github_repo="$(strip_quotes "$github_repo")"
  gh_repo_visibility="$(strip_quotes "$gh_repo_visibility")"

  # Basic presence check
  if [[ -z "${github_org}" || -z "${github_repo}" || -z "${gh_repo_visibility}" ]]; then
    echo "[WARNING] Skipping malformed line ${LINE_NUM}: missing target columns"
    echo "Migration will be skipped. Please ensure github_org, github_repo and gh_repo_visibility are populated."
    exit 1
  fi

  QUEUE+=("${org},${teamproject},${repo},${github_org},${github_repo},${gh_repo_visibility}")
done < "${CSV_PATH}"

# --- Initialize output CSV with Pending ---

for item in "${QUEUE[@]}"; do
  IFS=',' read -r org teamproject repo github_org github_repo gh_repo_visibility <<< "${item}"
  add_status_row "${org}" "${teamproject}" "${repo}" "${github_org}" "${github_repo}" "${gh_repo_visibility}" "Pending" ""
done
write_migration_status_csv

ALL_ITEMS=("${QUEUE[@]}")
write_repos_migration_status_csv
write_timeouts_csv_header

echo "[INFO] Starting migration with ${MAX_CONCURRENT} concurrent jobs (hardcoded for optimal performance)..."
echo "[INFO] Processing ${#QUEUE[@]} repositories from: ${CSV_PATH}"
echo "[INFO] Per-repo timeout: ${MIGRATION_TIMEOUT_MINUTES} min IN_PROGRESS on GitHub, ${QUEUE_TIMEOUT_MINUTES} min to start (no retries)"
if (( CIRCUIT_BREAKER_THRESHOLD > 0 )); then
  echo "[INFO] Circuit breaker: no new migrations start after ${CIRCUIT_BREAKER_THRESHOLD} timeouts"
else
  echo "[INFO] Circuit breaker: disabled"
fi
echo "[INFO] Initialized migration status output: ${OUTPUT_CSV_PATH}"

############################################
# Status bar (PS-style width stabilization)
############################################
STATUS_LINE_WIDTH=0
show_status_bar() {
  local queue_count=${#QUEUE[@]}
  local progress_count=${#JOB_PIDS[@]}
  local migrated_count=${#MIGRATED[@]}
  local failed_count=${#FAILED[@]}

  local status="QUEUE: ${queue_count} | IN PROGRESS: ${progress_count} | MIGRATED: ${migrated_count} | MIGRATION FAILED: ${failed_count}"
  (( ${#status} > STATUS_LINE_WIDTH )) && STATUS_LINE_WIDTH=${#status}
  printf "\r\033[36m%-${STATUS_LINE_WIDTH}s\033[0m" "${status}"
}

############################################
# Stage cancelled: abort in-flight migrations on GitHub
############################################
# On cancel, the Bash@3 task forwards SIGINT to this script, the agent sends
# SIGTERM 7.5 s later and kills the process tree 2.5 s after that (agent
# ProcessInvoker defaults). Without this, a migration keeps running on GitHub
# after a cancel (2026-10-01: ~8 h until GitHub aborted it). The abort calls
# run detached (setsid) so they survive that kill; the script waits for them
# at most CANCEL_WAIT_SECONDS after the signal, to show their result, then exits.

# Background part of the cancel handler: find the migration ID if the log had
# none, abort it, log the result. Args: github_org github_repo migration_id log_file job_start
abort_migration_detached() {
  local runner=()
  command -v setsid >/dev/null 2>&1 && runner=(setsid)
  "${runner[@]}" bash -c '
    id="$3"
    [[ -z "${id}" ]] && id="$(find_migration_id "$1" "$2" "$(date -u -d "@$(( $5 - 120 ))" +%Y-%m-%dT%H:%M:%SZ)")"
    if [[ -z "${id}" ]]; then
      echo "[$(date)] [CANCELLED] Stage cancelled: no migration found on GitHub, nothing to abort"
      exit 0
    fi
    echo "[$(date)] [CANCELLED] Stage cancelled: aborting migration ${id} on GitHub"
    timeout --kill-after=10 60 gh ado2gh abort-migration --migration-id "${id}"
    echo "[$(date)] [CANCELLED] abort-migration exit code: $?"
  ' _ "$1" "$2" "$3" "$4" "$5" >> "$4" 2>&1 < /dev/null &
  CANCEL_ABORT_PIDS+=($!)
}

CANCEL_ABORT_PIDS=()
# A signal that arrives while a job is being started or its result recorded
# is handled right after, so the cancel handler never sees a half-updated job.
IN_CRITICAL_SECTION=false
PENDING_SIGNAL=""
on_signal() {
  if [[ "${IN_CRITICAL_SECTION}" == true ]]; then PENDING_SIGNAL="$1"; return; fi
  on_cancel "$1"
}
end_critical_section() {
  IN_CRITICAL_SECTION=false
  [[ -n "${PENDING_SIGNAL}" ]] && on_cancel "${PENDING_SIGNAL}"
}

on_cancel() {
  # Swallow the follow-up SIGTERM while aborting. A no-op handler, not
  # trap '' (ignored signals are inherited, so the abort calls could not be stopped).
  trap ':' INT TERM HUP
  local sig="$1" handler_start pid log repo_info org tp repo gh_org gh_repo vis result gh_group i deadline running
  local -a to_abort=()
  local -A abort_ids=() cancelled_logs=()
  handler_start=$(date +%s)
  echo ""
  echo "##[warning]Stage cancelled (SIG${sig}): stopping ${#JOB_PIDS[@]} running migration(s) and aborting them on GitHub"
  export -f find_migration_id
  export GH_CALL_TIMEOUT_SECONDS

  # 1. Stop every local job (frees the agent's CPU for the aborts). Jobs that
  #    finished but were not collected yet keep their result.
  for pid in "${!JOB_PIDS[@]}"; do
    log="${JOB_LOGS[$pid]}"
    if [[ -f "${log}.result" ]]; then
      repo_info="${JOB_PIDS[$pid]}"
      IFS=',' read -r org tp repo gh_org gh_repo vis <<< "${repo_info}"
      result="$(<"${log}.result")"
      [[ "${result}" == "SUCCESS" ]] && MIGRATED+=("${repo_info}")
      if [[ -f "${log}.timeout" ]]; then
        printf '%s,%s,%s,%s,%s,%s\n' "$(csv_quote "${org}")" "$(csv_quote "${tp}")" "$(csv_quote "${repo}")" \
          "$(csv_quote "${gh_org}")" "$(csv_quote "${gh_repo}")" "$(<"${log}.timeout")" >> "${TIMEOUTS_CSV}"
      fi
      continue
    fi
    kill -TERM "${pid}" 2>/dev/null
    if [[ -f "${log}.pid" ]]; then
      gh_group="$(<"${log}.pid")"
      is_our_timeout_process "${gh_group}" && kill -KILL -- "-${gh_group}" 2>/dev/null
    fi
    to_abort+=("${pid}")
  done

  # 2. Start every abort at once; they run on GitHub's side, in parallel
  for pid in "${to_abort[@]}"; do
    log="${JOB_LOGS[$pid]}"
    IFS=',' read -r org tp repo gh_org gh_repo vis <<< "${JOB_PIDS[$pid]}"
    abort_ids[$pid]="$(grep -oE '\(ID: RM_[A-Za-z0-9_-]+\)' "${log}" 2>/dev/null | tail -n 1 | sed -E 's/^\(ID: //; s/\)$//')"
    abort_migration_detached "${gh_org}" "${gh_repo}" "${abort_ids[$pid]}" "${log}" "${JOB_STARTS[$pid]}"
  done

  # 3. Bookkeeping: report rows, per-run CSV (one write), status CSV
  for pid in "${to_abort[@]}"; do
    log="${JOB_LOGS[$pid]}"
    IFS=',' read -r org tp repo gh_org gh_repo vis <<< "${JOB_PIDS[$pid]}"
    cancelled_logs["${gh_repo}"]="${log}"
    echo "##[warning]CANCELLED: ${gh_org}/${gh_repo}: abort requested on GitHub (migration ${abort_ids[$pid]:-ID being looked up})"
    printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' "$(csv_quote "${org}")" "$(csv_quote "${tp}")" "$(csv_quote "${repo}")" \
      "$(csv_quote "${gh_org}")" "$(csv_quote "${gh_repo}")" '"CANCELLED_ABORT_REQUESTED"' "$(csv_quote "${abort_ids[$pid]}")" '"CANCELLED"' \
      "$(csv_quote "$(( (handler_start - ${JOB_STARTS[$pid]:-${handler_start}}) / 60 ))")" '""' '""' \
      "$(csv_quote "Stage cancelled: abort requested on GitHub, not verified (result at the end of this repo's log). Check the migration on GitHub, and delete any partial repo before re-running")" \
      >> "${TIMEOUTS_CSV}"
  done
  for i in "${!RUN_ROW_GH_REPO[@]}"; do
    if [[ -n "${cancelled_logs[${RUN_ROW_GH_REPO[$i]}]:-}" ]]; then
      RUN_ROW_STATUS[$i]="Cancelled"; RUN_ROW_LOG[$i]="${cancelled_logs[${RUN_ROW_GH_REPO[$i]}]}"
    fi
  done
  for pid in "${!JOB_PIDS[@]}"; do
    [[ -f "${JOB_LOGS[$pid]}.result" && "$(<"${JOB_LOGS[$pid]}.result")" == "SUCCESS" ]] || continue
    for i in "${!RUN_ROW_GH_REPO[@]}"; do
      [[ "${RUN_ROW_GH_REPO[$i]}" == "${JOB_REPOS[$pid]}" ]] && { RUN_ROW_STATUS[$i]="Success"; RUN_ROW_LOG[$i]="${JOB_LOGS[$pid]}"; }
    done
  done
  mark_pending_rows_not_started   # also writes the per-run CSV
  write_repos_migration_status_csv

  # 4. Show the abort results that arrive in time. Counted from the signal:
  #    ADO sends SIGTERM at 7.5 s and kills the process tree at 10 s.
  deadline=$(( handler_start + CANCEL_WAIT_SECONDS ))
  while (( $(date +%s) < deadline )); do
    running=false
    for pid in "${CANCEL_ABORT_PIDS[@]}"; do kill -0 "${pid}" 2>/dev/null && running=true; done
    [[ "${running}" == false ]] && break
    sleep 0.5
  done
  for pid in "${to_abort[@]}"; do
    grep -h '\[CANCELLED\]' "${JOB_LOGS[$pid]}" 2>/dev/null
  done
  running=false
  for pid in "${CANCEL_ABORT_PIDS[@]}"; do kill -0 "${pid}" 2>/dev/null && running=true; done
  if [[ "${running}" == true ]]; then
    echo "##[warning]Some abort calls were still running when the stage stopped; they continue in the background. Check those migrations on GitHub"
  fi

  echo "##vso[task.logissue type=warning]Stage cancelled: abort requested on GitHub for ${#to_abort[@]} in-flight migration(s); check them on GitHub and delete partial repos before re-running (see ${TIMEOUTS_CSV})"
  case "${sig}" in
    INT) exit 130;;
    HUP) exit 129;;
    *)   exit 143;;
  esac
}
trap 'on_signal INT' INT
trap 'on_signal TERM' TERM
trap 'on_signal HUP' HUP

############################################
# Main loop
############################################
while (( ${#QUEUE[@]} > 0 )) || (( ${#JOB_PIDS[@]} > 0 )); do

  # Start new jobs up to concurrency
  while (( ${#JOB_PIDS[@]} < MAX_CONCURRENT )) && (( ${#QUEUE[@]} > 0 )); do
    IN_CRITICAL_SECTION=true
    repo_info="${QUEUE[0]}"
    QUEUE=("${QUEUE[@]:1}")

    IFS=',' read -r ado_org ado_team_project ado_repo github_org github_repo gh_repo_visibility <<< "${repo_info}"
    log_file="migration-${github_repo}-$(date +%Y%m%d-%H%M%S).txt"

    # Update CSV with "In Progress" + log file
    update_repo_status_in_csv "${github_repo}" "In Progress" "${log_file}"

    # Start background job: no console output, only log + .result
    (
      migrate_repository "${ado_org}" "${ado_team_project}" "${ado_repo}" "${github_org}" "${github_repo}" "${gh_repo_visibility}" "${log_file}"
      case $? in
        0) echo "SUCCESS" > "${log_file}.result";;
        2) echo "TIMEOUT_ABORTED" > "${log_file}.result";;
        3) echo "TIMEOUT_ABORT_UNCONFIRMED" > "${log_file}.result";;
        4) echo "UNVERIFIED" > "${log_file}.result";;
        *) echo "FAILED" > "${log_file}.result";;
      esac
    ) &

    pid=$!
    JOB_PIDS["$pid"]="${repo_info}"
    JOB_LOGS["$pid"]="${log_file}"
    JOB_REPOS["$pid"]="${github_repo}"
    JOB_LASTLEN["$pid"]=0
    JOB_STARTS["$pid"]=$(date +%s)
    end_critical_section

    show_status_bar
  done

  # Stream new log content from each job (delta only)
  for pid in "${!JOB_PIDS[@]}"; do
    log="${JOB_LOGS[$pid]}"
    last="${JOB_LASTLEN[$pid]}"
    if [[ -f "${log}" ]]; then
      new_len=$(wc -c < "${log}")
      if (( new_len > last )); then
        delta_bytes=$(( new_len - last ))
        # Print the new portion only (trim CRs)
        echo ""  # break the status line once
        tail -c "${delta_bytes}" "${log}" | tr -d '\r' | while IFS= read -r l; do
          [[ -n "${l}" ]] && echo "${l}"
        done
        JOB_LASTLEN["$pid"]="${new_len}"
        show_status_bar
      fi
    fi
  done

  # Check completed jobs (use ps to avoid reused PID false-positives)
  for pid in "${!JOB_PIDS[@]}"; do
    if ! ps -p "${pid}" > /dev/null 2>&1; then
      IN_CRITICAL_SECTION=true
      repo_info="${JOB_PIDS[$pid]}"
      log_file="${JOB_LOGS[$pid]}"
      github_repo="${JOB_REPOS[$pid]}"

      result="FAILED"
      if [[ -f "${log_file}.result" ]]; then
        result="$(<"${log_file}.result")"
        rm -f "${log_file}.result"
      fi

      case "${result}" in
        SUCCESS)
          MIGRATED+=("${repo_info}")
          update_repo_status_in_csv "${github_repo}" "Success" "${log_file}";;
        TIMEOUT_ABORTED|TIMEOUT_ABORT_UNCONFIRMED)
          FAILED+=("${repo_info}")
          ((TIMED_OUT_COUNT++))
          update_repo_status_in_csv "${github_repo}" "Timeout" "${log_file}";;
        UNVERIFIED)
          FAILED+=("${repo_info}")
          update_repo_status_in_csv "${github_repo}" "Unverified" "${log_file}";;
        *)
          FAILED+=("${repo_info}")
          update_repo_status_in_csv "${github_repo}" "Failure" "${log_file}";;
      esac

      # Timeout / early-exit details (also written when it ended SUCCEEDED)
      if [[ -f "${log_file}.timeout" ]]; then
        IFS=',' read -r org tp repo gh_org gh_repo vis <<< "${repo_info}"
        printf '%s,%s,%s,%s,%s,%s\n' "$(csv_quote "${org}")" "$(csv_quote "${tp}")" "$(csv_quote "${repo}")" \
          "$(csv_quote "${gh_org}")" "$(csv_quote "${gh_repo}")" "$(<"${log_file}.timeout")" >> "${TIMEOUTS_CSV}"
        outcome="$(cut -d, -f1 "${log_file}.timeout" | tr -d '"')"
        rm -f "${log_file}.timeout"
        echo ""
        case "${outcome}" in
          TIMEOUT_ABORTED)
            echo "##vso[task.logissue type=warning]TIMEOUT: ${gh_org}/${gh_repo} exceeded its time limit and was aborted on GitHub; marked Failed. GitHub keeps the partial repo after an abort: delete it before re-running (see ${TIMEOUTS_CSV})";;
          TIMEOUT_ABORT_UNCONFIRMED)
            echo "##[error]TIMEOUT: ${gh_org}/${gh_repo} abort NOT confirmed - the migration may still be running on GitHub"
            echo "##vso[task.logissue type=warning]ACTION REQUIRED: ${gh_org}/${gh_repo} timed out and the abort could not be confirmed; escalate its migration ID to GitHub, and delete the GitHub repo before re-running (see ${TIMEOUTS_CSV})";;
          SUCCEEDED_AFTER_TIMEOUT)
            echo "##vso[task.logissue type=warning]${gh_org}/${gh_repo} hit its time limit but GitHub reports it SUCCEEDED; counted as Success";;
          CLIENT_EXITED_SUCCEEDED)
            echo "##vso[task.logissue type=warning]${gh_org}/${gh_repo}: gh-ado2gh exited early but GitHub reports the migration SUCCEEDED; counted as Success";;
          CLIENT_EXITED_UNVERIFIED)
            echo "##[error]${gh_org}/${gh_repo}: gh-ado2gh exited early and GitHub's migration state could not be read - it may still be running"
            echo "##vso[task.logissue type=warning]ACTION REQUIRED: ${gh_org}/${gh_repo} marked Failed but its migration may still be running on GitHub; check its migration ID (abort it if running) and delete the GitHub repo before re-running (see ${TIMEOUTS_CSV})";;
        esac
      fi

      unset JOB_PIDS["$pid"] JOB_LOGS["$pid"] JOB_REPOS["$pid"] JOB_LASTLEN["$pid"] JOB_STARTS["$pid"]
      write_repos_migration_status_csv
      end_critical_section
      show_status_bar
    fi
  done

  # Circuit breaker: repeated timeouts mean GitHub is likely degraded; stop
  # starting new migrations and let the in-flight ones finish. Only trips while
  # something is still queued (nothing to hold back otherwise).
  if (( CIRCUIT_BREAKER_THRESHOLD > 0 && TIMED_OUT_COUNT >= CIRCUIT_BREAKER_THRESHOLD && ${#QUEUE[@]} > 0 )) \
     && [[ "${CIRCUIT_BREAKER_TRIPPED}" == false ]]; then
    CIRCUIT_BREAKER_TRIPPED=true
    echo ""
    echo "##[error]CIRCUIT BREAKER: ${TIMED_OUT_COUNT} repositories timed out; no new migrations will start. ${#QUEUE[@]} queued repositories marked Failed (not started)"
    echo "##vso[task.logissue type=warning]Circuit breaker tripped after ${TIMED_OUT_COUNT} timeouts: ${#QUEUE[@]} repositories were not started (see ${TIMEOUTS_CSV})"
    mark_pending_rows_not_started
    for item in "${QUEUE[@]}"; do
      FAILED+=("${item}")
      IFS=',' read -r org tp repo gh_org gh_repo vis <<< "${item}"
      printf '%s,%s,%s,%s,%s,%s,"","","","","","Not started: circuit breaker tripped after %s timeouts"\n' \
        "$(csv_quote "${org}")" "$(csv_quote "${tp}")" "$(csv_quote "${repo}")" \
        "$(csv_quote "${gh_org}")" "$(csv_quote "${gh_repo}")" '"NOT_STARTED_CIRCUIT_BREAKER"' \
        "${TIMED_OUT_COUNT}" >> "${TIMEOUTS_CSV}"
    done
    QUEUE=()
    write_repos_migration_status_csv
    show_status_bar
  fi

  # Background + wait, so a cancel signal is handled at once (not after sleep)
  sleep 2 &
  wait $!
done

echo
echo "[INFO] All migrations completed."
total_repos=$(( $(wc -l < "${CSV_PATH}") - 1 ))
echo "[SUMMARY] Total: ${total_repos} | Migrated: ${#MIGRATED[@]} | Failed: ${#FAILED[@]} | Timed out: ${TIMED_OUT_COUNT}"
echo "[INFO] Wrote migration results with Migration_Status column: ${OUTPUT_CSV_PATH}"
if (( $(wc -l < "${TIMEOUTS_CSV}") > 1 )); then
  echo "##[section]Timeouts, early exits and not-started repositories (${TIMEOUTS_CSV}):"
  tail -n +2 "${TIMEOUTS_CSV}"
fi
if [[ "${CIRCUIT_BREAKER_TRIPPED}" == true ]]; then
  echo "##[warning]Circuit breaker tripped: re-run the NOT_STARTED_CIRCUIT_BREAKER repositories in a later wave"
fi

# Report failures but allow pipeline to continue
if (( ${#FAILED[@]} > 0 )); then
  echo ""
  echo "##[warning]Migration completed with ${#FAILED[@]} failures"
  echo "##[section]Failed Repositories:"
  for repo in "${FAILED[@]}"; do
    echo "##[warning]  ⚠️ $repo"
  done
  echo "##vso[task.logissue type=warning]${#FAILED[@]} of ${total_repos} repositories failed to migrate"
  
  # Add partial success indicator when there are both successes and failures
  if (( ${#MIGRATED[@]} > 0 )); then
    echo "##[warning]⚠️ Stage completed with PARTIAL SUCCESS: ${#MIGRATED[@]} succeeded, ${#FAILED[@]} failed"
  fi
fi

echo -e "\033[32m[SUCCESS] ${#MIGRATED[@]} of ${total_repos} repositories migrated successfully\033[0m"

# --- Generate repos-migration-status.csv ---

echo "##[section]📄 Generating repos-migration-status.csv for downstream stages..."

write_repos_migration_status_csv

echo "##[section]✅ Generated ${STATUS_CSV} with ${#MIGRATED[@]} successful and ${#FAILED[@]} failed repositories"

# --- Exit with appropriate status ---

if (( ${#FAILED[@]} == 0 )); then
  # All successful
  echo "##[section]✅ All repositories migrated successfully"
  exit 0
  
elif (( ${#MIGRATED[@]} == 0 )); then
  # All failed
  echo "##[error]❌ All repositories failed to migrate"
  echo "##[error]Migration failed: All $total_repos repository(ies) encountered errors"
  echo "##vso[task.logissue type=error]All repositories failed to migrate"
  exit 1
  
else
  # Partial success - some succeeded, some failed
  echo "##[warning]⚠️ Migration completed with PARTIAL SUCCESS: ${#MIGRATED[@]} succeeded, ${#FAILED[@]} failed"
  echo "##vso[task.logissue type=warning]Partial success: ${#MIGRATED[@]} succeeded, ${#FAILED[@]} failed"
  
  # Set task result to SucceededWithIssues and exit successfully
  echo "##vso[task.complete result=SucceededWithIssues]Migration completed with partial success"
  exit 0
fi
