#!/usr/bin/env bash
# Disable ADO repositories after successful migration + pipeline rewiring.
# Pipeline-integrated sibling of misc/6_disable_repo.sh (which stays untouched for
# manual use against misc/disable_repo.csv). This variant reads repos-migration-status.csv
# directly (the migration-results artifact), disables only rows where
# migration_status=Success, and writes the outcome back into a "disabled" (0/1) column
# so the artifact can be republished with disable status alongside migration status.
#
# Disables run concurrently (bounded background jobs), same pattern as bash/2_migration.sh,
# bash/4_rewire_pipeline.sh, and bash/3_post_migration_validation.sh. Override the default
# via DISABLE_MAX_CONCURRENT.
#
# Calls the ADO REST API directly instead of `gh ado2gh disable-ado-repo`: gh-ado2gh's
# DisableRepoCommandHandler downloads the project's full repository list (GetRepos - ~26 MB /
# ~20k repos in "Vicepresidencia Servicios de Tecnología") on every invocation just to find
# one repo's id, i.e. ~43 GB of heavy ADO queries for a 1.6k-repo batch - the kind of load
# that gets an identity throttled. Here each repo costs two small calls: GET the repo by name,
# PATCH {"isDisabled": true} (the same call and api-version gh-ado2gh's AdoApi.DisableRepo
# makes). ADO answers 404 for an already-disabled repo (verified 2026-09-24), which by itself
# can't be told apart from "doesn't exist"; only then is the full list fetched - at most once
# per run, shared by every job - to check its isDisabled flag.
#
# Usage: ./6_disable_repo.sh [--csv path/to/repos-migration-status.csv] [--dry-run]
#
# Required columns (any order): org,teamproject,repo,github_org,github_repo,gh_repo_visibility,migration_status
# A pre-existing "disabled" column (e.g. from a prior run) is recomputed, not duplicated.
#
# --dry-run: changes nothing. Looks every candidate repo up in ADO (read-only GETs) and writes
# disable-dry-run-report.csv (org,teamproject,repo,result,repo_id,detail) with one of
# WOULD_DISABLE / ALREADY_DISABLED / NOT_FOUND / ERROR / SKIPPED per row. Any non-GET request is
# refused inside ado_request itself, and the input CSV is read from a normalized copy, never
# rewritten. The input may also be a plain repos.csv (no migration_status column): every row is
# then a candidate - e.g. to check a wave's repos against real ADO before migrating it:
#   ADO_PAT=... ./bash/6_disable_repo.sh --csv bash/repos.csv --dry-run
# Exits 1 if any row is NOT_FOUND or ERROR, so a problem can't go unnoticed.

set -o pipefail

# How many repos to disable concurrently. Override without editing this file by setting
# DISABLE_MAX_CONCURRENT as a pipeline/environment variable.
DISABLE_MAX_CONCURRENT="${DISABLE_MAX_CONCURRENT:-5}"

# Transient failures (HTTP 5xx, timeouts, connection errors) are retried per API call up to
# this many attempts with backoff. Both calls are idempotent (GET, and a PATCH that sets
# isDisabled=true), so retrying is safe.
API_MAX_ATTEMPTS="${API_MAX_ATTEMPTS:-5}"

# ADO throttling (HTTP 429). ADO rate-limits per identity over a sliding 5-minute window and
# its delays stop "within five minutes" of consumption dropping
# (https://learn.microsoft.com/en-us/azure/devops/integrate/concepts/rate-limits), so a job
# that hits a 429 writes a shared "pause until" epoch to RATE_LIMIT_PAUSE_FILE: the main loop
# starts no new jobs and every job waits before its next ADO call until it passes - same
# mechanism as bash/4_rewire_pipeline.sh. Length = ADO's Retry-After, else
# RATE_LIMIT_PAUSE_SECONDS, capped at RATE_LIMIT_MAX_PAUSE_SECONDS. A single call gives up
# after waiting RATE_LIMIT_MAX_WAIT_SECONDS in total on throttling.
RATE_LIMIT_PAUSE_SECONDS="${RATE_LIMIT_PAUSE_SECONDS:-300}"
RATE_LIMIT_MAX_PAUSE_SECONDS="${RATE_LIMIT_MAX_PAUSE_SECONDS:-900}"
RATE_LIMIT_MAX_WAIT_SECONDS="${RATE_LIMIT_MAX_WAIT_SECONDS:-4500}"

# api-version for the PATCH is the one gh-ado2gh's AdoApi.DisableRepo uses in production.
ADO_API_VERSION="7.1"
ADO_DISABLE_API_VERSION="6.1-preview.1"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CSV_PATH="${SCRIPT_DIR}/repos-migration-status.csv"
DRY_RUN=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --csv)
      CSV_PATH="$2"; shift 2;;
    --dry-run)
      DRY_RUN=true; shift;;
    *)
      echo "[ERROR] Unknown option: $1"; exit 1;;
  esac
done

if [[ ! -f "${CSV_PATH}" ]]; then
  echo "[ERROR] CSV file not found: ${CSV_PATH}"
  exit 1
fi

# Normalize CRLF if present (Windows-generated CSV). A real run normalizes the file in place (it
# rewrites it at the end anyway); a dry run must not touch it, so it reads a normalized copy.
INPUT_CSV="${CSV_PATH}"
DRY_INPUT=""
if [[ "$DRY_RUN" == true ]]; then
  DRY_INPUT="$(mktemp)"
  trap 'rm -f "$DRY_INPUT"' EXIT
  sed 's/\r$//' "${CSV_PATH}" > "${DRY_INPUT}"
  INPUT_CSV="${DRY_INPUT}"
else
  sed -i 's/\r$//' "${CSV_PATH}" 2>/dev/null || true
fi

if [[ -z "${ADO_PAT:-}" ]]; then
  echo "[ERROR] ADO_PAT environment variable is not set"
  exit 1
fi
ADO_AUTH_B64="$(printf ":%s" "$ADO_PAT" | base64 -w 0 2>/dev/null || printf ":%s" "$ADO_PAT" | base64 | tr -d '\n')"

# curl + jq do all the work now. Installed on the fly on the self-hosted Linux agent if
# missing (same bootstrap as bash/4_rewire_pipeline.sh), since this stage's YAML doesn't.
for tool in curl jq; do
  command -v "$tool" >/dev/null 2>&1 && continue
  if command -v apt-get >/dev/null 2>&1 && command -v sudo >/dev/null 2>&1; then
    echo "[INFO] '$tool' not found - installing via apt..."
    sudo apt-get update -qq && sudo apt-get install -y "$tool"
  fi
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "[ERROR] required tool '$tool' is not installed and could not be auto-installed"
    exit 1
  fi
done

############################################
# CSV helpers (same quoted-field-safe parser used by bash/2_migration.sh)
############################################
parse_csv_line() {
  local line="$1"
  local -a fields=()
  local field="" in_quotes=false i char next
  for ((i=0; i<${#line}; i++)); do
    char="${line:$i:1}"
    next="${line:$((i+1)):1}"
    if [[ "${char}" == '"' ]]; then
      if [[ "${in_quotes}" == true ]]; then
        if [[ "${next}" == '"' ]]; then
          field+='"'; ((i++))
        else
          in_quotes=false
        fi
      else
        in_quotes=true
      fi
    elif [[ "${char}" == ',' && "${in_quotes}" == false ]]; then
      fields+=("${field}")
      field=""
    else
      field+="${char}"
    fi
  done
  fields+=("${field}")
  printf '%s\n' "${fields[@]}"
}

strip_quotes() {
  local s="$1"
  [[ ${s} == \"* ]] && s="${s#\"}"
  [[ ${s} == *\" ]] && s="${s%\"}"
  printf '%s' "$s"
}

urlencode() { jq -rn --arg s "$1" '$s|@uri'; }

# A real run decides what to disable from migration_status, so it's required there. A dry run
# may be pointed at a plain repos.csv (no migration_status): every row is then a candidate.
REQUIRED_COLUMNS=(org teamproject repo)
[[ "$DRY_RUN" == true ]] || REQUIRED_COLUMNS+=(migration_status)

read -r HEADER_LINE < "${INPUT_CSV}"
HEADER_LINE="${HEADER_LINE#$'\xEF\xBB\xBF'}"   # tolerate a UTF-8 BOM (Excel-saved CSVs)
mapfile -t HEADER_FIELDS < <(parse_csv_line "${HEADER_LINE}")

declare -A COLIDX=()
for idx in "${!HEADER_FIELDS[@]}"; do
  name="$(strip_quotes "${HEADER_FIELDS[$idx]}")"
  COLIDX["$name"]="$idx"
done

missing=()
for col in "${REQUIRED_COLUMNS[@]}"; do
  [[ -n "${COLIDX[$col]:-}" ]] || missing+=("$col")
done
if [[ ${#missing[@]} -gt 0 ]]; then
  echo "[ERROR] CSV missing required columns: ${missing[*]}"
  echo "[ERROR] Required: ${REQUIRED_COLUMNS[*]}"
  exit 1
fi
ALL_ROWS_CANDIDATES=false
[[ -z "${COLIDX[migration_status]:-}" ]] && ALL_ROWS_CANDIDATES=true

# Value of column <name> from the current row's fields (F), or "" if the CSV has no such column.
col_value() {
  local i="${COLIDX[$1]:-}"
  [[ -n "$i" ]] || return 0
  strip_quotes "${F[$i]:-}"
}

TOTAL_ROWS=$(grep -c . <(tail -n +2 "${INPUT_CSV}") || true)
if [[ ${TOTAL_ROWS} -lt 1 ]]; then
  echo "[ERROR] No repositories found in ${CSV_PATH}"
  exit 1
fi

echo "=========================================="
if [[ "$DRY_RUN" == true ]]; then
  echo "DISABLE ADO REPOSITORIES - DRY RUN (nothing will be changed)"
else
  echo "DISABLE ADO REPOSITORIES"
fi
echo "=========================================="
echo "CSV File: ${CSV_PATH}"
if [[ "$ALL_ROWS_CANDIDATES" == true ]]; then
  echo "Total rows: ${TOTAL_ROWS} (no migration_status column: every row is a candidate)"
else
  echo "Total rows: ${TOTAL_ROWS} (only migration_status=Success rows are disabled)"
fi
echo "Concurrency: ${DISABLE_MAX_CONCURRENT}"
echo "=========================================="
echo ""

SUCCESS=0
FAILED=0
SKIPPED=0
declare -a ORDERED_ROWS=()

# Per-repo log of every ADO call and its outcome, published as the disable-repo-logs artifact.
ORIG_DIR="$(pwd)"
LOG_DIR="${ORIG_DIR}/disable-logs"
mkdir -p "${LOG_DIR}"

# Scratch space for response bodies, the shared pause file and the cached repo list. Kept on
# disk rather than the default $TMPDIR (often tmpfs/RAM on Linux agents): the repo list alone
# is ~26 MB.
export TMPDIR="${ORIG_DIR}/.disable-tmp"
mkdir -p "$TMPDIR"
trap 'rm -rf "$TMPDIR"; [[ -n "$DRY_INPUT" ]] && rm -f "$DRY_INPUT"' EXIT
RATE_LIMIT_PAUSE_FILE="$TMPDIR/ado-rate-limit-pause-until"

############################################
# Shared ADO throttling pause (see RATE_LIMIT_PAUSE_FILE)
############################################
# Seconds left on the shared pause (0 if none).
rate_limit_pause_remaining() {
  local until now
  until=$(cat "$RATE_LIMIT_PAUSE_FILE" 2>/dev/null || true)
  if [[ ! "$until" =~ ^[0-9]+$ ]]; then
    echo 0
    return 0
  fi
  now=$(date +%s)
  if (( until > now )); then echo $(( until - now )); else echo 0; fi
}

# Extend (never shorten) the shared pause to <seconds> from now. Written to a temp file and
# renamed into place, so a concurrent reader never sees a half-written value.
set_rate_limit_pause() {
  local seconds="$1" reason="$2" until current tmp
  [[ "$seconds" =~ ^[0-9]+$ ]] || seconds="$RATE_LIMIT_PAUSE_SECONDS"
  if (( seconds < 1 )); then seconds=1; fi
  if (( seconds > RATE_LIMIT_MAX_PAUSE_SECONDS )); then seconds="$RATE_LIMIT_MAX_PAUSE_SECONDS"; fi
  until=$(( $(date +%s) + seconds ))
  current=$(cat "$RATE_LIMIT_PAUSE_FILE" 2>/dev/null || true)
  if [[ "$current" =~ ^[0-9]+$ ]] && (( current >= until )); then
    return 0
  fi
  tmp="${RATE_LIMIT_PAUSE_FILE}.${BASHPID}.${RANDOM}"
  printf '%s\n' "$until" > "$tmp" && mv -f "$tmp" "$RATE_LIMIT_PAUSE_FILE"
  echo "[$(date)] ADO throttling: pausing new ADO calls for ${seconds}s - ${reason}" >&2
}

# Block until the shared pause has passed. Re-checked at least every 30s since another job can
# extend it meanwhile; a little jitter afterwards so waiting jobs don't all resume at once.
wait_for_rate_limit_pause() {
  local left waited=false
  while :; do
    left=$(rate_limit_pause_remaining)
    if (( left <= 0 )); then
      break
    fi
    if [[ "$waited" == false ]]; then
      echo "[$(date)] ADO throttling: waiting ${left}s for the shared pause to end" >&2
    fi
    waited=true
    sleep $(( left < 30 ? left : 30 ))
  done
  if [[ "$waited" == true ]]; then
    sleep $(( RANDOM % 15 ))
  fi
}

############################################
# ADO REST
############################################
# ado_request <log_file> <method> <url> <out_body> [<json_body>]
# Returns 0 = HTTP 200 with a JSON body, 2 = HTTP 404, 1 = failure (logged).
ado_request() {
  local log_file="$1" method="$2" url="$3" out="$4" data="${5:-}"
  local hdr="${out}.hdr" err="${out}.err" code attempt=1 waited=0 wait retry_after
  local -a extra=()

  # Hard guarantee for --dry-run, enforced at the only place requests are made: nothing but
  # read-only GETs ever reaches ADO, whatever the caller does.
  if [[ "$DRY_RUN" == true && "$method" != "GET" ]]; then
    echo "[$(date)] DRY RUN: refused to send $method $url" >> "$log_file"
    return 1
  fi
  [[ -n "$data" ]] && extra=(-H "Content-Type: application/json" --data "$data")

  while :; do
    wait_for_rate_limit_pause 2>> "$log_file"
    code="$(curl -sS -X "$method" -o "$out" -D "$hdr" -w '%{http_code}' --connect-timeout 30 --max-time 300 \
      -H "Authorization: Basic ${ADO_AUTH_B64}" -H "Accept: application/json" "${extra[@]}" "$url" 2>"$err")" || true
    [[ "$code" =~ ^[0-9]{3}$ ]] || code="000"

    case "$code" in
      200)
        jq -e . "$out" >/dev/null 2>&1 && return 0
        ;;
      404)
        return 2
        ;;
      # ADO answers a bad/expired PAT with a redirect to its sign-in page (verified: HTTP 302), or
      # 203/401 depending on the endpoint. None of these fixes itself on retry.
      203|301|302|303|307|308|401|403)
        echo "[$(date)] ERROR: ADO returned HTTP $code for $method $url (ADO_PAT invalid/expired or missing permissions)" >> "$log_file"
        return 1
        ;;
      400)
        echo "[$(date)] ERROR: ADO returned HTTP 400 for $method $url: $(head -c 300 "$out" | tr '\n' ' ')" >> "$log_file"
        return 1
        ;;
    esac

    retry_after="$(grep -i '^retry-after:' "$hdr" 2>/dev/null | tail -n 1 | tr -d '\r' | sed -E 's/^[^:]*:[[:space:]]*//;s/[[:space:]]*$//' || true)"
    [[ "$retry_after" =~ ^[0-9]+$ ]] || retry_after=""

    if [[ "$code" == "429" ]]; then
      if (( waited >= RATE_LIMIT_MAX_WAIT_SECONDS )); then
        echo "[$(date)] ERROR: ADO throttling (HTTP 429) persisted after waiting ${waited}s: $method $url" >> "$log_file"
        return 1
      fi
      wait="${retry_after:-$RATE_LIMIT_PAUSE_SECONDS}"
      echo "[$(date)] ADO answered HTTP 429 (Retry-After: ${retry_after:-none}) for $method $url" >> "$log_file"
      set_rate_limit_pause "$wait" "HTTP 429 on $method $url" 2>> "$log_file"
      waited=$(( waited + wait ))
      continue
    fi

    if (( attempt >= API_MAX_ATTEMPTS )); then
      echo "[$(date)] ERROR: ADO API call failed (HTTP $code) after $attempt attempts: $method $url $(head -c 300 "$err" | tr '\n' ' ')" >> "$log_file"
      return 1
    fi
    wait=$(( attempt * 15 + RANDOM % 10 ))
    [[ -n "$retry_after" ]] && (( retry_after > wait )) && wait="$retry_after"
    echo "[$(date)] ADO API error (HTTP $code, attempt $attempt/$API_MAX_ATTEMPTS) for $method $url, retrying in ${wait}s" >> "$log_file"
    sleep "$wait"
    attempt=$(( attempt + 1 ))
  done
}

# repo_list_lookup <log_file> <org> <teamproject> <repo>
# Only used after a 404, to tell "already disabled" from "doesn't exist". Downloads the project's
# repo list once per run (first job to need it takes a lock; the others wait for its result)
# and prints "<id><TAB><isDisabled>" for <repo> (case-insensitive, as ADO names are).
# Returns 0 = found, 2 = not in the list, 1 = the list could not be fetched.
repo_list_lookup() {
  local log_file="$1" org="$2" teamproject="$3" repo="$4"
  local key list lock waited=0 rc
  key="$(printf '%s/%s' "$org" "$teamproject" | cksum | cut -d' ' -f1)"
  list="$TMPDIR/repolist-${key}.json"
  lock="$TMPDIR/repolist-${key}.lock"

  if mkdir "$lock" 2>/dev/null; then
    echo "[$(date)] Fetching the repository list of ${org}/${teamproject} (once per run) to check whether '${repo}' is already disabled" >> "$log_file"
    rc=0
    ado_request "$log_file" GET "https://dev.azure.com/$(urlencode "$org")/$(urlencode "$teamproject")/_apis/git/repositories?api-version=${ADO_API_VERSION}" "${list}.tmp" || rc=$?
    if (( rc == 0 )); then
      mv -f "${list}.tmp" "$list"
    else
      : > "${list}.failed"
    fi
  else
    # Another job is fetching it: wait for its result (the fetch itself may wait out throttling).
    until [[ -f "$list" || -f "${list}.failed" ]]; do
      if (( waited >= RATE_LIMIT_MAX_WAIT_SECONDS + 600 )); then
        echo "[$(date)] ERROR: timed out waiting for another job's repository-list fetch" >> "$log_file"
        return 1
      fi
      sleep 2
      waited=$(( waited + 2 ))
    done
  fi

  if [[ ! -f "$list" ]]; then
    echo "[$(date)] ERROR: could not fetch the repository list of ${org}/${teamproject}" >> "$log_file"
    return 1
  fi
  jq -er --arg n "$repo" '.value[] | select((.name | ascii_downcase) == ($n | ascii_downcase)) | "\(.id)\t\(.isDisabled // false)"' "$list" 2>/dev/null | head -n 1 | grep . || return 2
}

############################################
# Per-repo disable job (runs in a background subshell)
############################################
disable_repo_job() {
  local org="$1" teamproject="$2" repo="$3" github_org="$4" github_repo="$5"
  local gh_repo_visibility="$6" migration_status="$7" result_file="$8"

  local log_file="${result_file}.log" body base repo_id is_disabled rc found disabled=0 status="FAILED"
  : > "$log_file"
  body="$(mktemp)"
  base="https://dev.azure.com/$(urlencode "$org")/$(urlencode "$teamproject")/_apis/git/repositories"

  if [[ "$DRY_RUN" == true ]]; then
    echo "[$(date)] DRY RUN - checking ADO repo ${org}/${teamproject}/${repo} (read-only)" >> "$log_file"
  else
    echo "[$(date)] Disabling ADO repo ${org}/${teamproject}/${repo}" >> "$log_file"
  fi

  # 1. Look the repo up by name: its id, and whether it's already disabled.
  rc=0
  ado_request "$log_file" GET "${base}/$(urlencode "$repo")?api-version=${ADO_API_VERSION}" "$body" || rc=$?
  if (( rc == 0 )); then
    repo_id="$(jq -r '.id // empty' "$body")"
    is_disabled="$(jq -r '.isDisabled // false' "$body")"
  elif (( rc == 2 )); then
    # 404: missing, or already disabled (a re-run) - only the repo list can tell.
    rc=0
    found="$(repo_list_lookup "$log_file" "$org" "$teamproject" "$repo")" || rc=$?
    if (( rc == 0 )); then
      IFS=$'\t' read -r repo_id is_disabled <<< "$found"
    elif (( rc == 2 )); then
      echo "[$(date)] ERROR: ADO repo '${repo}' not found in project '${teamproject}' (renamed or deleted?)" >> "$log_file"
    fi
  fi

  # Dry run: report what a real run would do and stop here - the PATCH below is never reached
  # (and ado_request would refuse it anyway).
  if [[ "$DRY_RUN" == true ]]; then
    local result detail
    if [[ "$is_disabled" == "true" ]]; then
      result="ALREADY_DISABLED"; detail="already disabled in ADO - a real run would change nothing"
    elif [[ -n "$repo_id" ]]; then
      result="WOULD_DISABLE"; detail="found and enabled - a real run would disable it"
    elif (( rc == 2 )); then
      result="NOT_FOUND"; detail="not found in project '${teamproject}' (renamed or deleted?)"
    else
      result="ERROR"; detail="lookup failed - see disable-${repo}.log"
    fi
    echo "[$(date)] DRY RUN result: ${result} (id=${repo_id:-n/a}) - ${detail}" >> "$log_file"
    rm -f "$body" "${body}.hdr" "${body}.err"
    printf '%s\t%s\n' "${repo_id}" "${detail}" > "${result_file}.dry"
    echo "$result" > "${result_file}.status"
    return 0
  fi

  if [[ "$is_disabled" == "true" ]]; then
    echo "[$(date)] Already disabled (id=${repo_id}) - nothing to do" >> "$log_file"
    disabled=1
    status="SUCCESS"
  elif [[ -n "$repo_id" ]]; then
    # 2. Disable it.
    rc=0
    ado_request "$log_file" PATCH "${base}/$(urlencode "$repo_id")?api-version=${ADO_DISABLE_API_VERSION}" "$body" '{"isDisabled":true}' || rc=$?
    if (( rc == 0 )) && [[ "$(jq -r '.isDisabled // empty' "$body")" == "true" ]]; then
      echo "[$(date)] Disabled (id=${repo_id}) - ADO confirmed isDisabled=true" >> "$log_file"
      disabled=1
      status="SUCCESS"
    elif (( rc == 0 )); then
      # The PATCH response didn't carry isDisabled=true. Don't rely on its shape: re-read the
      # repo by id - it answered 200 moments ago, and ADO answers 404 once it's disabled.
      echo "[$(date)] PATCH response did not report isDisabled=true ($(head -c 200 "$body" | tr '\n' ' ')) - re-reading the repo to confirm" >> "$log_file"
      rc=0
      ado_request "$log_file" GET "${base}/$(urlencode "$repo_id")?api-version=${ADO_API_VERSION}" "$body" || rc=$?
      if (( rc == 2 )) || { (( rc == 0 )) && [[ "$(jq -r '.isDisabled // false' "$body")" == "true" ]]; }; then
        echo "[$(date)] Disabled (id=${repo_id}) - confirmed: ADO no longer serves the repo (HTTP 404) / reports isDisabled=true" >> "$log_file"
        disabled=1
        status="SUCCESS"
      else
        echo "[$(date)] ERROR: PATCH returned 200 but the repo is still enabled" >> "$log_file"
      fi
    elif (( rc == 2 )); then
      # 404 on the PATCH: an earlier attempt of this same PATCH may have landed (e.g. a 5xx whose
      # change still went through) - a disabled repo 404s. Confirm from the repo list.
      rc=0
      found="$(repo_list_lookup "$log_file" "$org" "$teamproject" "$repo")" || rc=$?
      if (( rc == 0 )) && [[ "$(cut -f2 <<< "$found")" == "true" ]]; then
        echo "[$(date)] Disabled (id=${repo_id}) - confirmed via the repository list" >> "$log_file"
        disabled=1
        status="SUCCESS"
      else
        echo "[$(date)] ERROR: PATCH returned 404 and the repo is not reported as disabled" >> "$log_file"
      fi
    fi
  else
    [[ -n "${found:-}" || $rc -ne 2 ]] && echo "[$(date)] ERROR: could not determine the repo's id" >> "$log_file"
  fi

  rm -f "$body" "${body}.hdr" "${body}.err"
  echo "$status" > "${result_file}.status"
  printf '%s,%s,%s,%s,%s,%s,%s,%s\n' \
    "${org}" "${teamproject}" "${repo}" "${github_org}" "${github_repo}" \
    "${gh_repo_visibility}" "${migration_status}" "${disabled}" > "${result_file}.row"
}

############################################
# Build row order + job queue in one pass. Skip rows are resolved immediately (no API
# call needed); Success rows are queued for the concurrent disable loop below.
############################################
declare -A JOB_PIDS=()   # pid -> "idx|result_file|repo"
QUEUE=()                 # entries: idx<TAB>org<TAB>teamproject<TAB>repo<TAB>github_org<TAB>github_repo<TAB>gh_repo_visibility<TAB>migration_status

# Quote one value as a CSV field (doubles embedded quotes) - for the dry-run report.
csv_q() { local v="$1"; v="${v//\"/\"\"}"; printf '"%s"' "$v"; }
declare -a DRY_REPORT=()   # idx -> report row (dry run only)
declare -a ROW_ORG=() ROW_PROJECT=()   # idx -> org / teamproject, for the dry-run report

LINE_NUM=0
ROW_IDX=0
# "|| [[ -n $line ]]": also process a last line that has no trailing newline.
while IFS= read -r line || [[ -n "${line}" ]]; do
  ((LINE_NUM++))
  [[ ${LINE_NUM} -eq 1 ]] && continue
  [[ -z "${line}" ]] && continue

  mapfile -t F < <(parse_csv_line "${line}")
  org="$(col_value org)"
  teamproject="$(col_value teamproject)"
  repo="$(col_value repo)"
  github_org="$(col_value github_org)"
  github_repo="$(col_value github_repo)"
  gh_repo_visibility="$(col_value gh_repo_visibility)"
  migration_status="$(col_value migration_status)"
  # Dry run over a plain repos.csv: every row is a candidate.
  [[ "$ALL_ROWS_CANDIDATES" == true ]] && migration_status="Success"
  ROW_ORG[$ROW_IDX]="$org"
  ROW_PROJECT[$ROW_IDX]="$teamproject"

  if [[ "${migration_status}" != "Success" ]]; then
    echo "[SKIP] ${org}/${teamproject}/${repo} (migration_status=${migration_status})"
    ((SKIPPED++))
    ORDERED_ROWS[$ROW_IDX]="${org},${teamproject},${repo},${github_org},${github_repo},${gh_repo_visibility},${migration_status},0"
    DRY_REPORT[$ROW_IDX]="$(csv_q "$org"),$(csv_q "$teamproject"),$(csv_q "$repo"),$(csv_q SKIPPED),$(csv_q ""),$(csv_q "migration_status=${migration_status} - not a candidate")"
  else
    QUEUE+=("${ROW_IDX}"$'\t'"${org}"$'\t'"${teamproject}"$'\t'"${repo}"$'\t'"${github_org}"$'\t'"${github_repo}"$'\t'"${gh_repo_visibility}"$'\t'"${migration_status}")
    # Default (disabled=0), replaced by the job's own row when it finishes - so a job that dies
    # without writing one still leaves a complete row instead of a blank CSV line.
    ORDERED_ROWS[$ROW_IDX]="${org},${teamproject},${repo},${github_org},${github_repo},${gh_repo_visibility},${migration_status},0"
    # Same idea for the dry-run report: a job that dies without a result still gets a row.
    DRY_REPORT[$ROW_IDX]="$(csv_q "$org"),$(csv_q "$teamproject"),$(csv_q "$repo"),$(csv_q ERROR),$(csv_q ""),$(csv_q "check job exited without a result")"
  fi
  ((ROW_IDX++))
done < "${INPUT_CSV}"

TOTAL_QUEUED=${#QUEUE[@]}
echo ""
if [[ "$DRY_RUN" == true ]]; then
  echo "[INFO] DRY RUN: checking ${TOTAL_QUEUED} repositories with ${DISABLE_MAX_CONCURRENT} concurrent jobs (read-only)..."
else
  echo "[INFO] Disabling ${TOTAL_QUEUED} repositories with ${DISABLE_MAX_CONCURRENT} concurrent jobs..."
fi
echo ""
DRY_WOULD=0
DRY_ALREADY=0
DRY_NOT_FOUND=0
DRY_ERROR=0

PAUSE_ACTIVE=false
RATE_LIMIT_PAUSE_COUNT=0

while (( ${#QUEUE[@]} > 0 )) || (( ${#JOB_PIDS[@]} > 0 )); do

  # While a shared ADO throttling pause is in effect, start no new jobs (running ones wait on
  # their own) so this identity's load actually drops. Announced once per pause.
  PAUSE_LEFT=$(rate_limit_pause_remaining)
  if (( PAUSE_LEFT > 0 )) && [[ "$PAUSE_ACTIVE" == false ]]; then
    PAUSE_ACTIVE=true
    RATE_LIMIT_PAUSE_COUNT=$((RATE_LIMIT_PAUSE_COUNT + 1))
    echo "##[warning]ADO is throttling this identity - starting no new disables for at least ${PAUSE_LEFT}s (${#JOB_PIDS[@]} in progress, ${#QUEUE[@]} queued)"
  elif (( PAUSE_LEFT <= 0 )) && [[ "$PAUSE_ACTIVE" == true ]]; then
    PAUSE_ACTIVE=false
    echo "[INFO] ADO throttling pause over - resuming (${#QUEUE[@]} queued)"
  fi

  # Start new jobs up to concurrency
  while (( PAUSE_LEFT <= 0 )) && (( ${#JOB_PIDS[@]} < DISABLE_MAX_CONCURRENT )) && (( ${#QUEUE[@]} > 0 )); do
    item="${QUEUE[0]}"
    QUEUE=("${QUEUE[@]:1}")

    IFS=$'\t' read -r idx org teamproject repo github_org github_repo gh_repo_visibility migration_status <<< "${item}"
    result_file="${ORIG_DIR}/.disable-result-${idx}"

    if [[ "$DRY_RUN" == true ]]; then
      echo "[INFO] Checking: ${org}/${teamproject}/${repo}"
    else
      echo "[INFO] Disabling: ${org}/${teamproject}/${repo}"
    fi

    (
      disable_repo_job "${org}" "${teamproject}" "${repo}" "${github_org}" "${github_repo}" \
        "${gh_repo_visibility}" "${migration_status}" "${result_file}"
    ) &

    pid=$!
    JOB_PIDS["${pid}"]="${idx}|${result_file}|${repo}"
  done

  # Check completed jobs (use ps to avoid reused PID false-positives)
  for pid in "${!JOB_PIDS[@]}"; do
    if ! ps -p "${pid}" > /dev/null 2>&1; then
      IFS='|' read -r idx result_file repo <<< "${JOB_PIDS[$pid]}"

      status="FAILED"
      [[ -f "${result_file}.status" ]] && status="$(<"${result_file}.status")"
      [[ -f "${result_file}.row" ]] && ORDERED_ROWS[$idx]="$(<"${result_file}.row")"

      if [[ "$DRY_RUN" == true ]]; then
        [[ "$status" == "FAILED" ]] && status="ERROR"   # job died without a result
        dry_id=""; dry_detail="check job exited without a result"
        [[ -f "${result_file}.dry" ]] && IFS=$'\t' read -r dry_id dry_detail < "${result_file}.dry"
        DRY_REPORT[$idx]="$(csv_q "${ROW_ORG[$idx]}"),$(csv_q "${ROW_PROJECT[$idx]}"),$(csv_q "$repo"),$(csv_q "$status"),$(csv_q "$dry_id"),$(csv_q "$dry_detail")"
        case "$status" in
          WOULD_DISABLE)    ((DRY_WOULD++));     echo "[DRY RUN] would disable: ${repo}" ;;
          ALREADY_DISABLED) ((DRY_ALREADY++));   echo "[DRY RUN] already disabled: ${repo}" ;;
          NOT_FOUND)        ((DRY_NOT_FOUND++)); echo "[DRY RUN] NOT FOUND in ADO: ${repo} (see disable-${repo}.log)" ;;
          *)                ((DRY_ERROR++));     echo "[DRY RUN] ERROR checking: ${repo} (see disable-${repo}.log)" ;;
        esac
      elif [[ "${status}" == "SUCCESS" ]]; then
        ((SUCCESS++))
        echo "[SUCCESS] Disabled: ${repo}"
      else
        ((FAILED++))
        echo "[FAILED] Could not disable: ${repo} (see disable-${repo}.log)"
      fi
      echo ""

      [[ -f "${result_file}.log" ]] && mv "${result_file}.log" "${LOG_DIR}/disable-${repo}.log"
      rm -f "${result_file}.status" "${result_file}.row" "${result_file}.dry"
      unset JOB_PIDS["${pid}"]
    fi
  done

  sleep 2
done

# Dry run: write the report, summarize, and stop - the input CSV is never rewritten.
if [[ "$DRY_RUN" == true ]]; then
  REPORT_CSV="${ORIG_DIR}/disable-dry-run-report.csv"
  {
    echo "org,teamproject,repo,result,repo_id,detail"
    for ((i=0; i<ROW_IDX; i++)); do
      printf '%s\n' "${DRY_REPORT[$i]}"
    done
  } > "${REPORT_CSV}"

  echo "=========================================="
  echo "DRY RUN SUMMARY - nothing was changed in ADO or in ${CSV_PATH}"
  echo "=========================================="
  echo "Total: ${TOTAL_ROWS} | Would disable: ${DRY_WOULD} | Already disabled: ${DRY_ALREADY} | Not found: ${DRY_NOT_FOUND} | Errors: ${DRY_ERROR} | Skipped (not Success): ${SKIPPED}"
  if (( RATE_LIMIT_PAUSE_COUNT > 0 )); then
    echo "ADO throttling pauses: ${RATE_LIMIT_PAUSE_COUNT}"
  fi
  echo "Report: ${REPORT_CSV}"
  echo "Per-repo logs: ${LOG_DIR}"
  echo "=========================================="
  if (( DRY_NOT_FOUND + DRY_ERROR > 0 )); then
    echo "##[warning]DRY RUN: ${DRY_NOT_FOUND} repo(s) not found and ${DRY_ERROR} error(s) - a real run would fail for these (see ${REPORT_CSV})"
    exit 1
  fi
  exit 0
fi

# Rewrite the CSV in place with the disabled column (0/1) appended.
# A pre-existing "disabled" column from a prior run is dropped and recomputed above
# rather than appended a second time.
tmp="$(mktemp)"
{
  echo "org,teamproject,repo,github_org,github_repo,gh_repo_visibility,migration_status,disabled"
  for ((i=0; i<ROW_IDX; i++)); do
    printf '%s\n' "${ORDERED_ROWS[$i]}"
  done
} > "${tmp}"
mv "${tmp}" "${CSV_PATH}"

echo "=========================================="
echo "SUMMARY"
echo "=========================================="
echo "Total: ${TOTAL_ROWS} | Disabled: ${SUCCESS} | Failed: ${FAILED} | Skipped (not Success): ${SKIPPED}"
if (( RATE_LIMIT_PAUSE_COUNT > 0 )); then
  echo "ADO throttling pauses: ${RATE_LIMIT_PAUSE_COUNT}"
fi
echo "Updated: ${CSV_PATH}"
echo "Per-repo disable logs: ${LOG_DIR}"
echo "=========================================="

if (( FAILED > 0 )); then
  echo "##[warning]${FAILED} repository(ies) failed to disable"
  echo "##vso[task.logissue type=warning]${FAILED} of $((SUCCESS+FAILED)) disable attempts failed"
  if (( SUCCESS > 0 )); then
    echo "##vso[task.complete result=SucceededWithIssues]Repo disable completed with partial success"
  else
    echo "##[error]All disable attempts failed"
    exit 1
  fi
fi

exit 0
