#!/usr/bin/env bash
set -euo pipefail

# Post-migration validation: proves each successfully migrated GitHub repo holds exactly the same
# refs as its ADO source.
#
# Method: EVERY branch (and, by default, every tag) is compared by name and by the SHA it points
# to. Because a Git commit ID is a hash over its content AND its parents, identical head SHAs
# mean identical commit history - so per-branch commit counting is unnecessary. This replaced an
# earlier approach that paginated each branch's full history over REST (100 commits per call):
# it only covered the default branch (<=10 branches) or 10 branches (>10), and on a ~630-repo
# wave it burned the token's 5,000/h REST budget ~280 repos in, turning ~290 healthy repos into
# false "failed validation" results.
#
# API cost per repo (independent of history size):
#   GitHub: one GraphQL query per 100 branches + one per 100 tags (1 point each; GraphQL has its
#           own 5,000 points/h budget, separate from REST).
#   ADO:    one repo lookup + one refs call per 1000 branches + one per 1000 tags.
#
# Each repo ends in one of three outcomes:
#   VALID      - every ref exists on both sides and the default branch points to the same SHA,
#                or GitHub's default branch contains every ADO commit plus newer ones (later
#                pipeline stages such as ReplaceBuildRepositoryNameVar/EnablePrTriggers commit to
#                the migrated repos, possibly while this stage is still running) - that case is a
#                WARNING. A non-default branch or tag pointing to a different SHA (typically a push
#                after the migration snapshot) is also a WARNING, with an explanation (GitHub N
#                commits behind/ahead, or unrelated history).
#   INVALID    - a ref missing on either side, GitHub's default branch missing ADO commits
#                (behind, diverged, or unrelated history), or the GitHub repo does not exist.
#   UNVERIFIED - the comparison could not be completed (API errors that persisted through
#                retries, ADO repo missing/disabled, ...). Says nothing about the migration; re-run
#                validation for these. An API error is never reported as a data mismatch.
#
# Validates repos concurrently (bounded background jobs), mirroring the pattern used by
# 2_migration.sh and 4_rewire_pipeline.sh. Each repo gets its own log file
# (validation-<repo>-<timestamp>.txt) so concurrent jobs never interleave writes. Scratch files
# live in a per-job mktemp dir, never in the working directory (the pipeline publishes every
# *.txt found there).
VALIDATION_MAX_CONCURRENT="${VALIDATION_MAX_CONCURRENT:-8}"

# Transient failures (HTTP 5xx, timeouts, connection errors, malformed responses) are retried per
# API call up to this many attempts with backoff. Validation is read-only, so retrying is safe.
API_MAX_ATTEMPTS="${API_MAX_ATTEMPTS:-5}"

# Rate limits are not "attempts": when GitHub reports its GraphQL budget exhausted we sleep until
# the budget's reset time (read from `gh api rate_limit`, which itself costs nothing), and on ADO
# 429 we honor Retry-After. This caps the total time a single API call may spend waiting on rate
# limits before the repo is marked UNVERIFIED. Default covers one full GitHub hourly window.
RATE_LIMIT_MAX_WAIT_SECONDS="${RATE_LIMIT_MAX_WAIT_SECONDS:-4500}"

# Pause proactively (until reset) once the GitHub GraphQL budget drops below this many points, so
# concurrent jobs don't all run into the hard limit at once.
GH_RATE_LIMIT_FLOOR="${GH_RATE_LIMIT_FLOOR:-100}"

# Compare tags as well as branches. GEI migrates tags, so a tag difference is a real gap.
TAG_CHECK="${TAG_CHECK:-true}"

# Page sizes (GitHub GraphQL max 100, ADO refs max 1000). Only lowered for testing pagination.
GH_REFS_PAGE_SIZE="${GH_REFS_PAGE_SIZE:-100}"
ADO_REFS_PAGE_SIZE="${ADO_REFS_PAGE_SIZE:-1000}"

VALIDATION_FAILURES=0
VALIDATION_SUCCESSES=0
VALIDATION_UNVERIFIED=0
FAILED_REPOS=()
UNVERIFIED_REPOS=()
NOTED_REPOS=()

GH_REFS_QUERY='query($owner: String!, $name: String!, $prefix: String!, $first: Int!, $cursor: String) {
  rateLimit { remaining resetAt }
  repository(owner: $owner, name: $name) {
    defaultBranchRef { name }
    refs(refPrefix: $prefix, first: $first, after: $cursor) {
      pageInfo { hasNextPage endCursor }
      nodes { name target { oid } }
    }
  }
}'

write_log() {
  local log_file="$1"; shift
  echo "$*" >> "$log_file"
}

urlencode() { jq -rn --arg s "$1" '$s|@uri'; }

clean_field() {
  local s="$1"
  s="${s%$'\r'}"
  s="${s#\"}"
  s="${s%\"}"
  s="$(printf '%s' "$s" | xargs)"
  printf '%s' "$s"
}

parse_csv_line() {
  local line="$1"
  local -a fields=()
  local field="" in_quotes=false i char next

  for ((i=0; i<${#line}; i++)); do
    char="${line:$i:1}"
    next="${line:$((i+1)):1}"

    if [[ "$char" == '"' ]]; then
      if [[ "$in_quotes" == true ]]; then
        if [[ "$next" == '"' ]]; then field+='"'; ((i++))
        else in_quotes=false; fi
      else in_quotes=true; fi
    elif [[ "$char" == ',' && "$in_quotes" == false ]]; then
      fields+=("$field"); field=""
    else
      field+="$char"
    fi
  done
  fields+=("$field")

  while [ "${#fields[@]}" -lt 7 ]; do fields+=(""); done

  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "${fields[0]}" "${fields[1]}" "${fields[2]}" \
    "${fields[3]}" "${fields[4]}" "${fields[5]}" "${fields[6]}"
}

# -----------------------------
# Auth checks (run once, before any per-repo job starts)
# -----------------------------
ensure_auth() {
  # ADO PAT check
  if [[ -z "${ADO_PAT:-}" ]]; then
    echo "❌ ERROR: ADO_PAT environment variable is not set" >&2
    exit 1
  fi

  # GitHub auth check (support GH_PAT or GH_TOKEN)
  if [[ -n "${GH_PAT:-}" && -z "${GH_TOKEN:-}" ]]; then
    export GH_TOKEN="$GH_PAT"
  fi

  if [[ -z "${GH_TOKEN:-}" ]]; then
    echo "❌ ERROR: GH_PAT or GH_TOKEN is not set (required for gh api)" >&2
    exit 1
  fi

  # Validate token
  if ! gh api user >/dev/null 2>&1; then
    echo "❌ ERROR: GitHub authentication failed (invalid/expired token)" >&2
    exit 1
  fi
}

# -----------------------------
# GitHub API (GraphQL)
# -----------------------------

# Seconds to sleep for a GitHub rate limit. Budget exhausted (or below the floor) -> until the
# reset time. Budget still available -> it was a secondary (burst) limit, which clears in about a
# minute, so don't sleep out the whole hourly window.
github_rate_limit_wait_seconds() {
  local info remaining reset now
  info="$(gh api rate_limit --jq '.resources.graphql | "\(.remaining) \(.reset)"' 2>/dev/null || true)"
  remaining="${info%% *}"
  reset="${info##* }"
  now="$(date +%s)"
  if [[ "$remaining" =~ ^[0-9]+$ && "$reset" =~ ^[0-9]+$ ]] && \
     (( remaining < GH_RATE_LIMIT_FLOOR && reset > now )); then
    echo $(( reset - now + 5 + RANDOM % 25 ))
  else
    echo $(( 60 + RANDOM % 30 ))
  fi
}

# gh_graphql <log_file> <out_json> <gh api graphql args...>
# Returns 0 = success (.data present, no errors), 2 = NOT_FOUND, 1 = could not complete (logged).
gh_graphql() {
  local log_file="$1" out="$2"; shift 2
  local err="${out}.err" rc attempt=1 waited=0 wait detail body_msg remaining

  while :; do
    rc=0
    gh api graphql "$@" >"$out" 2>"$err" || rc=$?

    if (( rc == 0 )) && jq -e '(.data != null) and ((.errors // []) | length == 0)' "$out" >/dev/null 2>&1; then
      remaining="$(jq -r '.data.rateLimit.remaining // empty' "$out" 2>/dev/null || true)"
      if [[ "$remaining" =~ ^[0-9]+$ ]] && (( remaining < GH_RATE_LIMIT_FLOOR )); then
        wait="$(github_rate_limit_wait_seconds)"
        write_log "$log_file" "⏳ GitHub GraphQL budget low (remaining=$remaining), pausing ${wait}s until it resets..."
        sleep "$wait"
      fi
      return 0
    fi

    if jq -e '[(.errors // [])[] | .type] | index("NOT_FOUND") != null' "$out" >/dev/null 2>&1; then
      return 2
    fi

    detail="$(tr '\n' ' ' < "$err" | head -c 400)"
    body_msg="$(jq -rc '(.errors // []) | map("\(.type // "")\(if .type then ": " else "" end)\(.message // "")") | join("; ")' "$out" 2>/dev/null || true)"
    if [[ -z "$body_msg" && -s "$out" ]] && ! jq -e . "$out" >/dev/null 2>&1; then
      body_msg="non-JSON response: $(head -c 200 "$out" | tr '\n' ' ')"
    fi
    [[ -n "$body_msg" ]] && detail+=" | $body_msg"

    if grep -qiE 'rate.?limit|abuse' <<< "$detail"; then
      if (( waited >= RATE_LIMIT_MAX_WAIT_SECONDS )); then
        write_log "$log_file" "❌ ERROR: GitHub rate limit persisted after waiting ${waited}s: $detail"
        return 1
      fi
      wait="$(github_rate_limit_wait_seconds)"
      write_log "$log_file" "⏳ GitHub rate limit hit, waiting ${wait}s (waited ${waited}s so far): $detail"
      sleep "$wait"
      waited=$(( waited + wait ))
      continue
    fi

    # Auth/permission/request errors won't fix themselves - fail fast instead of retrying.
    if grep -qiE 'HTTP 40[0-9]|HTTP 41[0-9]|HTTP 42[0-8]|Bad credentials|SAML|FORBIDDEN|INSUFFICIENT_SCOPES' <<< "$detail"; then
      write_log "$log_file" "❌ ERROR: GitHub API call failed (not retryable): $detail"
      return 1
    fi

    if (( attempt >= API_MAX_ATTEMPTS )); then
      write_log "$log_file" "❌ ERROR: GitHub API call failed after $attempt attempts: $detail"
      return 1
    fi
    wait=$(( attempt * 15 + RANDOM % 10 ))
    write_log "$log_file" "⏳ GitHub API error (attempt $attempt/$API_MAX_ATTEMPTS), retrying in ${wait}s: $detail"
    sleep "$wait"
    attempt=$(( attempt + 1 ))
  done
}

# gh_fetch_refs <log_file> <owner> <repo> <prefix> <out_json> [<out_default_branch_file>]
# Writes a JSON array of {key: <ref name without prefix>, value: <sha>} to out_json.
# Returns gh_graphql's codes (0 ok, 2 repo not found, 1 failure).
gh_fetch_refs() {
  local log_file="$1" owner="$2" repo="$3" prefix="$4" out="$5" out_default="${6:-}"
  local page="${out}.page" cursor="" has_next rc pages=0
  local -a args

  echo '[]' > "$out"
  while :; do
    args=(-f query="$GH_REFS_QUERY" -f owner="$owner" -f name="$repo" -f prefix="$prefix" -F first="$GH_REFS_PAGE_SIZE")
    [[ -n "$cursor" ]] && args+=(-f cursor="$cursor")

    rc=0
    gh_graphql "$log_file" "$page" "${args[@]}" || rc=$?
    (( rc != 0 )) && return "$rc"

    if (( pages == 0 )) && [[ -n "$out_default" ]]; then
      jq -r '.data.repository.defaultBranchRef.name // ""' "$page" > "$out_default"
    fi

    if ! jq -s '.[0] + (.[1].data.repository.refs.nodes | map({key: .name, value: .target.oid}))' \
         "$out" "$page" > "${out}.tmp"; then
      write_log "$log_file" "❌ ERROR: Unexpected GitHub refs response for $owner/$repo ($prefix)"
      return 1
    fi
    mv "${out}.tmp" "$out"

    pages=$(( pages + 1 ))
    has_next="$(jq -r '.data.repository.refs.pageInfo.hasNextPage' "$page")"
    cursor="$(jq -r '.data.repository.refs.pageInfo.endCursor // ""' "$page")"
    [[ "$has_next" == "true" ]] || break
    if [[ -z "$cursor" ]] || (( pages >= 10000 )); then
      write_log "$log_file" "❌ ERROR: GitHub refs pagination for $owner/$repo ($prefix) did not terminate cleanly"
      return 1
    fi
  done
  return 0
}

# GitHub turns characters it doesn't allow in repo names into '-' at creation time (e.g.
# "Batch(eliminar" -> "Batch-eliminar"), so the CSV name can differ from the real repo name.
# Prints candidate names (collapsed and per-character replacement), excluding the original.
github_name_variants() {
  local name="$1" v
  for v in "$(sed -E 's/[^A-Za-z0-9._-]+/-/g' <<< "$name")" "$(sed -E 's/[^A-Za-z0-9._-]/-/g' <<< "$name")"; do
    [[ "$v" != "$name" ]] && echo "$v"
  done | awk '!seen[$0]++'
}

# -----------------------------
# ADO API (REST)
# -----------------------------

# ado_get <log_file> <url> <out_body>
# Returns 0 = HTTP 200 with JSON body, 2 = HTTP 404, 1 = failure (logged). Headers go to <out_body>.hdr.
ado_get() {
  local log_file="$1" url="$2" out="$3"
  local hdr="${out}.hdr" err="${out}.err" code attempt=1 waited=0 wait retry_after

  while :; do
    code="$(curl -sS -o "$out" -D "$hdr" -w '%{http_code}' --connect-timeout 30 --max-time 180 \
      -H "Authorization: Basic $ADO_AUTH" -H "Accept: application/json" "$url" 2>"$err")" || true
    [[ "$code" =~ ^[0-9]{3}$ ]] || code="000"

    case "$code" in
      200)
        jq -e . "$out" >/dev/null 2>&1 && return 0
        ;;
      404)
        return 2
        ;;
      # ADO answers a bad/expired PAT with a redirect to its sign-in page (verified: HTTP 302), or
      # 203/401 depending on the endpoint. None of these fixes itself on retry.
      203|301|302|303|307|308|401|403)
        write_log "$log_file" "❌ ERROR: ADO returned HTTP $code (ADO_PAT invalid/expired or missing permissions): $url"
        return 1
        ;;
      400)
        write_log "$log_file" "❌ ERROR: ADO returned HTTP 400: $url | $(head -c 300 "$out" | tr '\n' ' ')"
        return 1
        ;;
    esac

    retry_after="$(grep -i '^retry-after:' "$hdr" 2>/dev/null | tail -n 1 | tr -dc '0-9' || true)"

    if [[ "$code" == "429" ]]; then
      if (( waited >= RATE_LIMIT_MAX_WAIT_SECONDS )); then
        write_log "$log_file" "❌ ERROR: ADO throttling persisted after waiting ${waited}s: $url"
        return 1
      fi
      wait="${retry_after:-60}"
      (( wait < 5 )) && wait=5
      wait=$(( wait + RANDOM % 10 ))
      write_log "$log_file" "⏳ ADO throttled (HTTP 429), waiting ${wait}s (waited ${waited}s so far)"
      sleep "$wait"
      waited=$(( waited + wait ))
      continue
    fi

    if (( attempt >= API_MAX_ATTEMPTS )); then
      write_log "$log_file" "❌ ERROR: ADO API call failed (HTTP $code) after $attempt attempts: $url $(head -c 300 "$err" | tr '\n' ' ')"
      return 1
    fi
    wait=$(( attempt * 15 + RANDOM % 10 ))
    [[ -n "$retry_after" ]] && (( retry_after > wait )) && wait="$retry_after"
    write_log "$log_file" "⏳ ADO API error (HTTP $code, attempt $attempt/$API_MAX_ATTEMPTS), retrying in ${wait}s"
    sleep "$wait"
    attempt=$(( attempt + 1 ))
  done
}

# ado_fetch_refs <log_file> <ado_org> <encoded_project> <repo_id> <filter> <strip_prefix> <out_json>
# Writes a JSON array of {key: <ref name without prefix>, value: <objectId>} to out_json.
ado_fetch_refs() {
  local log_file="$1" ado_org="$2" encoded_project="$3" repo_id="$4" filter="$5" strip="$6" out="$7"
  local page="${out}.page" token="" prev_token="" url rc pages=0

  echo '[]' > "$out"
  while :; do
    url="https://dev.azure.com/$ado_org/$encoded_project/_apis/git/repositories/$repo_id/refs?filter=$filter&\$top=$ADO_REFS_PAGE_SIZE&api-version=7.1"
    [[ -n "$token" ]] && url+="&continuationToken=$(urlencode "$token")"

    rc=0
    ado_get "$log_file" "$url" "$page" || rc=$?
    if (( rc == 2 )); then
      write_log "$log_file" "❌ ERROR: ADO refs endpoint returned 404 for repo_id=$repo_id"
      return 1
    fi
    (( rc != 0 )) && return 1

    if ! jq -s --arg p "$strip" '.[0] + (.[1].value | map({key: (.name | ltrimstr($p)), value: .objectId}))' \
         "$out" "$page" > "${out}.tmp"; then
      write_log "$log_file" "❌ ERROR: Unexpected ADO refs response for repo_id=$repo_id ($filter)"
      return 1
    fi
    mv "${out}.tmp" "$out"

    pages=$(( pages + 1 ))
    prev_token="$token"
    token="$(grep -i '^x-ms-continuationtoken:' "${page}.hdr" 2>/dev/null | tail -n 1 | cut -d: -f2- | tr -d ' \r' || true)"
    [[ -n "$token" ]] || break
    if [[ "$token" == "$prev_token" ]] || (( pages >= 10000 )); then
      write_log "$log_file" "❌ ERROR: ADO refs pagination for repo_id=$repo_id ($filter) did not terminate cleanly"
      return 1
    fi
  done
  return 0
}

# -----------------------------
# Comparison
# -----------------------------

# sha_relation <github_org> <github_repo> <ado_sha> <gh_sha>
# Asks GitHub how the ADO SHA relates to the GitHub SHA (REST compare API, only called for refs
# whose SHAs differ). Prints "<kind><TAB><message>" where kind is one of:
#   ahead     - GitHub contains every ADO commit plus newer ones (e.g. commits made by later
#               pipeline stages like ReplaceBuildRepositoryNameVar/EnablePrTriggers, or new work).
#               Nothing from ADO is missing.
#   behind    - GitHub is missing ADO commits.
#   diverged  - both sides have commits the other lacks (ADO commits missing in GitHub).
#   unrelated - the ADO commit does not exist in the GitHub repo at all.
#   unknown   - the relationship could not be determined (API error after retries).
sha_relation() {
  local owner="$1" repo="$2" ado_sha="$3" gh_sha="$4" out status ahead behind attempt
  for attempt in 1 2 3; do
    if out="$(gh api "/repos/$owner/$repo/compare/${ado_sha}...${gh_sha}?per_page=1" \
                --jq '"\(.status) \(.ahead_by) \(.behind_by)"' 2>&1)"; then
      read -r status ahead behind <<< "$out"
      case "$status" in
        ahead)    printf 'ahead\tGitHub contains all ADO commits plus %s newer commit(s) (e.g. commits made by later pipeline stages, or new work on GitHub)\n' "$ahead" ;;
        behind)   printf 'behind\tGitHub is %s commit(s) behind ADO (ADO commits missing in GitHub)\n' "$behind" ;;
        diverged) printf 'diverged\thistories diverged: GitHub is %s ahead / %s behind ADO (ADO commits missing in GitHub)\n' "$ahead" "$behind" ;;
        *)        printf 'unknown\tunexpected GitHub compare status: %s\n' "$out" ;;
      esac
      return 0
    fi
    if grep -qiE 'HTTP 404|No common ancestor|not found' <<< "$out"; then
      printf 'unrelated\tADO commit not present in GitHub (unrelated history)\n'
      return 0
    fi
    (( attempt < 3 )) && sleep $(( attempt * 10 + RANDOM % 5 ))
  done
  printf 'unknown\tcould not determine relationship: %s\n' "$(head -c 150 <<< "$out" | tr '\n' ' ')"
}

# compare_refs <log_file> <label> <ado_json> <gh_json> <work_dir> <default_branch> <github_org> <github_repo>
# Logs a count line plus one line per ref. Severity:
#   ❌ failing  - a ref missing on either side, or the DEFAULT branch missing ADO commits in GitHub
#                 (behind / diverged / unrelated, per GitHub's compare API).
#   ⚠️ warning  - the default branch where GitHub has every ADO commit plus newer ones, or a
#                 non-default branch / tag pointing to a different SHA. Logged, reported, not a failure.
#   ❓          - default branch differs but the compare API failed after retries -> UNVERIFIED.
# Returns 0 = all identical, 1 = at least one failing difference, 4 = warnings only,
# 3 = could not be verified. Warning lines are appended to $work/warnings.
DIFF_EXPLAIN_MAX="${DIFF_EXPLAIN_MAX:-20}"
compare_refs() {
  local log_file="$1" label="$2" ado_json="$3" gh_json="$4" work="$5" default_branch="$6" owner="$7" repo="$8"
  local diff_file="$work/compare.tsv" ado_count gh_count status name a g matched=0 failing=0 warnings=0
  local explained=0 unverifiable=0 why severity kind

  if ! jq -rn --slurpfile a "$ado_json" --slurpfile g "$gh_json" '
      ($a[0] | from_entries) as $ado
      | ($g[0] | from_entries) as $gh
      | (($ado | keys) + ($gh | keys) | unique)[] as $k
      | if ($ado | has($k)) and ($gh | has($k)) then
          (if $ado[$k] == $gh[$k] then "OK" else "DIFF" end) + "\t\($k)\t\($ado[$k])\t\($gh[$k])"
        elif ($ado | has($k)) then "MISSING_GH\t\($k)\t\($ado[$k])\t-"
        else "MISSING_ADO\t\($k)\t-\t\($gh[$k])"
        end' > "$diff_file"; then
    write_log "$log_file" "❌ ERROR: Could not compare ${label,,}s (jq failure)"
    return 3
  fi

  ado_count="$(jq 'length' "$ado_json")"
  gh_count="$(jq 'length' "$gh_json")"
  if [[ "$ado_count" == "$gh_count" ]]; then
    write_log "$log_file" "$label Count: ADO=$ado_count | GitHub=$gh_count | ✅ Matching"
  else
    write_log "$log_file" "$label Count: ADO=$ado_count | GitHub=$gh_count | ❌ Not Matching"
  fi

  while IFS=$'\t' read -r status name a g; do
    case "$status" in
      OK)
        matched=$(( matched + 1 ))
        write_log "$log_file" "$label '$name': ADO SHA=$a | GitHub SHA=$g | ✅ Matching" ;;
      DIFF)
        why=""
        if [[ "$label" == "Branch" && -n "$default_branch" && "$name" == "$default_branch" ]]; then
          # Default branch: the relationship decides the outcome. "ahead" means every ADO commit
          # is in GitHub (the migration is complete; GitHub just has newer commits, typically
          # from the later pipeline stages that commit to the migrated repos).
          IFS=$'\t' read -r kind why <<< "$(sha_relation "$owner" "$repo" "$a" "$g" < /dev/null)"
          case "$kind" in
            ahead)
              warnings=$(( warnings + 1 ))
              write_log "$log_file" "$label '$name': ADO SHA=$a | GitHub SHA=$g | ⚠️ Not Matching (default branch, warning only) - $why"
              echo "$label '$name' (default branch: GitHub has newer commits)" >> "$work/warnings" ;;
            unknown)
              unverifiable=$(( unverifiable + 1 ))
              write_log "$log_file" "$label '$name': ADO SHA=$a | GitHub SHA=$g | ❓ Not Matching (default branch) - $why" ;;
            *)
              failing=$(( failing + 1 ))
              write_log "$log_file" "$label '$name': ADO SHA=$a | GitHub SHA=$g | ❌ Not Matching (default branch) - $why" ;;
          esac
          continue
        fi
        # Non-default branches: diagnostic only. Tags are skipped - they can point to
        # annotated-tag objects, which the compare API can't relate.
        if [[ "$label" == "Branch" ]] && (( explained < DIFF_EXPLAIN_MAX )); then
          IFS=$'\t' read -r kind why <<< "$(sha_relation "$owner" "$repo" "$a" "$g" < /dev/null)"
          why=" - $why"
          explained=$(( explained + 1 ))
        fi
        warnings=$(( warnings + 1 ))
        severity="non-default branch"
        [[ "$label" == "Tag" ]] && severity="tag"
        write_log "$log_file" "$label '$name': ADO SHA=$a | GitHub SHA=$g | ⚠️ Not Matching ($severity, warning only)$why"
        echo "$label '$name'" >> "$work/warnings" ;;
      MISSING_GH)
        failing=$(( failing + 1 ))
        write_log "$log_file" "$label '$name': ADO SHA=$a | ❌ Missing in GitHub" ;;
      MISSING_ADO)
        failing=$(( failing + 1 ))
        write_log "$log_file" "$label '$name': GitHub SHA=$g | ❌ Missing in ADO" ;;
    esac
  done < "$diff_file"

  if (( failing > 0 )); then
    write_log "$log_file" "${label} refs: $matched identical, $failing failing, $warnings warning(s) | ❌ Not Matching"
    return 1
  fi
  if (( unverifiable > 0 )); then
    write_log "$log_file" "❌ ERROR: Default branch SHA differs and GitHub could not tell whether all ADO commits are present (see above)"
    return 3
  fi
  if (( warnings > 0 )); then
    write_log "$log_file" "${label} refs: $matched identical, $warnings warning(s) (see ⚠️ lines above) | ⚠️ Matching with warnings"
    return 4
  fi
  write_log "$log_file" "${label} refs: $matched/$ado_count identical (name + SHA) | ✅ Matching"
  return 0
}

# -----------------------------
# Validate migration
# -----------------------------
# Returns 0 = VALID, 1 = INVALID, 3 = UNVERIFIED. Notes for the console summary go to $work/notes.
validate_migration() {
  local ado_org="$1"
  local ado_team_project="$2"
  local ado_repo="$3"
  local github_org="$4"
  local github_repo="$5"
  local log_file="$6"
  local work="$7"

  local has_validation_errors=0 rc gh_name candidate found=""
  local -a variants=()

  write_log "$log_file" "============================================================"
  write_log "$log_file" "Validating: $ado_repo -> $github_org/$github_repo"
  write_log "$log_file" "Method: every branch$([[ "$TAG_CHECK" == "true" ]] && echo " and tag") compared by name and SHA (identical head SHAs imply identical commit history)"

  # ---- GitHub branches (+ resolve the real repo name) ----
  gh_name="$github_repo"
  rc=0
  gh_fetch_refs "$log_file" "$github_org" "$gh_name" "refs/heads/" "$work/gh_heads.json" "$work/gh_default" || rc=$?
  if (( rc == 2 )); then
    mapfile -t variants < <(github_name_variants "$github_repo")
    for candidate in "${variants[@]}"; do
      rc=0
      gh_fetch_refs "$log_file" "$github_org" "$candidate" "refs/heads/" "$work/gh_heads.json" "$work/gh_default" || rc=$?
      if (( rc == 0 )); then found="$candidate"; break; fi
      (( rc == 1 )) && return 3
    done
    if [[ -z "$found" ]]; then
      write_log "$log_file" "❌ ERROR: GitHub repo $github_org/$github_repo not found${variants[0]:+ (also tried: ${variants[*]})}"
      return 1
    fi
    gh_name="$found"
    write_log "$log_file" "⚠️ GitHub repo '$github_repo' does not exist; the migrated repo is '$gh_name' (GitHub replaces characters it does not allow in repo names). Validating '$gh_name'."
    echo "GitHub repo name differs from CSV: $github_org/$gh_name (CSV: $github_repo)" >> "$work/notes"
  elif (( rc != 0 )); then
    return 3
  fi

  # ---- ADO repo lookup ----
  local encoded_project repo_id is_disabled ado_default gh_default
  encoded_project="$(urlencode "$ado_team_project")"

  rc=0
  ado_get "$log_file" "https://dev.azure.com/$ado_org/$encoded_project/_apis/git/repositories/$(urlencode "$ado_repo")?api-version=7.1" "$work/ado_repo.json" || rc=$?
  if (( rc == 2 )); then
    # ADO answers TF401019/404 both for a missing repo and for a DISABLED one (e.g. after the
    # RepoDisable stage ran) - verified. Either way its refs are unreadable, so nothing can be compared.
    write_log "$log_file" "❌ ERROR: ADO repo '$ado_repo' in project '$ado_team_project' is not readable (HTTP 404: disabled, renamed, or deleted). Validation must run before the ADO repo is disabled."
    return 3
  elif (( rc != 0 )); then
    return 3
  fi

  repo_id="$(jq -r '.id // empty' "$work/ado_repo.json")"
  is_disabled="$(jq -r '.isDisabled // false' "$work/ado_repo.json")"
  ado_default="$(jq -r '(.defaultBranch // "") | ltrimstr("refs/heads/")' "$work/ado_repo.json")"
  if [[ -z "$repo_id" ]]; then
    write_log "$log_file" "❌ ERROR: ADO repo lookup for '$ado_repo' returned no id"
    return 3
  fi
  if [[ "$is_disabled" == "true" ]]; then
    write_log "$log_file" "❌ ERROR: ADO repo '$ado_repo' is disabled, its refs cannot be read"
    return 3
  fi

  gh_default="$(cat "$work/gh_default")"
  if [[ -n "$ado_default" && -n "$gh_default" && "$ado_default" != "$gh_default" ]]; then
    write_log "$log_file" "Default branch: ADO=$ado_default | GitHub=$gh_default | ⚠️ Different (not counted as a failure)"
  else
    write_log "$log_file" "Default branch: ADO=${ado_default:-<none>} | GitHub=${gh_default:-<none>}"
  fi

  # ---- ADO branches + compare ----
  ado_fetch_refs "$log_file" "$ado_org" "$encoded_project" "$repo_id" "heads/" "refs/heads/" "$work/ado_heads.json" || return 3

  # Default branch whose SHA must match: ADO's (the source of truth), else GitHub's.
  local default_branch="${ado_default:-$gh_default}"

  rc=0
  compare_refs "$log_file" "Branch" "$work/ado_heads.json" "$work/gh_heads.json" "$work" "$default_branch" "$github_org" "$gh_name" || rc=$?
  (( rc == 3 )) && return 3
  (( rc == 1 )) && has_validation_errors=1

  # ---- Tags ----
  if [[ "$TAG_CHECK" == "true" ]]; then
    rc=0
    gh_fetch_refs "$log_file" "$github_org" "$gh_name" "refs/tags/" "$work/gh_tags.json" || rc=$?
    (( rc != 0 )) && return 3
    ado_fetch_refs "$log_file" "$ado_org" "$encoded_project" "$repo_id" "tags/" "refs/tags/" "$work/ado_tags.json" || return 3

    rc=0
    compare_refs "$log_file" "Tag" "$work/ado_tags.json" "$work/gh_tags.json" "$work" "$default_branch" "$github_org" "$gh_name" || rc=$?
    (( rc == 3 )) && return 3
    (( rc == 1 )) && has_validation_errors=1
  fi

  if [[ -s "$work/warnings" ]]; then
    echo "⚠️ $(wc -l < "$work/warnings" | tr -d ' ') ref(s) differ from ADO without failing validation (warning only): $(head -n 5 "$work/warnings" | paste -sd ',' -)$( (( $(wc -l < "$work/warnings") > 5 )) && echo ', ...')" >> "$work/notes"
  fi

  return $has_validation_errors
}

# -----------------------------
# MAIN
# -----------------------------
ensure_auth

ADO_AUTH="$(printf ":%s" "$ADO_PAT" | base64 -w 0 2>/dev/null || printf ":%s" "$ADO_PAT" | base64 | tr -d '\n')"

CSV_INPUT="${1:-repos-migration-status.csv}"

declare -A JOB_PIDS=()   # pid -> github_repo (for progress messages)
declare -A JOB_LOGS=()   # pid -> log file

QUEUE=()

while read -r line; do
  line="${line%$'\r'}"
  [[ -z "$line" ]] && continue

  IFS=$'\t' read -r org teamproject repo github_org github_repo _ status \
    < <(parse_csv_line "$line")

  org=$(clean_field "$org")
  teamproject=$(clean_field "$teamproject")
  repo=$(clean_field "$repo")
  github_org=$(clean_field "$github_org")
  github_repo=$(clean_field "$github_repo")
  status=$(clean_field "$status")

  [[ "$status" != "Success" ]] && continue

  QUEUE+=("$org"$'\t'"$teamproject"$'\t'"$repo"$'\t'"$github_org"$'\t'"$github_repo")
done < <(tail -n +2 "$CSV_INPUT")

TOTAL_QUEUED=${#QUEUE[@]}
echo "[INFO] Validating $TOTAL_QUEUED successfully migrated repositories with $VALIDATION_MAX_CONCURRENT concurrent jobs (branches: all, tags: $TAG_CHECK)..."

while (( ${#QUEUE[@]} > 0 )) || (( ${#JOB_PIDS[@]} > 0 )); do

  # Start new jobs up to concurrency
  while (( ${#JOB_PIDS[@]} < VALIDATION_MAX_CONCURRENT )) && (( ${#QUEUE[@]} > 0 )); do
    item="${QUEUE[0]}"
    QUEUE=("${QUEUE[@]:1}")

    IFS=$'\t' read -r org teamproject repo github_org github_repo <<< "$item"
    log_file="validation-${github_repo}-$(date +%Y%m%d-%H%M%S).txt"

    (
      work="$(mktemp -d)"
      trap 'rm -rf "$work"' EXIT

      rc=0
      validate_migration "$org" "$teamproject" "$repo" "$github_org" "$github_repo" "$log_file" "$work" || rc=$?
      case "$rc" in
        0) result="VALID" ;;
        1) result="INVALID" ;;
        *) result="UNVERIFIED" ;;
      esac
      if [[ "$result" == "VALID" && -s "$work/warnings" ]]; then
        write_log "$log_file" "Result: VALID (with warnings)"
      else
        write_log "$log_file" "Result: $result"
      fi
      { echo "$result"; cat "$work/notes" 2>/dev/null || true; } > "${log_file}.result"
    ) &

    pid=$!
    JOB_PIDS["$pid"]="$github_repo"
    JOB_LOGS["$pid"]="$log_file"
  done

  # Check completed jobs (use ps to avoid reused PID false-positives)
  for pid in "${!JOB_PIDS[@]}"; do
    if ! ps -p "$pid" > /dev/null 2>&1; then
      github_repo="${JOB_PIDS[$pid]}"
      log_file="${JOB_LOGS[$pid]}"

      # A job that died without writing a result (crash, OOM kill) proves nothing either way.
      result="UNVERIFIED"
      note=""
      if [[ -f "${log_file}.result" ]]; then
        result="$(head -n 1 "${log_file}.result")"
        note="$(tail -n +2 "${log_file}.result" | tr '\n' ' ')"
        rm -f "${log_file}.result"
      else
        echo "Result: UNVERIFIED (validation job exited without a result)" >> "$log_file"
      fi

      done_count=$((VALIDATION_SUCCESSES + VALIDATION_FAILURES + VALIDATION_UNVERIFIED + 1))
      case "$result" in
        VALID)
          VALIDATION_SUCCESSES=$((VALIDATION_SUCCESSES + 1))
          echo "[INFO] ✅ $github_repo validated ($done_count/$TOTAL_QUEUED)"
          ;;
        INVALID)
          VALIDATION_FAILURES=$((VALIDATION_FAILURES + 1))
          echo "[INFO] ❌ $github_repo failed validation ($done_count/$TOTAL_QUEUED) — see $log_file"
          FAILED_REPOS+=("$github_repo ($log_file)")
          ;;
        *)
          VALIDATION_UNVERIFIED=$((VALIDATION_UNVERIFIED + 1))
          echo "[INFO] ⚠️ $github_repo could not be verified ($done_count/$TOTAL_QUEUED) — see $log_file"
          UNVERIFIED_REPOS+=("$github_repo ($log_file)")
          ;;
      esac
      if [[ -n "${note// /}" ]]; then
        echo "[INFO]    note: $note"
        NOTED_REPOS+=("$github_repo: $note")
      fi

      unset JOB_PIDS["$pid"] JOB_LOGS["$pid"]
    fi
  done

  sleep 2
done

echo "============================================================"
echo "Summary: $VALIDATION_SUCCESSES succeeded, $VALIDATION_FAILURES failed, $VALIDATION_UNVERIFIED unverified"

if (( VALIDATION_FAILURES > 0 )); then
  echo "##[warning]Post-migration validation found ${VALIDATION_FAILURES} repositor(ies) whose refs do NOT match ADO"
  echo "##[section]Failed Repositories (real differences - investigate):"
  for repo in "${FAILED_REPOS[@]}"; do
    echo "##[warning]  ⚠️ $repo"
  done
fi

if (( VALIDATION_UNVERIFIED > 0 )); then
  echo "##[warning]${VALIDATION_UNVERIFIED} repositor(ies) could not be verified (API/infrastructure errors, not data differences) - re-run validation for them"
  echo "##[section]Unverified Repositories:"
  for repo in "${UNVERIFIED_REPOS[@]}"; do
    echo "##[warning]  ⚠️ $repo"
  done
fi

if (( ${#NOTED_REPOS[@]} > 0 )); then
  echo "##[section]Notes and warnings (repos above still count as validated):"
  for repo in "${NOTED_REPOS[@]}"; do
    echo "##[warning]  ℹ️ $repo"
  done
fi

if (( VALIDATION_FAILURES + VALIDATION_UNVERIFIED > 0 )); then
  echo "##vso[task.logissue type=warning]${VALIDATION_FAILURES} of ${TOTAL_QUEUED} repositories failed post-migration validation, ${VALIDATION_UNVERIFIED} could not be verified"
fi

# Optional: fail pipeline if you want (unverified counts too - it is not proof of success)
if [[ "${FAIL_ON_VALIDATION_FAILURES:-false}" == "true" ]] && (( VALIDATION_FAILURES + VALIDATION_UNVERIFIED > 0 )); then
  echo "❌ FAIL_ON_VALIDATION_FAILURES=true and failed/unverified repositories detected. Exiting with code 1."
  exit 1
fi

if (( VALIDATION_FAILURES + VALIDATION_UNVERIFIED > 0 )); then
  echo "##vso[task.complete result=SucceededWithIssues]Post-migration validation: ${VALIDATION_FAILURES} failed, ${VALIDATION_UNVERIFIED} unverified"
fi

exit 0
