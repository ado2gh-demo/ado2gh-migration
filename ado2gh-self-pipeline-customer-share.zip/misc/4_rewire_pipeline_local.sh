#!/usr/bin/env bash

# --- MANUAL/LOCAL COPY ------------------------------------------------------
# This is a copy of bash/4_rewire_pipeline.sh, kept here for running targeted
# local remediation batches (e.g. a pipelines.csv trimmed to a handful of
# pipeline_ids) without going through the full ADO pipeline. See CLAUDE.md's
# "Running/testing scripts locally" section for the general local-run pattern.
#
# DRIFT WARNING: this is a plain copy, not a symlink or generated file - it
# will NOT automatically pick up future fixes to bash/4_rewire_pipeline.sh
# (that file is the one actually used by the ADO pipeline; this one is not
# wired into it). Before relying on this for a real remediation, diff it
# against the current bash/4_rewire_pipeline.sh and re-copy if they've
# diverged. Last synced from bash/4_rewire_pipeline.sh on 2026-09-30 (retry
# 5xx/stale-definition skips, readable skip messages, shared ADO throttling pause).
# -----------------------------------------------------------------------------

set -euo pipefail

# Copyright (c) 2025 Vamsi Cherukuri, Microsoft
# 
# MIT License
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Verify GitHub CLI is available
if ! command -v gh &> /dev/null; then
    echo "ERROR: GitHub CLI (gh) not found. Please install it first."
    exit 1
fi

# ADO2GH: Rewire Pipelines
# 
# Description:
#   Rewires Azure DevOps pipelines to GitHub repositories.
#   Reads pipeline information from pipelines.csv and executes rewiring for each pipeline.
#
# Prerequisites:
#   - ADO_PAT and GH_PAT environment variables set
#   - curl and jq installed (used to verify each claimed rewire against ADO's own API -
#     auto-installed via apt on a Linux agent if missing; on Windows/Git Bash install jq
#     yourself first, e.g. `winget install jqlang.jq`, curl ships with Git Bash)
#   - pipelines.csv, in this same directory (misc/), with required columns:
#     org, teamproject, pipeline_id, github_org, github_repo, serviceConnection
#     (also needs repo, so rows can be cross-referenced against repos-migration-status.csv below)
#   - repos-migration-status.csv, in your current working directory (NOT next to the script),
#     with a repo/migration_status column pair - only rows for that repo marked "Success" get
#     rewired. Get both CSVs from a real migration run's `migration-results` pipeline artifact,
#     then trim pipelines.csv down to just the pipeline_ids you want to remediate.
#     misc/pipelines.csv and misc/repos-migration-status.csv are header-only placeholders for
#     these - copy real data into a working copy, don't edit those files in place.
#
# Usage:
#   cd misc
#   export ADO_PAT="..." GH_PAT="..."
#   ./4_rewire_pipeline_local.sh
#
# Output:
#   pipeline-rewiring-status.csv (columns: org,teamproject,repo,pipeline_id,pipeline,
#   github_org,github_repo,rewire_status,details) plus a detailed .log file, both written to
#   the current directory - nothing is uploaded anywhere, this is local-only.
#
# Workflow:
#   [Step 0] Validate/install curl and jq
#   [Step 1] Validate PAT tokens (ADO_PAT and GH_PAT)
#   [Step 2] Validate pipelines.csv file and required columns
#   [Step 3] Validate service connection IDs (no placeholders)
#   [Step 4] Execute pipeline rewiring, verifying each claimed success against ADO's API
#   [Step 5] Generate summary and log file

# --- Configuration ---

PIPELINES_FILE="pipelines.csv"
REQUIRED_COLUMNS=("org" "teamproject" "pipeline_id" "github_org" "github_repo" "serviceConnection")
PLACEHOLDER_VALUES=("your-service-connection-id" "placeholder" "TODO" "TBD" "xxx" "")

# Force mktemp to use a disk-backed directory instead of the default $TMPDIR (often tmpfs,
# i.e. RAM-backed, on Linux agents). Each concurrent rewiring job writes gh-ado2gh's verbose
# log (up to ~150MB, more under API retries) into its own mktemp -d; running MAX_CONCURRENT
# of those in RAM at once can exhaust agent memory and get jobs OOM-killed mid-run, which
# surfaces here as "Job produced no result file" with no underlying error.
export TMPDIR="$(pwd)/.rewire-tmp"
mkdir -p "$TMPDIR"
trap 'rm -rf "$TMPDIR"' EXIT

DETAILED_LOG=$(mktemp)
# How many pipelines to rewire concurrently. Override without editing this file by
# setting REWIRE_MAX_CONCURRENT as a pipeline/environment variable (e.g. for a pilot run).
MAX_CONCURRENT="${REWIRE_MAX_CONCURRENT:-5}"

# If a rewire attempt comes back FAILED or SKIPPED_REWIRING and its output matches this, it's
# retried with jittered backoff instead of being marked final immediately. Deliberately
# text-based rather than a bare "429": ADO's hard-block (TF400733) is normally only visible at
# a verbose log level gh-ado2gh doesn't emit by default, so what actually surfaces here is
# .NET's generic wrapped exception - "Response status code does not indicate success: 429
# (Too Many Requests)." - which "too many requests" already catches; TF400733 is kept only as
# a cheap defensive extra in case it ever does surface raw. A bare 429 was deliberately left
# out: a standalone number risks false-matching an unrelated 429 in the output (a work item
# ID, a PR number, etc.) with no accompanying rate-limit wording. A non-matching failure (bad
# service connection, pipeline genuinely broken, etc.) is NOT retried - retrying that would
# just waste time before failing anyway, since it isn't caused by throttling.
RATE_LIMIT_PATTERN='rate.?limit|too many requests|TF400733|abuse detection'
# Rate-limited pipelines get more attempts than other retryable failures (5xx, transport
# errors, unverified success): ADO's throttle clears by itself once load drops, so it's worth
# waiting out, while a 5xx that repeats 3 times probably won't.
RATE_LIMIT_MAX_ATTEMPTS="${RATE_LIMIT_MAX_ATTEMPTS:-5}"
TRANSIENT_MAX_ATTEMPTS="${TRANSIENT_MAX_ATTEMPTS:-3}"

# ADO rate-limits per identity over a sliding 5-minute window (200 TSTUs) and its delays stop
# "within five minutes" of consumption dropping
# (https://learn.microsoft.com/en-us/azure/devops/integrate/concepts/rate-limits). A job that
# just backs off 20-50s on its own while the other MAX_CONCURRENT-1 slots keep calling ADO on
# the same PAT only burns its attempts. So any job that sees throttling writes a shared "pause
# until" epoch to RATE_LIMIT_PAUSE_FILE: the main loop starts no new jobs and every job waits
# before its next ADO call until it passes. The length is ADO's Retry-After when we can see it
# (our own verify calls can; gh-ado2gh drops it on a 429 because it throws before reading the
# header), else RATE_LIMIT_PAUSE_SECONDS; capped at RATE_LIMIT_MAX_PAUSE_SECONDS so a bad
# header can't stall the run.
RATE_LIMIT_PAUSE_SECONDS="${RATE_LIMIT_PAUSE_SECONDS:-300}"
RATE_LIMIT_MAX_PAUSE_SECONDS="${RATE_LIMIT_MAX_PAUSE_SECONDS:-900}"
RATE_LIMIT_PAUSE_FILE="$TMPDIR/ado-rate-limit-pause-until"
# verify_pipeline_rewired's own tries when ADO answers 429 (each waits out the shared pause).
VERIFY_MAX_ATTEMPTS="${VERIFY_MAX_ATTEMPTS:-3}"

# gh-ado2gh v1.32.0 can internally fail to (re-)retrieve the pipeline definition mid-rewire
# with a generic transport-level error - "[WARNING] HTTP error retrieving pipeline <id> ...:
# An error occurred while sending the request.. Skipping pipeline rewiring." - and still exit
# 0. Before this pattern was added, that text matched none of the SKIPPED_REWIRING/
# ALREADY_MIGRATED checks below and fell through to SUCCESS, silently recording a pipeline as
# rewired when it was never touched (confirmed 2026-09-02: 12/431 pipelines in one run, no
# error text, no non-zero exit, only detectable by reading each pipeline's own log). Observed
# occurrences are scattered randomly across pipelines/time with no shared cause, consistent
# with a transient network blip rather than a permanent block, so it's retried like a
# rate-limit hit rather than failing immediately.
TRANSIENT_SKIP_PATTERN='skipping pipeline rewiring'

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
GRAY='\033[0;37m'
NC='\033[0m' # No Color

# Counters
SUCCESS_COUNT=0
FAILURE_COUNT=0
ALREADY_MIGRATED_COUNT=0
SKIPPED_COUNT=0
SKIPPED_REWIRING_COUNT=0
RATE_LIMIT_PAUSE_COUNT=0      # shared ADO throttling pauses the main loop honoured
PAUSE_ACTIVE=false
declare -a RESULTS=()
declare -a FAILED_DETAILS=()
declare -a ALREADY_MIGRATED_DETAILS=()
declare -a SKIPPED_DETAILS=()
declare -a SKIPPED_REWIRING=()
declare -A MIGRATED_REPOS=()  # Track successfully migrated repos
declare -a REPORT_ROWS=()     # One CSV row per pipeline processed (see write_report_row)
declare -A PIPELINE_REPO=()   # pipeline_id -> ADO repo name, for the CSV report
declare -A PIPELINE_NAME=()   # pipeline_id -> ADO pipeline name, for the CSV report
declare -A PIPELINE_ORG=()    # pipeline_id -> ADO org, for the CSV report

# --- Helper Functions ---

# Load repos-migration-status.csv to filter pipelines
load_migrated_repos() {
    local repos_status_csv="repos-migration-status.csv"
    
    if [ ! -f "$repos_status_csv" ]; then
        echo -e "${RED}❌ ERROR: repos-migration-status.csv not found${NC}"
        echo -e "${YELLOW}   Make sure Stage 3 (Migration) completed successfully${NC}"
        exit 1
    fi
    
    echo -e "${YELLOW}Loading successfully migrated repositories...${NC}"
    
    # Read repos-migration-status.csv and track Success repos
    while IFS=',' read -r org teamproject repo github_org github_repo visibility status; do
        # Remove quotes and whitespace
        repo=$(echo "$repo" | sed 's/^"//;s/"$//;s/^[[:space:]]*//;s/[[:space:]]*$//')
        status=$(echo "$status" | sed 's/^"//;s/"$//;s/^[[:space:]]*//;s/[[:space:]]*$//')
        
        if [ "$status" = "Success" ]; then
            MIGRATED_REPOS["$repo"]=1
        fi
    done < <(tail -n +2 "$repos_status_csv")
    
    echo -e "${GREEN}✅ Loaded ${#MIGRATED_REPOS[@]} successfully migrated repositories${NC}"
    
    # Debug: Show which repos were loaded
    if [ ${#MIGRATED_REPOS[@]} -gt 0 ]; then
        echo -e "${GRAY}   Successfully migrated repos:${NC}"
        for repo_name in "${!MIGRATED_REPOS[@]}"; do
            echo -e "${GRAY}     • '$repo_name'${NC}"
        done
    fi
    
    # Skip gracefully if no repos migrated successfully
    if [ ${#MIGRATED_REPOS[@]} -eq 0 ]; then
        echo -e "${YELLOW}⚠️ WARNING: No successfully migrated repositories found${NC}"
        echo -e "${YELLOW}   All repositories failed migration. Skipping rewiring.${NC}"
        echo "##[warning]No successfully migrated repositories to rewire - skipping rewiring stage"
        echo "Skipping pipeline rewiring as all repositories failed migration"
        exit 0
    fi
}

# Function to parse CSV line properly (handles quoted fields)
parse_csv_line() {
  local line="$1"
  local -a fields=()
  local field="" in_quotes=false i char next
  for ((i=0; i<${#line}; i++)); do
    char="${line:$i:1}"
    next="${line:$((i+1)):1}"
    if [[ "${char}" == '"' ]]; then
      if [[ "${in_quotes}" == true ]]; then
        if [[ "${next}" == '"' ]]; then
          field+='"'; ((i++))
        else
          in_quotes=false
        fi
      else
        in_quotes=true
      fi
    elif [[ "${char}" == ',' && "${in_quotes}" == false ]]; then
      fields+=("${field}")
      field=""
    else
      field+="${char}"
    fi
  done
  fields+=("${field}")
  printf '%s\n' "${fields[@]}"
}

# --- Shared ADO throttling pause (see RATE_LIMIT_PAUSE_FILE) ---
# Messages here say "throttling", never "rate limit": they can land in a log that's grepped
# for RATE_LIMIT_PATTERN, and must not make an unrelated failure look rate-limited.

# Seconds left on the shared pause (0 if none).
rate_limit_pause_remaining() {
    local until now
    until=$(cat "$RATE_LIMIT_PAUSE_FILE" 2>/dev/null || true)
    if [[ ! "$until" =~ ^[0-9]+$ ]]; then
        echo 0
        return 0
    fi
    now=$(date +%s)
    if (( until > now )); then echo $(( until - now )); else echo 0; fi
}

# Extend (never shorten) the shared pause to <seconds> from now. Written to a temp file and
# renamed into place, so a concurrent reader never sees a half-written value.
set_rate_limit_pause() {
    local seconds="$1" reason="$2" until current tmp
    [[ "$seconds" =~ ^[0-9]+$ ]] || seconds="$RATE_LIMIT_PAUSE_SECONDS"
    if (( seconds < 1 )); then seconds=1; fi
    if (( seconds > RATE_LIMIT_MAX_PAUSE_SECONDS )); then seconds="$RATE_LIMIT_MAX_PAUSE_SECONDS"; fi
    until=$(( $(date +%s) + seconds ))
    current=$(cat "$RATE_LIMIT_PAUSE_FILE" 2>/dev/null || true)
    if [[ "$current" =~ ^[0-9]+$ ]] && (( current >= until )); then
        return 0
    fi
    tmp="${RATE_LIMIT_PAUSE_FILE}.${BASHPID}.${RANDOM}"
    printf '%s\n' "$until" > "$tmp" && mv -f "$tmp" "$RATE_LIMIT_PAUSE_FILE"
    echo "[$(date)] ADO throttling: pausing new ADO calls for ${seconds}s - ${reason}" >&2
}

# Block until the shared pause has passed. Re-checked at least every 30s since another job can
# extend it meanwhile; a little jitter afterwards so waiting jobs don't all resume at once.
wait_for_rate_limit_pause() {
    local left waited=false
    while :; do
        left=$(rate_limit_pause_remaining)
        if (( left <= 0 )); then
            break
        fi
        if [[ "$waited" == false ]]; then
            echo "[$(date)] ADO throttling: waiting ${left}s for the shared pause to end" >&2
        fi
        waited=true
        sleep $(( left < 30 ? left : 30 ))
    done
    if [[ "$waited" == true ]]; then
        sleep $(( RANDOM % 15 ))
    fi
}

# Ground-truth check, not just text matching: gh-ado2gh has now been shown (2026-09-02, see
# TRANSIENT_SKIP_PATTERN above) to exit 0 and claim success for pipelines it never actually
# rewired - caught there only because that failure happened to print recognizable text. There
# is no guarantee every way gh-ado2gh can silently no-op prints anything - so instead of adding
# more regexes as new failure text turns up, any claimed SUCCESS is confirmed directly against
# ADO's own build-definitions API before being trusted. Response shapes were confirmed by
# probing ADO directly (2026-09-02): a GitHub-rewired definition reports
# repository.type="GitHub" and repository.name="<org>/<repo>" (pipeline_id=68323); an
# un-rewired one reports type="TfsGit" with a bare repo name (pipeline_ids 11260, 67521 -
# both still TfsGit despite gh having exited 0 for them). Any curl/parse failure here counts
# as NOT verified (fail closed) - an unverifiable claim of success is treated the same as a
# false one.
#
# Returns 0 = verified, 1 = not verified, 2 = could not verify because ADO kept answering 429.
# Honours ADO's Retry-After on any response - ADO sends it before it starts delaying requests,
# not only with a 429 - by extending the shared pause for every job (see RATE_LIMIT_PAUSE_FILE).
verify_pipeline_rewired() {
    local ado_org="$1" ado_project="$2" ado_pipeline_id="$3" github_org="$4" github_repo="$5"
    local enc_org enc_project url body_file hdr_file http_code retry_after vattempt
    local response repo_type repo_name

    enc_org=$(jq -rn --arg s "$ado_org" '$s|@uri')
    enc_project=$(jq -rn --arg s "$ado_project" '$s|@uri')
    url="https://dev.azure.com/${enc_org}/${enc_project}/_apis/build/definitions/${ado_pipeline_id}?api-version=7.1"
    body_file=$(mktemp)
    hdr_file=$(mktemp)

    for ((vattempt=1; vattempt<=VERIFY_MAX_ATTEMPTS; vattempt++)); do
        wait_for_rate_limit_pause
        : > "$body_file"
        : > "$hdr_file"
        http_code=$(curl -s -o "$body_file" -D "$hdr_file" -w '%{http_code}' --max-time 30 \
            -H "Authorization: Basic ${ADO_AUTH_B64}" "$url" || true)
        [[ "$http_code" =~ ^[0-9]{3}$ ]] || http_code="000"

        retry_after=$(grep -i '^retry-after:' "$hdr_file" 2>/dev/null | tail -n 1 | tr -d '\r' | sed -E 's/^[^:]*:[[:space:]]*//;s/[[:space:]]*$//' || true)
        if [[ "$retry_after" =~ ^[0-9]+$ ]]; then
            set_rate_limit_pause "$retry_after" "ADO sent Retry-After: ${retry_after} (HTTP ${http_code}) verifying pipeline_id=${ado_pipeline_id}"
        else
            retry_after=""  # absent, or an HTTP-date form ADO isn't documented to send
        fi

        [[ "$http_code" == "429" ]] || break

        if [[ -z "$retry_after" ]]; then
            set_rate_limit_pause "$RATE_LIMIT_PAUSE_SECONDS" "ADO answered HTTP 429 without Retry-After verifying pipeline_id=${ado_pipeline_id}"
        fi
        echo "[ADO verify] pipeline_id=${ado_pipeline_id}: HTTP 429 (Too Many Requests) (verify attempt ${vattempt}/${VERIFY_MAX_ATTEMPTS})" >&2
    done

    response=$(cat "$body_file" 2>/dev/null || true)
    rm -f "$body_file" "$hdr_file"

    if [[ "$http_code" == "429" ]]; then
        echo "[ADO verify] pipeline_id=${ado_pipeline_id}: could not verify - ADO still answering HTTP 429 (Too Many Requests) after ${VERIFY_MAX_ATTEMPTS} attempts" >&2
        return 2
    fi

    if ! echo "$response" | jq -e . >/dev/null 2>&1; then
        echo "[ADO verify] pipeline_id=${ado_pipeline_id}: could not parse ADO API response (HTTP ${http_code}) - treating as NOT verified" >&2
        return 1
    fi

    repo_type=$(echo "$response" | jq -r '.repository.type // empty')
    repo_name=$(echo "$response" | jq -r '.repository.name // empty')

    if [[ "$repo_type" == "GitHub" && "$repo_name" == "${github_org}/${github_repo}" ]]; then
        echo "[ADO verify] pipeline_id=${ado_pipeline_id}: confirmed via ADO API - repository.type=GitHub, repository.name=${repo_name}" >&2
        return 0
    else
        echo "[ADO verify] pipeline_id=${ado_pipeline_id}: NOT verified - ADO API reports repository.type='${repo_type:-<empty>}', repository.name='${repo_name:-<empty>}' (expected GitHub, ${github_org}/${github_repo})" >&2
        return 1
    fi
}

# Quote a single value for safe inclusion as one CSV field (doubles embedded quotes).
csv_field() {
    local val="$1"
    val="${val//\"/\"\"}"
    printf '"%s"' "$val"
}

# Append one row to REPORT_ROWS for the pipeline-rewiring-status CSV.
write_report_row() {
    local org="$1" project="$2" repo="$3" pipeline_id="$4" pipeline_name="$5"
    local github_org="$6" github_repo="$7" status="$8" details="$9"
    REPORT_ROWS+=("$(csv_field "$org"),$(csv_field "$project"),$(csv_field "$repo"),$(csv_field "$pipeline_id"),$(csv_field "$pipeline_name"),$(csv_field "$github_org"),$(csv_field "$github_repo"),$(csv_field "$status"),$(csv_field "$details")")
}

# ========================================
# MAIN SCRIPT
# ========================================
echo -e "\n${CYAN}========================================${NC}"
echo -e "${CYAN}  ADO2GH: Rewire Pipelines${NC}"
echo -e "${CYAN}========================================${NC}\n"

# ========================================
# STEP 0: Validate required CLI tools (curl, jq)
# ========================================
# verify_pipeline_rewired() needs both to confirm rewiring against the ADO API. Unlike
# MigrationReadinessCheck's job (which installs jq via a dedicated step), this stage's YAML
# never has - and a self-hosted agent job isn't guaranteed to land on a machine where some
# other stage already installed it. Checked/installed up front, before any pipeline work
# starts, so a missing tool fails fast with one clear message instead of silently making
# verify_pipeline_rewired() fail-closed for every single pipeline in the run.
echo -e "${YELLOW}Checking required tools (curl, jq)...${NC}"
for tool in curl jq; do
    if command -v "$tool" >/dev/null 2>&1; then
        continue
    fi
    if command -v apt-get >/dev/null 2>&1 && command -v sudo >/dev/null 2>&1; then
        echo -e "${YELLOW}⚠️  '$tool' not found - installing via apt...${NC}"
        sudo apt-get update -qq && sudo apt-get install -y "$tool"
    fi
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo -e "${RED}❌ ERROR: required tool '$tool' is not installed and could not be auto-installed${NC}"
        echo -e "${YELLOW}   On the Linux agent: sudo apt-get install -y $tool${NC}"
        echo -e "${YELLOW}   On Windows/Git Bash (local run): winget install jqlang.jq (curl ships with Git Bash)${NC}"
        exit 1
    fi
done
echo -e "${GREEN}✅ curl and jq available${NC}"

# Load successfully migrated repositories first
load_migrated_repos

# ========================================
# STEP 1: Validate PAT Tokens
# ========================================
echo -e "${YELLOW}[Step 1/4] Validating PAT tokens...${NC}"

if [ -z "$ADO_PAT" ]; then
    echo -e "${RED}❌ ERROR: ADO_PAT environment variable is not set${NC}"
    exit 1
fi

if [ -z "$GH_PAT" ]; then
    echo -e "${RED}❌ ERROR: GH_PAT environment variable is not set${NC}"
    exit 1
fi

echo -e "${GREEN}✅ PAT tokens validated${NC}"

# Basic-auth header for direct ADO REST calls (verify_pipeline_rewired below), same encoding
# used by 3_post_migration_validation.sh / 1_pr_pipeline_check.sh elsewhere in this repo.
ADO_AUTH_B64=$(printf ":%s" "$ADO_PAT" | base64 -w 0 2>/dev/null || printf ":%s" "$ADO_PAT" | base64)

# ========================================
# STEP 2: Validate pipelines.csv File
# ========================================
echo -e "\n${YELLOW}[Step 2/4] Validating pipelines.csv file...${NC}"

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CSV_PATH="$SCRIPT_DIR/$PIPELINES_FILE"

# Check file exists
if [ ! -f "$CSV_PATH" ]; then
    echo -e "${RED}❌ ERROR: Pipeline file not found: $CSV_PATH${NC}"
    echo -e "${YELLOW}   Please ensure pipelines.csv exists in the current directory${NC}"
    exit 1
fi

# Load CSV and count lines
TOTAL_LINES=$(wc -l < "$CSV_PATH")
PIPELINE_COUNT=$((TOTAL_LINES - 1))  # Subtract header

if [ $PIPELINE_COUNT -eq 0 ]; then
    echo -e "${YELLOW}⚠️  No pipelines found in CSV file${NC}"
    echo -e "${GRAY}   Nothing to process. Exiting.${NC}"
    exit 0
fi

echo -e "${GREEN}✅ File loaded: $PIPELINE_COUNT pipeline(s) found${NC}"

# ========================================
# STEP 3: Validate Required Columns
# ========================================
echo -e "\n${YELLOW}[Step 3/4] Validating CSV columns and data...${NC}"

# Read header and validate columns
IFS=',' read -ra CSV_COLUMNS <<< "$(head -n 1 "$CSV_PATH")"

# Remove quotes and whitespace from column names
for i in "${!CSV_COLUMNS[@]}"; do
    CSV_COLUMNS[$i]=$(echo "${CSV_COLUMNS[$i]}" | sed 's/^"//;s/"$//;s/^[[:space:]]*//;s/[[:space:]]*$//')
done

# Check for missing columns
MISSING_COLUMNS=()
for req_col in "${REQUIRED_COLUMNS[@]}"; do
    found=false
    for csv_col in "${CSV_COLUMNS[@]}"; do
        if [ "$csv_col" = "$req_col" ]; then
            found=true
            break
        fi
    done
    if [ "$found" = "false" ]; then
        MISSING_COLUMNS+=("$req_col")
    fi
done

if [ ${#MISSING_COLUMNS[@]} -gt 0 ]; then
    echo -e "${RED}❌ ERROR: CSV is missing required columns: ${MISSING_COLUMNS[*]}${NC}"
    echo -e "${YELLOW}   Required columns: ${REQUIRED_COLUMNS[*]}${NC}"
    echo -e "${GRAY}   Found columns: ${CSV_COLUMNS[*]}${NC}"
    exit 1
fi

echo -e "${GREEN}✅ All required columns present${NC}"

# Get column indices
declare -A COL_INDEX
for i in "${!CSV_COLUMNS[@]}"; do
    COL_INDEX["${CSV_COLUMNS[$i]}"]=$i
done

# Validate service connection IDs
echo -e "${GRAY}   Validating service connection IDs...${NC}"
INVALID_ROWS=()
ROW_NUM=1

while IFS= read -r line; do
    ROW_NUM=$((ROW_NUM + 1))
    
    # Parse CSV line
    IFS=',' read -ra fields <<< "$line"
    
    # Remove quotes
    for i in "${!fields[@]}"; do
        fields[$i]=$(echo "${fields[$i]}" | sed 's/^"//;s/"$//')
    done
    
    # Get service connection ID
    SERVICE_CONN_ID="${fields[${COL_INDEX["serviceConnection"]}]}"
    PIPELINE_ID="${fields[${COL_INDEX["pipeline_id"]}]}"

    # Check if empty or placeholder
    if [ -z "$SERVICE_CONN_ID" ]; then
        INVALID_ROWS+=("Row $ROW_NUM: pipeline_id=$PIPELINE_ID - Empty service connection ID")
    else
        for placeholder in "${PLACEHOLDER_VALUES[@]}"; do
            if [ "$SERVICE_CONN_ID" == "$placeholder" ]; then
                INVALID_ROWS+=("Row $ROW_NUM: pipeline_id=$PIPELINE_ID - Placeholder value: '$SERVICE_CONN_ID'")
                break
            fi
        done
    fi
done < <(tail -n +2 "$CSV_PATH")

if [ ${#INVALID_ROWS[@]} -gt 0 ]; then
    echo -e "\n${RED}❌ ERROR: Invalid service connection IDs found${NC}"
    echo -e "${YELLOW}   The following rows have issues:\n${NC}"
    
    for invalid in "${INVALID_ROWS[@]}"; do
        echo -e "${YELLOW}      $invalid${NC}"
    done
    
    echo -e "\n${CYAN}   💡 How to fix:${NC}"
    echo -e "${GRAY}      1. Go to Azure DevOps → Project Settings → Service Connections${NC}"
    echo -e "${GRAY}      2. Find your GitHub service connection${NC}"
    echo -e "${GRAY}      3. Copy the connection ID (GUID format)${NC}"
    echo -e "${GRAY}      4. Update the 'serviceConnection' column in pipelines.csv${NC}"
    exit 1
fi

echo -e "${GREEN}✅ All service connection IDs validated${NC}"

# ========================================
# STEP 4: Rewire Pipelines (parallel, up to MAX_CONCURRENT at a time)
# ========================================
echo -e "\n${YELLOW}[Step 4/4] Rewiring pipelines to GitHub (up to ${MAX_CONCURRENT} concurrent)...${NC}"

# Runs one pipeline's rewire in the background. Writes full gh output to $7 (log_file,
# swept into the 'rewiring-logs' artifact by the existing YAML collection step) and a
# one-line-status + one-line-message verdict to "$7.result" for the parent to read back.
#
# gh-ado2gh always writes a *.octoshift.log (~1KB) and *.octoshift.verbose.log (~150MB)
# per invocation into its CWD, with no flag/env var to disable it. Each job runs it inside
# its own temp dir so concurrent jobs can't collide. The small *.octoshift.log duplicates
# what we already capture below (gh's stdout/stderr), so it's discarded along with the
# temp dir; the ~150MB verbose log is only kept (renamed so it survives the YAML's
# exclusion filter) when the pipeline actually failed/was skipped.
rewire_pipeline_job() {
    local ado_org="$1" ado_project="$2" ado_pipeline_id="$3"
    local github_org="$4" github_repo="$5" service_connection_id="$6" log_file="$7"

    local orig_dir; orig_dir="$(pwd)"
    local abs_log_file="${orig_dir}/${log_file}"
    : > "$abs_log_file"

    local attempt result_type message keep_verbose
    # Bounded inside: every path breaks, except a retry, which needs attempt < TRANSIENT_ or
    # RATE_LIMIT_MAX_ATTEMPTS.
    for ((attempt=1; ; attempt++)); do
        # On a retry, first check whether an earlier attempt did rewire the pipeline after all
        # (e.g. its success couldn't be verified while ADO was throttling). Re-running
        # gh-ado2gh costs another ~150MB branch-policy download - the kind of load that gets
        # this identity throttled in the first place - while this check is one small GET.
        if (( attempt > 1 )); then
            local pre_rc=0
            verify_pipeline_rewired "$ado_org" "$ado_project" "$ado_pipeline_id" "$github_org" "$github_repo" 2>> "$abs_log_file" || pre_rc=$?
            if [[ $pre_rc -eq 0 ]]; then
                echo "[$(date)] pipeline_id=${ado_pipeline_id} already points at ${github_org}/${github_repo} (confirmed via ADO API) - not re-running gh-ado2gh" >> "$abs_log_file"
                result_type="SUCCESS"
                message=" "
                rm -f "${orig_dir}/rewire-${ado_pipeline_id}-verbose.log"
                break
            fi
        fi

        # Each attempt's output is judged in isolation (attempt_log), then folded into the
        # permanent per-pipeline log - classifying against the cumulative log across retries
        # would let an earlier failed attempt's text (e.g. an error mentioning "404") leak
        # into the verdict for a later, successful attempt.
        local attempt_log; attempt_log="$(mktemp)"
        local octoshift_dir; octoshift_dir=$(mktemp -d)
        # gh's output is also kept on its own (gh_out) and all classification greps run on it
        # alone: attempt_log's header lines contain repo/project names, and a repo named e.g.
        # "..._RateLimiter" or "..._ErrorHandler" must not match a failure/rate-limit pattern.
        local gh_out; gh_out="$(mktemp)"

        # Waited on as the last step before launching gh, so a pause another job set meanwhile
        # - or that the pre-check above set when it hit 429s - is still honoured. Nothing between
        # here and the launch forks a process (printf's %()T is a bash builtin), keeping that
        # window as small as possible.
        wait_for_rate_limit_pause 2>> "$abs_log_file"
        {
            printf '[%(%a %b %d %T %Z %Y)T] Rewiring pipeline_id=%s (attempt %d): %s/%s -> %s/%s\n' \
                -1 "$ado_pipeline_id" "$attempt" "$ado_org" "$ado_project" "$github_org" "$github_repo"
            printf 'Running: gh ado2gh rewire-pipeline --ado-org %s --ado-team-project %s --ado-pipeline-id %s --github-org %s --github-repo %s --service-connection-id %s\n' \
                "$ado_org" "$ado_project" "$ado_pipeline_id" "$github_org" "$github_repo" "$service_connection_id"
        } > "$attempt_log"

        cd "$octoshift_dir" || true
        local rc=0
        gh ado2gh rewire-pipeline \
            --ado-org "$ado_org" \
            --ado-team-project "$ado_project" \
            --ado-pipeline-id "$ado_pipeline_id" \
            --github-org "$github_org" \
            --github-repo "$github_repo" \
            --service-connection-id "$service_connection_id" > "$gh_out" 2>&1 || rc=$?
        cat "$gh_out" >> "$attempt_log"

        cd "$orig_dir" || true

        # gh-ado2gh honours Retry-After only while ADO still answers 200 (the "delay" phase,
        # before it starts returning 429), logging "THROTTLING IN EFFECT. Waiting <n> ms" -
        # the earliest sign this identity is near its limit. Only that gh process slows down,
        # so pass it on to every other job through the shared pause.
        local throttle_ms
        throttle_ms=$(grep -oE "THROTTLING IN EFFECT\. Waiting [0-9]+ ms" "$gh_out" | grep -oE "[0-9]+" | sort -n | tail -n 1 || true)
        if [[ -n "$throttle_ms" ]]; then
            set_rate_limit_pause $(( (throttle_ms + 999) / 1000 )) "gh-ado2gh reported THROTTLING IN EFFECT (${throttle_ms} ms) on pipeline_id=${ado_pipeline_id}" 2>> "$abs_log_file"
        fi

        keep_verbose=false
        local is_retryable=false
        local is_rate_limited=false
        if [[ $rc -eq 0 ]]; then
            # CATCH HIDDEN ERRORS (400, 403, 500, etc.) and internal skips - gh-ado2gh can print
            # either or both (its skip warning embeds the HTTP error: "...does not indicate
            # success: 500 (Internal Server Error).. Skipping pipeline rewiring.") and still
            # exit 0. Both are handled in one branch so the retry decision depends on the HTTP
            # status, not on which of the two phrases happened to be checked first.
            if grep -qiE "does not indicate success|$TRANSIENT_SKIP_PATTERN" "$gh_out"; then
                result_type="SKIPPED_REWIRING"
                keep_verbose=true
                # Take gh's own line - a loose "[0-9]{3} \(.*\)" over the whole attempt log also
                # matched this script's header ("pipeline_id=59425 (attempt 1/3)") and reported
                # "425 (attempt 1/3)" as the error (seen 2026-09-30).
                message=$(grep -iE "does not indicate success|$TRANSIENT_SKIP_PATTERN" "$gh_out" | tail -n 1 | sed -E 's/^\[[^]]*\]\s*(\[(WARNING|ERROR)\]\s*)?//' || true)
                local http_status
                http_status=$(grep -oiE "does not indicate success: [0-9]{3}" "$gh_out" | tail -n 1 | grep -oE "[0-9]{3}$" || true)
                # Retry when the cause can plausibly clear on its own: no HTTP status at all (a
                # transport error, e.g. "An error occurred while sending the request", see
                # TRANSIENT_SKIP_PATTERN above) or a 5xx. A 4xx (bad service connection, missing
                # permission, pipeline not found) would fail the same way again, so it isn't.
                # The 5xx seen 2026-09-30 (11/663 pipelines) was ADO rejecting the PUT with
                # CannotUpdateStaleDefinitionException - the definition's revision changed during
                # gh-ado2gh's ~70s GET->PUT window - and a retry re-reads the definition, so it
                # picks up the current revision.
                if [[ -z "$http_status" || "$http_status" == 5* ]]; then
                    is_retryable=true
                fi
                # The real ADO error body is only in the verbose log (the stdout line just says
                # "500 (Internal Server Error)"); surface the stale-definition case explicitly so
                # the CSV/summary say what actually happened.
                if grep -qsF "CannotUpdateStaleDefinitionException" "$octoshift_dir"/*.octoshift.verbose.log; then
                    message="${message} [ADO: CannotUpdateStaleDefinitionException - pipeline definition was modified while it was being rewired]"
                fi
                message="${message:-gh-ado2gh reported an API error and skipped rewiring}"
            elif grep -qiE "repository.*type.*GitHub|already.*github|404.*Not Found" "$gh_out"; then
                result_type="ALREADY_MIGRATED"
                # "|| true": the branch can match on a line with none of these words, and a grep
                # with no match would kill this job under set -euo pipefail (see FAILED below).
                message=$(grep -iE "warning|404|Not Found" "$gh_out" | head -n 1 || true)
                message="${message:-Pipeline repository type is already '"'"'GitHub'"'"'}"
            else
                local verify_rc=0
                verify_pipeline_rewired "$ado_org" "$ado_project" "$ado_pipeline_id" "$github_org" "$github_repo" 2>> "$attempt_log" || verify_rc=$?
                if [[ $verify_rc -eq 0 ]]; then
                    result_type="SUCCESS"
                    message=" "
                elif [[ $verify_rc -eq 2 ]]; then
                    # Unknown, not failed: the retry's pre-check verifies again once the shared
                    # pause is over, before re-running gh-ado2gh.
                    result_type="SKIPPED_REWIRING"
                    message="gh-ado2gh reported success but it could not be verified - ADO kept answering HTTP 429 (Too Many Requests) to the verification call"
                    keep_verbose=true
                    is_retryable=true
                    is_rate_limited=true
                else
                    # gh exited 0 with no recognizable failure text, but ADO's own record says the
                    # pipeline still isn't pointed at GitHub - see verify_pipeline_rewired above.
                    result_type="SKIPPED_REWIRING"
                    message="gh-ado2gh reported success but ADO pipeline_id=${ado_pipeline_id} still does not point at ${github_org}/${github_repo} - verified against ADO API"
                    keep_verbose=true
                    is_retryable=true
                fi
            fi
        else
            result_type="FAILED"
            # "|| true": with no matching line grep exits 1, which (set -euo pipefail) would kill
            # this background job before it writes its .result file.
            message=$(grep -iE "error|fail|exception" "$gh_out" | head -n 3 | tr '\n' ' ' || true)
            message="${message:-Unknown error during pipeline rewiring}"
            keep_verbose=true
        fi

        cat "$attempt_log" >> "$abs_log_file"
        echo "" >> "$abs_log_file"

        if [[ "$keep_verbose" == true ]] && grep -qiE "$RATE_LIMIT_PATTERN" "$gh_out"; then
            is_retryable=true
            is_rate_limited=true
            # gh-ado2gh doesn't expose ADO's Retry-After on a 429 (see RATE_LIMIT_PAUSE_FILE),
            # so the pause is the default length - Microsoft's documented recovery window.
            set_rate_limit_pause "$RATE_LIMIT_PAUSE_SECONDS" "gh-ado2gh hit ADO throttling on pipeline_id=${ado_pipeline_id}" 2>> "$abs_log_file"
        fi

        if [[ "$keep_verbose" == true ]]; then
            local verbose_log
            verbose_log=$(find "$octoshift_dir" -maxdepth 1 -name "*.octoshift.verbose.log" | head -n 1)
            # Overwrites any verbose log kept by an earlier attempt for this same pipeline -
            # only the most recent attempt's diagnostic is worth keeping.
            [[ -n "$verbose_log" ]] && cp "$verbose_log" "${orig_dir}/rewire-${ado_pipeline_id}-verbose.log"
        fi
        rm -rf "$octoshift_dir"
        rm -f "$attempt_log" "$gh_out"

        if [[ "$result_type" == "SUCCESS" || "$result_type" == "ALREADY_MIGRATED" ]]; then
            # A retry succeeded: drop the verbose log an earlier failed attempt kept, so a
            # ~150MB log doesn't land in the rewiring-logs artifact for a pipeline that's fine.
            rm -f "${orig_dir}/rewire-${ado_pipeline_id}-verbose.log"
            break
        fi

        local attempt_limit="$TRANSIENT_MAX_ATTEMPTS"
        if [[ "$is_rate_limited" == true ]]; then
            attempt_limit="$RATE_LIMIT_MAX_ATTEMPTS"
        fi
        if [[ "$is_retryable" == true && $attempt -lt $attempt_limit ]]; then
            if [[ "$is_rate_limited" == true ]]; then
                # No fixed backoff: the shared pause just set (or extended) is the wait - the
                # next attempt's pre-check and gh launch both wait it out first.
                echo "[$(date)] Retryable failure detected ($result_type, ADO throttling) - retrying after the shared pause (attempt $((attempt + 1))/${attempt_limit})..." >> "$abs_log_file"
            else
                local backoff=$(( attempt * 20 + (RANDOM % 10) ))
                echo "[$(date)] Retryable failure detected ($result_type), retrying in ${backoff}s (attempt $((attempt + 1))/${attempt_limit})..." >> "$abs_log_file"
                sleep "$backoff"
            fi
            continue
        fi

        break
    done

    printf '%s\n%s\n' "$result_type" "$message" > "${log_file}.result"
}

declare -A JOB_PIDS=()   # pid -> pipeline_id (debug/reference only)
declare -A JOB_LOG=()    # pid -> log file
declare -A JOB_META=()   # pid -> "project|pipeline_id|github_org|github_repo"

QUEUE=()

while IFS= read -r line; do
    IFS=',' read -ra fields <<< "$line"
    for i in "${!fields[@]}"; do
        fields[$i]=$(echo "${fields[$i]}" | sed 's/^"//;s/"$//')
    done

    ADO_ORG="${fields[${COL_INDEX["org"]}]}"
    ADO_PROJECT="${fields[${COL_INDEX["teamproject"]}]}"
    ADO_REPO="${fields[${COL_INDEX["repo"]}]}"
    ADO_PIPELINE_ID="${fields[${COL_INDEX["pipeline_id"]}]}"
    GITHUB_ORG="${fields[${COL_INDEX["github_org"]}]}"
    GITHUB_REPO="${fields[${COL_INDEX["github_repo"]}]}"
    SERVICE_CONNECTION_ID="${fields[${COL_INDEX["serviceConnection"]}]}"

    # "pipeline" (display name) isn't in REQUIRED_COLUMNS, so guard against it being absent.
    if [ -n "${COL_INDEX["pipeline"]+x}" ]; then
        ADO_PIPELINE_NAME="${fields[${COL_INDEX["pipeline"]}]}"
    else
        ADO_PIPELINE_NAME=""
    fi
    PIPELINE_REPO["$ADO_PIPELINE_ID"]="$ADO_REPO"
    PIPELINE_NAME["$ADO_PIPELINE_ID"]="$ADO_PIPELINE_NAME"
    PIPELINE_ORG["$ADO_PIPELINE_ID"]="$ADO_ORG"

    # Check if repo successfully migrated (safe check for associative array) - no gh
    # call involved, so this stays a cheap synchronous filter before queuing jobs.
    if [ -z "${MIGRATED_REPOS[$ADO_REPO]+x}" ]; then
        SKIPPED_COUNT=$((SKIPPED_COUNT + 1))
        echo -e "${YELLOW}   ⏭️  Skipping: pipeline_id=$ADO_PIPELINE_ID${NC}"
        echo -e "${GRAY}      Reason: Repository '$ADO_REPO' failed migration (not in repos-migration-status.csv as Success)${NC}"
        SKIPPED_DETAILS+=("$ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID: Repository '$ADO_REPO' not found in repos-migration-status.csv or migration failed")
        write_report_row "$ADO_ORG" "$ADO_PROJECT" "$ADO_REPO" "$ADO_PIPELINE_ID" "$ADO_PIPELINE_NAME" \
            "$GITHUB_ORG" "$GITHUB_REPO" "Skipped" "Repository '$ADO_REPO' not found in repos-migration-status.csv or migration failed"
        continue
    fi

    QUEUE+=("$ADO_ORG,$ADO_PROJECT,$ADO_PIPELINE_ID,$GITHUB_ORG,$GITHUB_REPO,$SERVICE_CONNECTION_ID")
done < <(tail -n +2 "$CSV_PATH")

echo -e "${GRAY}   Queued ${#QUEUE[@]} pipeline(s) for rewiring (${SKIPPED_COUNT} skipped, repo not migrated)${NC}"

while (( ${#QUEUE[@]} > 0 )) || (( ${#JOB_PIDS[@]} > 0 )); do

    # While a shared ADO throttling pause is in effect (see RATE_LIMIT_PAUSE_FILE), start no new
    # jobs - running ones wait on their own - so this identity's load actually drops.
    # Announced once per pause, not on every extension (each throttled job extends it).
    PAUSE_LEFT=$(rate_limit_pause_remaining)
    if (( PAUSE_LEFT > 0 )) && [[ "$PAUSE_ACTIVE" == false ]]; then
        PAUSE_ACTIVE=true
        RATE_LIMIT_PAUSE_COUNT=$((RATE_LIMIT_PAUSE_COUNT + 1))
        echo "##[warning]ADO is throttling this identity - starting no new rewires for at least ${PAUSE_LEFT}s (${#JOB_PIDS[@]} in progress, ${#QUEUE[@]} queued)"
    elif (( PAUSE_LEFT <= 0 )) && [[ "$PAUSE_ACTIVE" == true ]]; then
        PAUSE_ACTIVE=false
        echo -e "${YELLOW}   ADO throttling pause over - resuming rewires (${#QUEUE[@]} queued)${NC}"
    fi

    # Start new jobs up to the concurrency limit
    while (( PAUSE_LEFT <= 0 )) && (( ${#JOB_PIDS[@]} < MAX_CONCURRENT )) && (( ${#QUEUE[@]} > 0 )); do
        item="${QUEUE[0]}"
        QUEUE=("${QUEUE[@]:1}")
        IFS=',' read -r ADO_ORG ADO_PROJECT ADO_PIPELINE_ID GITHUB_ORG GITHUB_REPO SERVICE_CONNECTION_ID <<< "$item"

        LOG_FILE="rewire-${ADO_PIPELINE_ID}-$(date +%Y%m%d-%H%M%S).log"
        echo -e "${CYAN}   🔄 Starting: pipeline_id=$ADO_PIPELINE_ID ($ADO_PROJECT -> $GITHUB_ORG/$GITHUB_REPO)${NC}"

        rewire_pipeline_job "$ADO_ORG" "$ADO_PROJECT" "$ADO_PIPELINE_ID" "$GITHUB_ORG" "$GITHUB_REPO" "$SERVICE_CONNECTION_ID" "$LOG_FILE" &

        pid=$!
        JOB_PIDS["$pid"]="$ADO_PIPELINE_ID"
        JOB_LOG["$pid"]="$LOG_FILE"
        JOB_META["$pid"]="$ADO_PROJECT|$ADO_PIPELINE_ID|$GITHUB_ORG|$GITHUB_REPO"
    done

    # Reap completed jobs and fold their result into the same counters/arrays Step 5 already reads
    for pid in "${!JOB_PIDS[@]}"; do
        if ! ps -p "$pid" > /dev/null 2>&1; then
            wait "$pid" 2>/dev/null || true

            LOG_FILE="${JOB_LOG[$pid]}"
            IFS='|' read -r ADO_PROJECT ADO_PIPELINE_ID GITHUB_ORG GITHUB_REPO <<< "${JOB_META[$pid]}"

            RESULT_TYPE="FAILED"
            MESSAGE="Job produced no result file"
            if [ -f "${LOG_FILE}.result" ]; then
                mapfile -t RES < "${LOG_FILE}.result"
                RESULT_TYPE="${RES[0]:-FAILED}"
                MESSAGE="${RES[1]:-}"
                rm -f "${LOG_FILE}.result"
            fi

            # Preserve full command output for the rewiring-logs artifact / troubleshooting
            {
                echo "===== pipeline_id=$ADO_PIPELINE_ID ($ADO_PROJECT -> $GITHUB_ORG/$GITHUB_REPO): $RESULT_TYPE ====="
                cat "$LOG_FILE" 2>/dev/null
                echo ""
            } >> "$DETAILED_LOG"

            REPORT_ORG="${PIPELINE_ORG[$ADO_PIPELINE_ID]:-}"
            REPORT_REPO="${PIPELINE_REPO[$ADO_PIPELINE_ID]:-}"
            REPORT_PIPELINE_NAME="${PIPELINE_NAME[$ADO_PIPELINE_ID]:-}"

            case "$RESULT_TYPE" in
                SUCCESS)
                    SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
                    echo -e "${GREEN}      ✅ SUCCESS: pipeline_id=$ADO_PIPELINE_ID${NC}"
                    RESULTS+=("✅ SUCCESS | $ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID → $GITHUB_ORG/$GITHUB_REPO")
                    write_report_row "$REPORT_ORG" "$ADO_PROJECT" "$REPORT_REPO" "$ADO_PIPELINE_ID" "$REPORT_PIPELINE_NAME" \
                        "$GITHUB_ORG" "$GITHUB_REPO" "Success" "Rewired successfully"
                    ;;
                ALREADY_MIGRATED)
                    ALREADY_MIGRATED_COUNT=$((ALREADY_MIGRATED_COUNT + 1))
                    echo -e "${YELLOW}      ⚠️  ALREADY ON GITHUB: pipeline_id=$ADO_PIPELINE_ID${NC}"
                    echo "##[warning]Pipeline '$ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID' already points to GitHub repository. No rewiring needed."
                    RESULTS+=("⚠️  ALREADY ON GITHUB | $ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID → $GITHUB_ORG/$GITHUB_REPO")
                    ALREADY_MIGRATED_DETAILS+=("$ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID: $MESSAGE")
                    write_report_row "$REPORT_ORG" "$ADO_PROJECT" "$REPORT_REPO" "$ADO_PIPELINE_ID" "$REPORT_PIPELINE_NAME" \
                        "$GITHUB_ORG" "$GITHUB_REPO" "AlreadyOnGitHub" "$MESSAGE"
                    ;;
                SKIPPED_REWIRING)
                    SKIPPED_REWIRING_COUNT=$((SKIPPED_REWIRING_COUNT + 1))
                    echo -e "${RED}      ⚠️ WARNING: API FAILED - pipeline_id=$ADO_PIPELINE_ID - $MESSAGE${NC}"
                    echo "##vso[task.logissue type=warning]Pipeline pipeline_id=$ADO_PIPELINE_ID failed with $MESSAGE"
                    RESULTS+=("⚠️ WARNING | $ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID ($MESSAGE)")
                    SKIPPED_REWIRING+=("⚠️ $ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID: $MESSAGE")
                    write_report_row "$REPORT_ORG" "$ADO_PROJECT" "$REPORT_REPO" "$ADO_PIPELINE_ID" "$REPORT_PIPELINE_NAME" \
                        "$GITHUB_ORG" "$GITHUB_REPO" "Failed" "$MESSAGE"
                    ;;
                *)
                    FAILURE_COUNT=$((FAILURE_COUNT + 1))
                    echo -e "${RED}      ❌ FAILED: pipeline_id=$ADO_PIPELINE_ID - $MESSAGE${NC}"
                    echo "##[error]Failed to rewire pipeline: $ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID - $MESSAGE"
                    RESULTS+=("❌ FAILED | $ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID → $GITHUB_ORG/$GITHUB_REPO")
                    FAILED_DETAILS+=("$ADO_PROJECT/pipeline_id=$ADO_PIPELINE_ID: $MESSAGE")
                    write_report_row "$REPORT_ORG" "$ADO_PROJECT" "$REPORT_REPO" "$ADO_PIPELINE_ID" "$REPORT_PIPELINE_NAME" \
                        "$GITHUB_ORG" "$GITHUB_REPO" "Failed" "$MESSAGE"
                    ;;
            esac

            unset JOB_PIDS["$pid"] JOB_LOG["$pid"] JOB_META["$pid"]
        fi
    done

    sleep 0.5
done

# ========================================
# STEP 5: Generate Summary and Log
# ========================================
echo -e "\n${CYAN}========================================${NC}"
echo -e "${CYAN}  Pipeline Rewiring Summary${NC}"
echo -e "${CYAN}========================================${NC}"
echo -e "Total Pipelines: $PIPELINE_COUNT"
echo -e "${GREEN}Successful: $SUCCESS_COUNT${NC}"
echo -e "${YELLOW}Already on GitHub: $ALREADY_MIGRATED_COUNT${NC}"
echo -e "${YELLOW}Skipped (repo not migrated): $SKIPPED_COUNT${NC}"
echo -e "${YELLOW}Skipped (rewiring incomplete): $SKIPPED_REWIRING_COUNT${NC}"
echo -e "${RED}Failed: $FAILURE_COUNT${NC}"
if [ "$RATE_LIMIT_PAUSE_COUNT" -gt 0 ]; then
    echo -e "${YELLOW}ADO throttling pauses: $RATE_LIMIT_PAUSE_COUNT${NC}"
fi

echo -e "\n${CYAN}📋 Detailed Results:${NC}"
for result in "${RESULTS[@]}"; do
    echo -e "${GRAY}   $result${NC}"
done

# Show details for already migrated pipelines
if [ -n "${ALREADY_MIGRATED_DETAILS+x}" ] && [ ${#ALREADY_MIGRATED_DETAILS[@]} -gt 0 ]; then
    echo -e "\n${YELLOW}⚠️  Already on GitHub (No rewiring needed):${NC}"
    for detail in "${ALREADY_MIGRATED_DETAILS[@]}"; do
        echo -e "${GRAY}   • $detail${NC}"
    done
fi

# Show details for skipped pipelines
if [ -n "${SKIPPED_DETAILS+x}" ] && [ ${#SKIPPED_DETAILS[@]} -gt 0 ]; then
    echo -e "\n${YELLOW}⏭️  Skipped (Repository not migrated):${NC}"
    for detail in "${SKIPPED_DETAILS[@]}"; do
        echo -e "${GRAY}   • $detail${NC}"
    done
fi

# Show details for skipped rewiring
if [ -n "${SKIPPED_REWIRING+x}" ] && [ ${#SKIPPED_REWIRING[@]} -gt 0 ]; then
    echo -e "\n${YELLOW}⏭️  Skipped (rewiring incomplete):${NC}"
    for detail in "${SKIPPED_REWIRING[@]}"; do
        echo -e "${GRAY}   • $detail${NC}"
    done
fi

# Show details for failed pipelines
if [ -n "${FAILED_DETAILS+x}" ] && [ ${#FAILED_DETAILS[@]} -gt 0 ]; then
    echo -e "\n${RED}❌ Failed Pipelines:${NC}"
    for detail in "${FAILED_DETAILS[@]}"; do
        echo -e "${GRAY}   • $detail${NC}"
    done
fi

# Generate log file
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")
LOG_FILE="pipeline-rewiring-$(date "+%Y%m%d-%H%M%S").txt"

cat > "$LOG_FILE" << EOF
Pipeline Rewiring Log - $TIMESTAMP
========================================
Total Pipelines: $PIPELINE_COUNT
Successful: $SUCCESS_COUNT
Already on GitHub: $ALREADY_MIGRATED_COUNT
Skipped (repo not migrated): $SKIPPED_COUNT
Skipped (rewiring incomplete): $SKIPPED_REWIRING_COUNT
Failed: $FAILURE_COUNT
ADO throttling pauses: $RATE_LIMIT_PAUSE_COUNT

Detailed Results:
$(if [ "${#RESULTS[@]}" -gt 0 ] 2>/dev/null; then printf '%s\n' "${RESULTS[@]}"; else echo "None"; fi)

Already on GitHub Details:
$(if [ "${#ALREADY_MIGRATED_DETAILS[@]}" -gt 0 ] 2>/dev/null; then printf '%s\n' "${ALREADY_MIGRATED_DETAILS[@]}"; else echo "None"; fi)

Skipped Pipeline Details (Repository not migrated):
$(if [ "${#SKIPPED_DETAILS[@]}" -gt 0 ] 2>/dev/null; then printf '%s\n' "${SKIPPED_DETAILS[@]}"; else echo "None"; fi)

Skipped Pipeline Details (Rewiring incomplete):
$(if [ "${#SKIPPED_REWIRING[@]}" -gt 0 ] 2>/dev/null; then printf '%s\n' "${SKIPPED_REWIRING[@]}"; else echo "None"; fi)

Failed Pipeline Details:
$(if [ "${#FAILED_DETAILS[@]}" -gt 0 ] 2>/dev/null; then printf '%s\n' "${FAILED_DETAILS[@]}"; else echo "None"; fi)
========================================

Detailed Command Output:
========================================
EOF

# Append detailed command output if exists
if [ -f "$DETAILED_LOG" ] && [ -s "$DETAILED_LOG" ]; then
    cat "$DETAILED_LOG" >> "$LOG_FILE"
    rm -f "$DETAILED_LOG"
else
    echo "No detailed command output captured" >> "$LOG_FILE"
fi

# Generate CSV report - one row per pipeline (Success/AlreadyOnGitHub/Failed/Skipped),
# so results can be reviewed/shared without parsing the log file.
REPORT_CSV="pipeline-rewiring-status.csv"
{
    echo "org,teamproject,repo,pipeline_id,pipeline,github_org,github_repo,rewire_status,details"
    if [ "${#REPORT_ROWS[@]}" -gt 0 ] 2>/dev/null; then
        printf '%s\n' "${REPORT_ROWS[@]}"
    fi
} > "$REPORT_CSV"

echo -e "\n${GRAY}📄 Log saved: $LOG_FILE${NC}"
echo -e "${GRAY}📊 CSV report saved: $REPORT_CSV${NC}"

# ========================================
# EXIT WITH APPROPRIATE STATUS
# ========================================

# Determine exit behavior based on the three scenarios
ACTUAL_FAILURES=$FAILURE_COUNT  # Only count real errors, not "already migrated"
ACTUAL_SUCCESSES=$((SUCCESS_COUNT + ALREADY_MIGRATED_COUNT))  # Both are successful outcomes

# Check if ALL pipelines were skipped (no actual work done)
if [ $ACTUAL_SUCCESSES -eq 0 ] && [ $ACTUAL_FAILURES -eq 0 ] && [ $SKIPPED_COUNT -gt 0 ] && [ $SKIPPED_REWIRING_COUNT -gt 0 ]; then
    # All pipelines skipped - show warning
    echo -e "\n${YELLOW}⚠️  All pipelines skipped - no repositories were migrated${NC}"
    echo -e "${YELLOW}   ⏭️  Skipped: $SKIPPED_COUNT${NC}"
    echo -e "${YELLOW}   ⏭️  Skipped: $SKIPPED_REWIRING_COUNT${NC}"
    echo "##[warning]⚠️ All $SKIPPED_COUNT pipeline(s) skipped because their repositories were not successfully migrated"
    echo "##[warning]⚠️ All $SKIPPED_REWIRING_COUNT pipeline(s) skipped because rewiring is incomplete"
    echo "##vso[task.logissue type=warning]All pipelines skipped - no repositories migrated"

    # Show skipped pipeline details
    if [ ${#SKIPPED_DETAILS[@]} -gt 0 ]; then
        echo -e "\n${YELLOW}Skipped Pipeline Details:${NC}"
        for detail in "${SKIPPED_DETAILS[@]}"; do
            echo "##[warning]  Skipped: $detail"
        done
    fi

    # Show skipped rewiring details
    if [ ${#SKIPPED_REWIRING[@]} -gt 0 ]; then
        echo -e "\n${YELLOW}Skipped Pipeline Details:${NC}"
        for detail in "${SKIPPED_REWIRING[@]}"; do
            echo "##[warning]  Skipped: $detail"
        done
    fi

    # Set task result to SucceededWithIssues since no work was done
    echo "##vso[task.complete result=SucceededWithIssues]All pipelines skipped - no repositories migrated"
    exit 0

# Downstream stages should not fail completely, only show partial success
elif [ $ACTUAL_FAILURES -eq 0 ]; then
    # All successful (including already migrated)
    if [ $SKIPPED_COUNT -gt 0 ]; then
        # Some succeeded, some skipped
        echo -e "\n${GREEN}✅ Pipeline rewiring completed successfully${NC}"
        echo -e "${GREEN}   ✅ Successful: $SUCCESS_COUNT${NC}"
        if [ $ALREADY_MIGRATED_COUNT -gt 0 ]; then
            echo -e "${YELLOW}   ⚠️  Already on GitHub: $ALREADY_MIGRATED_COUNT${NC}"
        fi
        echo -e "${YELLOW}   ⏭️  Skipped: $SKIPPED_COUNT${NC}"
        echo "##[warning]$SKIPPED_COUNT pipeline(s) skipped because repositories were not migrated"
        
        # Show skipped details
        if [ ${#SKIPPED_DETAILS[@]} -gt 0 ]; then
            echo -e "\n${YELLOW}Skipped Pipeline Details (Repository not migrated):${NC}"
            for detail in "${SKIPPED_DETAILS[@]}"; do
                echo "##[warning]  Skipped: $detail"
            done
        fi
        
        echo "##vso[task.complete result=SucceededWithIssues]Rewiring completed with $SKIPPED_COUNT skipped pipeline(s)"
        exit 0

    elif [ $SKIPPED_REWIRING_COUNT -gt 0 ]; then
        # Some succeeded, some skipped
        echo -e "\n${GREEN}✅ Pipeline rewiring completed successfully${NC}"
        echo -e "${GREEN}   ✅ Successful: $SUCCESS_COUNT${NC}"
        if [ $ALREADY_MIGRATED_COUNT -gt 0 ]; then
            echo -e "${YELLOW}   ⚠️  Already on GitHub: $ALREADY_MIGRATED_COUNT${NC}"
        fi
        echo -e "${YELLOW}   ⏭️  Skipped: $SKIPPED_REWIRING_COUNT${NC}"
        echo "##[warning]$SKIPPED_REWIRING_COUNT pipeline(s) skipped because rewiring is incomplete"

        # Show skipped rewiring
        if [ ${#SKIPPED_REWIRING[@]} -gt 0 ]; then
            echo -e "\n${YELLOW}Skipped Pipeline Details (Rewiring incomplete):${NC}"
            for detail in "${SKIPPED_REWIRING[@]}"; do
                echo "##[warning]  Skipped: $detail"
            done
        fi

        echo "##vso[task.complete result=SucceededWithIssues]Rewiring completed with $SKIPPED_REWIRING_COUNT skipped pipeline(s)"
        exit 0

    elif [ $ALREADY_MIGRATED_COUNT -gt 0 ]; then
        echo -e "\n${GREEN}✅ Pipeline rewiring completed successfully${NC}"
        echo "##[warning]$ALREADY_MIGRATED_COUNT pipeline(s) already on GitHub - no rewiring needed"
        exit 0
    else
        echo -e "\n${GREEN}✅ All pipelines rewired successfully${NC}"
        exit 0
    fi
    
else
    # Partial success or some failed - downstream stage should continue
    echo -e "\n${YELLOW}⚠️  Pipeline rewiring completed with issues${NC}"
    echo -e "${GREEN}   ✅ Successful: $SUCCESS_COUNT${NC}"
    if [ $ALREADY_MIGRATED_COUNT -gt 0 ]; then
        echo -e "${YELLOW}   ⚠️  Already on GitHub: $ALREADY_MIGRATED_COUNT${NC}"
    fi
    if [ $SKIPPED_COUNT -gt 0 ]; then
        echo -e "${YELLOW}   ⏭️  Skipped: $SKIPPED_COUNT${NC}"
    fi
    if [ $SKIPPED_REWIRING_COUNT -gt 0 ]; then
        echo -e "${YELLOW}   ⏭️  Skipped: $SKIPPED_REWIRING_COUNT${NC}"
    fi
    echo -e "${RED}   ❌ Failed: $FAILURE_COUNT${NC}"

    # Output warnings for partial success
    echo "##[warning]⚠️ Rewiring completed with issues: $ACTUAL_SUCCESSES succeeded, $SKIPPED_COUNT skipped,$SKIPPED_REWIRING_COUNT skippedRewiring,$FAILURE_COUNT failed"
    echo "##vso[task.logissue type=warning]Partial success: $ACTUAL_SUCCESSES succeeded, $SKIPPED_COUNT skipped,$SKIPPED_REWIRING_COUNT skippedRewiring, $FAILURE_COUNT failed"
    
    # Show failed pipeline details as warnings
    if [ ${#FAILED_DETAILS[@]} -gt 0 ]; then
        echo -e "\n${YELLOW}Failed Pipeline Details:${NC}"
        for detail in "${FAILED_DETAILS[@]}"; do
            echo "##[warning]  Failed: $detail"
        done
    fi
    
    # Show skipped pipeline details
    if [ ${#SKIPPED_DETAILS[@]} -gt 0 ]; then
        echo -e "\n${YELLOW}Skipped Pipeline Details (Repository not migrated):${NC}"
        for detail in "${SKIPPED_DETAILS[@]}"; do
            echo "##[warning]  Skipped: $detail"
        done
    fi

    # Show skipped pipeline rewiring details
    if [ ${#SKIPPED_REWIRING[@]} -gt 0 ]; then
        echo -e "\n${YELLOW}Skipped Pipeline Details (rewiring incomplete):${NC}"
        for detail in "${SKIPPED_REWIRING[@]}"; do
            echo "##[warning]  Skipped: $detail"
        done
    fi

    # Show already migrated details if any
    if [ ${#ALREADY_MIGRATED_DETAILS[@]} -gt 0 ]; then
        echo -e "\n${YELLOW}Already on GitHub (No action needed):${NC}"
        for detail in "${ALREADY_MIGRATED_DETAILS[@]}"; do
            echo "##[warning]  Already migrated: $detail"
        done
    fi
    
    # Set task result to SucceededWithIssues and exit successfully
    echo "##vso[task.complete result=SucceededWithIssues]Rewiring completed with partial success"
    exit 0
fi
